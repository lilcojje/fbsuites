<?php

if (!defined( 'ABSPATH' )) {
    exit;
}
if (!class_exists( 'Ova_Hotel_Customize' )){

class Ova_Hotel_Customize {
	
	public function __construct() {
        add_action( 'customize_register', array( $this, 'ova_customize_register' ) );
    }

    public function ova_customize_register($wp_customize) {
        
        $this->init_archive_hotel( $wp_customize );
        $this->init_single_hotel( $wp_customize );
   
        do_action( 'ova_customize_register', $wp_customize );
    }


     public function init_archive_hotel( $wp_customize ){

     	$wp_customize->add_panel( 'rooms_list_panel', array(
		    'title'      => esc_html__( 'Rooms List', 'hozing' ),
		    'priority' => 5,
		) );

			// Rental List setting ////////////////////////////////////////////////////////////////////////////////////////////////////////

			$wp_customize->add_section( 'rental_list_section' , array(
			    'title'      => esc_html__( 'Room List', 'ova-hotel' ),
			    'priority'   => 6,
			    'panel'	=> 'rooms_list_panel'
			) );

				$wp_customize->add_setting( 'rl_type', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '2columns_sidebar',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );


			

				$wp_customize->add_setting( 'woo_layout', array(
					'type'              => 'theme_mod', // or 'option'
					'capability'        => 'edit_theme_options',
					'theme_supports'    => '', // Rarely needed.
					'default'           => 'layout_1c',
					'transport'         => 'refresh', // or postMessage
					'sanitize_callback' => 'sanitize_text_field' // Get function name 
						  
				) );
				$wp_customize->add_control('woo_layout', array(
					'label'    => esc_html__('Layout Archive','hozing'),
					'section'  => 'rental_list_section',
					'settings' => 'woo_layout',
					'type'     =>'select',
					'choices'  => apply_filters( 'hozing_define_layout', '' )
				));

				$wp_customize->add_setting( 'woo_sidebar_width', array(
					'type'              => 'theme_mod', // or 'option'
					'capability'        => 'edit_theme_options',
					'theme_supports'    => '', // Rarely needed.
					'default'           => '320',
					'transport'         => 'refresh', // or postMessage
					'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
				$wp_customize->add_control('woo_sidebar_width', array(
					'label'    => esc_html__('Sidebar Width (px)','hozing'),
					'section'  => 'rental_list_section',
					'settings' => 'woo_sidebar_width',
					'type'     =>'number'
				));

				

				$wp_customize->add_setting( 'rl_header', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'default',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('rl_header', array(
					'label' => esc_html__('Header style','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rl_header',
					'type' =>'select',
					'choices' => apply_filters('hozing_list_header', '')

				));

				$wp_customize->add_setting( 'rl_footer', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'default',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('rl_footer', array(
					'label' => esc_html__('Footer style','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rl_footer',
					'type' =>'select',
					'choices' => apply_filters('hozing_list_footer', '')

				));


				$wp_customize->add_control('rl_type', array(
					'label' => esc_html__('Product Template','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rl_type',
					'type' =>'select',
					'choices' => array(
						'2columns_sidebar' => esc_html__( 'Room grid with sidebar', 'ova-hotel' ),
						'room_list_with_sidebar' => esc_html__( 'Room list with sidebar', 'ova-hotel' ),
						
						'2columns_no_sidebar1' => esc_html__( 'Room grid 2 columns no sidebar v1', 'ova-hotel' ),
						'2columns_no_sidebar2' => esc_html__( 'Room grid 2 columns no sidebar v2', 'ova-hotel' ),

						'3columns_no_sidebar1' => esc_html__( 'Room grid 3 columns no sidebar v1', 'ova-hotel' ),
						'3columns_no_sidebar2' => esc_html__( 'Room grid 3 columns no sidebar v2', 'ova-hotel' ),

						'room_list' => esc_html__( 'Room list', 'ova-hotel' ),
						'room_lifestyle' => esc_html__( 'Room Lifestyle', 'ova-hotel' ),

					)

				));

				$wp_customize->add_setting( 'rl_show_search', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('rl_show_search', array(
					'label' => esc_html__('Show Search','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rl_show_search',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'rd_room_cat_margin_top', array(
				  	'type' => 'theme_mod', // or 'option'
				  	'capability' => 'edit_theme_options',
				  	'theme_supports' => '', // Rarely needed.
				  	'default' => '0',
				  	'transport' => 'refresh', // or postMessage
				  	'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('rd_room_cat_margin_top', array(
					'label' => esc_html__('Make Margin For Content(PX)','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rd_room_cat_margin_top',
					'type' =>'number',

				));


				$wp_customize->add_setting( 'rl_type_show_price', array(
					'type'              => 'theme_mod', // or 'option'
					'capability'        => 'edit_theme_options',
					'theme_supports'    => '', // Rarely needed.
					'default'           => 'yes',
					'transport'         => 'refresh', // or postMessage
					'sanitize_callback' => 'sanitize_text_field' // Get function name
				) );

				$wp_customize->add_control('rl_type_show_price', array(
					'label'    => esc_html__('Show Price','ova-hotel'),
					'section'  => 'rental_list_section',
					'settings' => 'rl_type_show_price',
					'type'     =>'select',
					'choices' => array(
						'yes' => esc_html__( 'Yes', 'ova-hotel' ),
						'no'  => esc_html__( 'No', 'ova-hotel' )
					)
				));

				$wp_customize->add_setting( 'rl_type_show_acreage', array(
					'type'              => 'theme_mod', // or 'option'
					'capability'        => 'edit_theme_options',
					'theme_supports'    => '', // Rarely needed.
					'default'           => 'yes',
					'transport'         => 'refresh', // or postMessage
					'sanitize_callback' => 'sanitize_text_field' // Get function name
				) );

				$wp_customize->add_control('rl_type_show_acreage', array(
					'label'    => esc_html__('Show Acreage','ova-hotel'),
					'section'  => 'rental_list_section',
					'settings' => 'rl_type_show_acreage',
					'type'     =>'select',
					'choices'  => array(
						'yes' => esc_html__( 'Yes', 'ova-hotel' ),
						'no'  => esc_html__( 'No', 'ova-hotel' )
					)
				));


				$wp_customize->add_setting( 'rl_type_show_special_info', array(
					'type'              => 'theme_mod', // or 'option'
					'capability'        => 'edit_theme_options',
					'theme_supports'    => '', // Rarely needed.
					'default'           => 'yes',
					'transport'         => 'refresh', // or postMessage
					'sanitize_callback' => 'sanitize_text_field' // Get function name
				) );

				$wp_customize->add_control('rl_type_show_special_info', array(
					'label'    => esc_html__('Show Special Info','ova-hotel'),
					'section'  => 'rental_list_section',
					'settings' => 'rl_type_show_special_info',
					'type'     =>'select',
					'choices'  => array(
						'yes' => esc_html__( 'Yes', 'ova-hotel' ),
						'no'  => esc_html__( 'No', 'ova-hotel' )
					)
				));

				$wp_customize->add_setting( 'rl_type_show_special_info_number', array(
					'type'              => 'theme_mod',
					'capability'        => 'edit_theme_options',
					'theme_supports'    => '',
					'default'           => 2,
					'transport'         => 'refresh',
					'sanitize_callback' => 'sanitize_text_field'
				));

				$wp_customize->add_control( 'rl_type_show_special_info_number', array(
					'label'    => esc_html__('Show Special Info Number', 'ova-hotel'),
					'section'  => 'rental_list_section',
					'settings' => 'rl_type_show_special_info_number',
					'min'      => 1,
					'type'     => 'number'
				));

				$wp_customize->add_setting( 'rl_type_show_adults_max', array(
					'type'              => 'theme_mod', // or 'option'
					'capability'        => 'edit_theme_options',
					'theme_supports'    => '', // Rarely needed.
					'default'           => 'yes',
					'transport'         => 'refresh', // or postMessage
					'sanitize_callback' => 'sanitize_text_field' // Get function name
				) );

				$wp_customize->add_control('rl_type_show_adults_max', array(
					'label'    => esc_html__('Show Adults Max','ova-hotel'),
					'section'  => 'rental_list_section',
					'settings' => 'rl_type_show_adults_max',
					'type'     =>'select',
					'choices'  => array(
						'yes' => esc_html__( 'Yes', 'ova-hotel' ),
						'no' => esc_html__( 'No', 'ova-hotel' )
					)
				));

				$wp_customize->add_setting( 'rl_type_show_children_max', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'yes',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name
				) );

				$wp_customize->add_control('rl_type_show_children_max', array(
					'label' => esc_html__('Show Childrens Max','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rl_type_show_children_max',
					'type' =>'select',
					'choices' => array(
						'yes' => esc_html__( 'Yes', 'ova-hotel' ),
						'no' => esc_html__( 'No', 'ova-hotel' )
					)
				));

				$wp_customize->add_setting( 'rl_type_show_amenities_featured', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'yes',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name
				) );

				$wp_customize->add_control('rl_type_show_amenities_featured', array(
					'label' => esc_html__('Show Amenities Featured','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rl_type_show_amenities_featured',
					'type' =>'select',
					'choices' => array(
						'yes' => esc_html__( 'Yes', 'ova-hotel' ),
						'no' => esc_html__( 'No', 'ova-hotel' )
					)
				));

				$wp_customize->add_setting( 'rl_type_show_amenities_featured_number', array(
					'type' => 'theme_mod',
					'capability' => 'edit_theme_options',
					'theme_supports' => '',
					'default' => '4',
					'transport' => 'refresh',
					'sanitize_callback' => 'sanitize_text_field'
				));

				$wp_customize-> add_control( 'rl_type_show_amenities_featured_number', array(
					'label' => esc_html__( 'Show Amenities Featured Number'),
					'section' => 'rental_list_section',
					'settings' => 'rl_type_show_amenities_featured_number',
					'type' => 'number',
					'min' => 1
				));

				$wp_customize->add_setting( 'rl_type_show_button', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'yes',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name
				) );

				$wp_customize->add_control('rl_type_show_button', array(
					'label' => esc_html__('Show Button','ova-hotel'),
					'section' => 'rental_list_section',
					'settings' => 'rl_type_show_button',
					'type' =>'select',
					'choices' => array(
						'yes' => esc_html__( 'Yes', 'ova-hotel' ),
						'no' => esc_html__( 'No', 'ova-hotel' )
					)
				));


				

			/* Search Settings *****************************/
			/*************************************************/


			$wp_customize->add_section( 'rl_search_section' , array(
			    'title'      => esc_html__( 'Search Settings', 'ova-hotel' ),
			    'priority'   => 8,
			    'panel'	=> 'rooms_list_panel'
			) );

				


				$wp_customize->add_setting( 'rl_search_tempale', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '2columns_no_sidebar1',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('rl_search_tempale', array(
					'label' => esc_html__('Product Template in Result Page','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'rl_search_tempale',
					'type' =>'select',
					'choices' => array(
						'2columns_sidebar' => esc_html__( 'Room grid 2 columns with sidebar', 'ova-hotel' ),
						'room_list_with_sidebar' => esc_html__( 'Room list with sidebar', 'ova-hotel' ),
						
						'2columns_no_sidebar1' => esc_html__( 'Room grid 2 columns no sidebar v1', 'ova-hotel' ),
						'2columns_no_sidebar2' => esc_html__( 'Room grid 2 columns no sidebar v2', 'ova-hotel' ),

						'3columns_no_sidebar1' => esc_html__( 'Room grid 3 columns no sidebar v1', 'ova-hotel' ),
						'3columns_no_sidebar2' => esc_html__( 'Room grid 3 columns no sidebar v2', 'ova-hotel' ),

						'room_list' => esc_html__( 'Room list', 'ova-hotel' ),
						'room_lifestyle' => esc_html__( 'Room Lifestyle', 'ova-hotel' ),

					)

				));

				


				$wp_customize->add_setting( 'show_check_in', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('show_check_in', array(
					'label' => esc_html__('Show Check-In','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'show_check_in',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'show_check_out', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('show_check_out', array(
					'label' => esc_html__('Show Check-Out','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'show_check_out',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'show_adults', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('show_adults', array(
					'label' => esc_html__('Show Adults','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'show_adults',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'show_childrens', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('show_childrens', array(
					'label' => esc_html__('Show Childrens','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'show_childrens',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'show_rooms', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'false',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('show_rooms', array(
					'label' => esc_html__('Show Rooms','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'show_rooms',
					'type' =>'select',
					'choices' => array(
						'false' => esc_html__( 'No', 'ova-hotel' ),
						'true' => esc_html__( 'Yes', 'ova-hotel' )
						
					)

				));

				$wp_customize->add_setting( 'show_night', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'false',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('show_night', array(
					'label' => esc_html__('Show Night','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'show_night',
					'type' =>'select',
					'choices' => array(
						'false' => esc_html__( 'No', 'ova-hotel' ),
						'true' => esc_html__( 'Yes', 'ova-hotel' )
						
					)

				));

				$wp_customize->add_setting( 'show_night_ipad', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'false',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('show_night_ipad', array(
					'label' => esc_html__('Show Night: ipad,mobile','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'show_night_ipad',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),	
						'false' => esc_html__( 'No', 'ova-hotel' ),
											
					)

				));



				$wp_customize->add_setting( 'req_input_check_in', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('req_input_check_in', array(
					'label' => esc_html__('Required Input: Check In','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'req_input_check_in',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'req_input_check_out', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'false',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('req_input_check_out', array(
					'label' => esc_html__('Required Input: Check-Out','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'req_input_check_out',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'req_input_adults', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('req_input_adults', array(
					'label' => esc_html__('Required Input: Adults','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'req_input_adults',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'req_input_childrens', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('req_input_childrens', array(
					'label' => esc_html__('Required Input: Childrens','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'req_input_childrens',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'req_input_rooms', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'false',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('req_input_rooms', array(
					'label' => esc_html__('Required Input: Rooms','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'req_input_rooms',
					'type' =>'select',
					'choices' => array(
						'true' => esc_html__( 'Yes', 'ova-hotel' ),
						'false' => esc_html__( 'No', 'ova-hotel' )
					)

				));

				$wp_customize->add_setting( 'max_adults', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '5',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('max_adults', array(
					'label' => esc_html__('Max Adults','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'max_adults',
					'type' =>'number'

				));

				$wp_customize->add_setting( 'max_childrens', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '5',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('max_childrens', array(
					'label' => esc_html__('Max Childrens','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'max_childrens',
					'type' =>'number'

				));

				$wp_customize->add_setting( 'max_rooms', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '10',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('max_rooms', array(
					'label' => esc_html__('Max Rooms','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'max_rooms',
					'type' =>'number'

				));

				$wp_customize->add_setting( 'rooms_result_page', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '6',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );

				$wp_customize->add_control('rooms_result_page', array(
					'label' => esc_html__('Rooms per Result Page','ova-hotel'),
					'section' => 'rl_search_section',
					'settings' => 'rooms_result_page',
					'type' =>'number'

				));

    }


     public function init_single_hotel( $wp_customize ){



			// Rental Detail setting ////////////////////////////////////////////////////////////////////////////////////////////////////////
			$wp_customize->add_panel( 'rental_detail_panel', array(
			    'title' => 'Room Detail',
			    'priority' => 6,
			) );

			$wp_customize->add_section( 'rd_show_hide_section' , array(
			    'title'      => esc_html__( 'Template', 'ova-hotel' ),
			    'priority'   => 30,
			    'panel' => 'rental_detail_panel',
			) );


			$wp_customize->add_setting( 'rd_header', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_header', array(
				'label' => esc_html__('Header Version','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_header',
				'type' =>'select',
				'choices' => apply_filters('hozing_list_header', '')

			));

			$wp_customize->add_setting( 'rd_header_margin_top', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => '-180',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_header_margin_top', array(
				'label' => esc_html__('Margin Top Content Detail (PX)','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_header_margin_top',
				'type' =>'number',

			));

			$wp_customize->add_setting( 'rd_footer', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_footer', array(
				'label' => esc_html__('Footer Version','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_footer',
				'type' =>'select',
				'choices' => apply_filters('hozing_list_footer', '')

			));

			$wp_customize->add_setting( 'rd_style', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'single-product',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_style', array(
				'label' => esc_html__('Template','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_style',
				'type' =>'select',
				'choices' => array(
					'single-product' => esc_html__( 'Template 1', 'ova-hotel' )
				)

			));

			
			$wp_customize->add_setting( 'rd_show_title', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_title', array(
				'label' => esc_html__('Show Title','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_title',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_breadcrumbs', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_breadcrumbs', array(
				'label' => esc_html__('Show Breadcrumbs','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_breadcrumbs',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_price', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_price', array(
				'label' => esc_html__('Show Price','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_price',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));


			$wp_customize->add_setting( 'rd_show_gallery_btn', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_gallery_btn', array(
				'label' => esc_html__('Show Gallery Button','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_gallery_btn',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));




			$wp_customize->add_setting( 'rd_show_video_btn', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_video_btn', array(
				'label' => esc_html__('Show Video Button','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_video_btn',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));
			
			

			$wp_customize->add_setting( 'rd_show_adults_max', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_adults_max', array(
				'label' => esc_html__('Show Adults Max','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_adults_max',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));


			$wp_customize->add_setting( 'rd_show_childrens_max', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_childrens_max', array(
				'label' => esc_html__('Show Childrens Max','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_childrens_max',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_acreage', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_acreage', array(
				'label' => esc_html__('Show Acreage','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_acreage',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_special_info', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_special_info', array(
				'label' => esc_html__('Show Special Info','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_special_info',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_amenities', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_amenities', array(
				'label' => esc_html__('Show Amenities','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_amenities',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_services', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_services', array(
				'label' => esc_html__('Show Services','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_services',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));
			

			$wp_customize->add_setting( 'rd_show_calendar', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_calendar', array(
				'label' => esc_html__('Show Calendar','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_calendar',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_booking_form', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_booking_form', array(
				'label' => esc_html__('Show booking form','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_booking_form',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));

			$wp_customize->add_setting( 'rd_show_related', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_show_related', array(
				'label' => esc_html__('Show Related Room','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_show_related',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' ),
				)

			));


			$wp_customize->add_setting( 'rd_room_number_related', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => '6',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('rd_room_number_related', array(
				'label' => esc_html__('Number Related Room','ova-hotel'),
				'section' => 'rd_show_hide_section',
				'settings' => 'rd_room_number_related',
				'type' =>'number',
				'min'  => 1
			));

		

		// Add Booking Settings
		$wp_customize->add_section( 'rd_booking_form' , array(
			    'title'      => esc_html__( 'Booking Form', 'ova-hotel' ),
			    'priority'   => 30,
			    'panel' => 'rental_detail_panel',
			) );
		
			$wp_customize->add_setting( 'booking_show_search', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'true',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
			) );

			$wp_customize->add_control('booking_show_search', array(
				'label' => esc_html__('Show Search','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_show_search',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' )
				)

			));


			$wp_customize->add_setting( 'booking_show_check_in', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_show_check_in', array(
				'label' => esc_html__('Show Check-In','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_show_check_in',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' )
				)

			));

			$wp_customize->add_setting( 'booking_show_check_out', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_show_check_out', array(
				'label' => esc_html__('Show Check-Out','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_show_check_out',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' )
				)

			));

			$wp_customize->add_setting( 'booking_show_adults', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_show_adults', array(
				'label' => esc_html__('Show Adults','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_show_adults',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' )
				)

			));

			$wp_customize->add_setting( 'booking_show_childrens', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_show_childrens', array(
				'label' => esc_html__('Show Childrens','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_show_childrens',
				'type' =>'select',
				'choices' => array(
					'true' => esc_html__( 'Yes', 'ova-hotel' ),
					'false' => esc_html__( 'No', 'ova-hotel' )
				)

			));

			$wp_customize->add_setting( 'booking_show_rooms', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_show_rooms', array(
				'label' => esc_html__('Show Rooms','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_show_rooms',
				'type' =>'select',
				'choices' => array(
					'false' => esc_html__( 'No', 'ova-hotel' ),
					'true' => esc_html__( 'Yes', 'ova-hotel' )
					
				)

			));

			$wp_customize->add_setting( 'booking_show_night', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'true',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_show_night', array(
				'label' => esc_html__('Show Night','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_show_night',
				'type' =>'select',
				'choices' => array(
					'false' => esc_html__( 'No', 'ova-hotel' ),
					'true' => esc_html__( 'Yes', 'ova-hotel' )
					
				)

			));

			

			// Required
			
			$wp_customize->add_setting( 'booking_req_input_adults', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => '',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_req_input_adults', array(
				'label' => esc_html__('Required Input: Adults','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_req_input_adults',
				'type' =>'select',
				'choices' => array(
					'required' => esc_html__( 'Yes', 'ova-hotel' ),
					'' => esc_html__( 'No', 'ova-hotel' )
				)

			));

			$wp_customize->add_setting( 'booking_req_input_childrens', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => '',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );

			$wp_customize->add_control('booking_req_input_childrens', array(
				'label' => esc_html__('Required Input: Childrens','ova-hotel'),
				'section' => 'rd_booking_form',
				'settings' => 'booking_req_input_childrens',
				'type' =>'select',
				'choices' => array(
					'required' => esc_html__( 'Yes', 'ova-hotel' ),
					'' => esc_html__( 'No', 'ova-hotel' )
				)

			));


     }

	
}

}

new Ova_Hotel_Customize();


 