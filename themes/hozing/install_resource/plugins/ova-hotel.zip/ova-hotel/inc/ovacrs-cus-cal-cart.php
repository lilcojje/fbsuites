<?php 
defined( 'ABSPATH' ) || exit();
function set_price_by_global_discount($product_id, $ovacrs_global_discount_duration_val = array(),  $rental_time ){

     if( $ovacrs_global_discount_duration_val ){

        foreach ($ovacrs_global_discount_duration_val as $key_dur => $value_dur) {
           if( $rental_time >=  $value_dur){
                $ovacrs_global_discount_price = get_post_meta( $product_id, 'ovacrs_global_discount_price', true );
                return $ovacrs_global_discount_price[$key_dur];

           }
        }
    }

    return false;

}


function set_price_by_rt_discount( $ovacrs_rt_discount_duration_val = array(), $ovacrs_rt_discount_duration_price = array(), $rental_time ){
    
    if( $ovacrs_rt_discount_duration_val ){
        foreach ($ovacrs_rt_discount_duration_val as $key_dur => $value_dur) {
           if( $rental_time >=  $value_dur){
                return $ovacrs_rt_discount_duration_price[$key_dur];

           }
        }
    }

    return false;

}

// YOu have to insert unistamp time
function get_time_bew_2day( $start, $end ){
    $rental_time_day_raw = ( $end - $start )/(24*60*60);
    return ceil( $rental_time_day_raw );
}



// Price in Global
function ovacrs_price_global( $product_id, $rental_time ){

    $ovacrs_global_discount_duration_val = get_post_meta( $product_id, 'ovacrs_global_discount_duration_val', true );
    if( $ovacrs_global_discount_duration_val ){ arsort( $ovacrs_global_discount_duration_val ); }


    // Set Price by Global Discount
    $gl_price = get_post_meta( $product_id, '_regular_price', true );
    if( $ovacrs_global_discount_duration_val ){
        $gl_set_price = set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val, $rental_time );
        $gl_price = ( $gl_set_price != false ) ? $gl_set_price : $gl_price;
    }
    return $gl_price;

}

// Calculate in Special Time ( Range Time )
function ovacrs_price_special_time( $product_id, $rental_time, $key_rt ){

    
    $ovacrs_rt_startdate = get_post_meta( $product_id, 'ovacrs_rt_startdate', true );
    $ovacrs_rt_price = get_post_meta( $product_id, 'ovacrs_rt_price', true );
    $ovacrs_rt_discount = get_post_meta( $product_id, 'ovacrs_rt_discount', true );
    
    if( $ovacrs_rt_startdate[$key_rt] ){

         $rt_price = $ovacrs_rt_price[$key_rt];
        // Return ST Price Discount
        if( isset( $ovacrs_rt_discount[$key_rt] ) ){
            $ovacrs_rt_discount_duration_val = $ovacrs_rt_discount[$key_rt]['duration'];
            arsort($ovacrs_rt_discount_duration_val);

            
            $ovacrs_rt_discount_duration_price = $ovacrs_rt_discount[$key_rt]['price'];
            $st_set_price = set_price_by_rt_discount($ovacrs_rt_discount_duration_val, $ovacrs_rt_discount_duration_price, $rental_time );
            $rt_price = $st_set_price != false ? $st_set_price : $rt_price;
        }

        return $rt_price;
        
    } // endif
}

// Get Quantity, Price, linetool
function ovacrs_cal_real_qr( $room_check_in, $room_check_out, $product_id ){
    

    $rental_time = get_time_bew_2day( $room_check_in, $room_check_out );

    $gl_quantity = $rental_time;
    $rt_quantity = $rt_price = 0;

    
    // Get Range Time or ST
    $ovacrs_rt_startdate = get_post_meta( $product_id, 'ovacrs_rt_startdate', true );
    $ovacrs_rt_enddate = get_post_meta( $product_id, 'ovacrs_rt_enddate', true );

    /* Table Price - Global *******************************************/
    $gl_price = ovacrs_price_global( $product_id, $rental_time );

    $line_total = $gl_price * $rental_time;
    

    /* Table Price - Special Time ( Range Time) *******************************************/
    if( $ovacrs_rt_startdate ){
        foreach ($ovacrs_rt_startdate as $key_rt => $value_rt) {

            /* If check-in-store - check-in - check-out - check-out-store */
            if( $room_check_in >= strtotime( $ovacrs_rt_startdate[$key_rt] ) && $room_check_out <= strtotime( $ovacrs_rt_enddate[$key_rt] ) ){

                $rt_quantity = $rental_time;
                $gl_quantity = 0;

                $rt_price = ovacrs_price_special_time( $product_id, $rental_time, $key_rt );

                $line_total = $rt_price * $rental_time;

                break;

            }/* Check-in - Check-in-store - Check-out - Check-out-store */
            else if( $room_check_in < strtotime( $ovacrs_rt_startdate[$key_rt] ) && $room_check_out <= strtotime( $ovacrs_rt_enddate[$key_rt] ) && $room_check_out >= strtotime( $ovacrs_rt_startdate[$key_rt] ) ){
                
                
                $gl_quantity = get_time_bew_2day( $room_check_in, strtotime( $ovacrs_rt_startdate[$key_rt] ) );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity );
                

                $rt_quantity = get_time_bew_2day( strtotime( $ovacrs_rt_startdate[$key_rt] ), $room_check_out );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity, $key_rt );
                
                $line_total = $gl_price * $gl_quantity + $rt_quantity * $rt_price;
                
                break;

            }/* Check-in-store - Check-in - Check-out-store - Check-out  */
            else if( $room_check_in >= strtotime( $ovacrs_rt_startdate[$key_rt] ) && $room_check_in <= strtotime( $ovacrs_rt_enddate[$key_rt] ) && $room_check_out >= strtotime( $ovacrs_rt_enddate[$key_rt] ) ){

                $gl_quantity = get_time_bew_2day( strtotime( $ovacrs_rt_enddate[$key_rt] ), $room_check_out-24*60*60 );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity );


                $rt_quantity = get_time_bew_2day( $room_check_in, strtotime( $ovacrs_rt_enddate[$key_rt] )+24*60*60 );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity, $key_rt );
               
                
                // $quantity = $gl_quantity + $rt_quantity;
                $line_total = $gl_price * $gl_quantity + $rt_quantity * $rt_price;

                break;

            }else if( $room_check_in < strtotime( $ovacrs_rt_startdate[$key_rt] ) && $room_check_out > strtotime( $ovacrs_rt_enddate[$key_rt] ) ){

                $gl_quantity_1 = get_time_bew_2day( $room_check_in, strtotime( $ovacrs_rt_startdate[$key_rt] ) );
                $gl_quantity_3 = get_time_bew_2day( strtotime( $ovacrs_rt_enddate[$key_rt] )+24*60*60, $room_check_out );
                $gl_quantity = $gl_quantity_1 + $gl_quantity_3;

                $rt_quantity = get_time_bew_2day( strtotime( $ovacrs_rt_startdate[$key_rt] ), strtotime( $ovacrs_rt_enddate[$key_rt] )+24*60*60 );
                
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity, $key_rt );


                $line_total = $gl_price * $gl_quantity + $rt_quantity * $rt_price;
                break;

            }

        }
    }
    return array( 'line_total' => $line_total, 'gl_quantity' => $gl_quantity, 'gl_price' => $gl_price, 'rt_quantity' => $rt_quantity, 'rt_price' => $rt_price );

}





// Custom Calculate Total Add To Cart
add_action( 'woocommerce_before_calculate_totals',  'ovacrs_woocommerce_before_calculate_totals' , 10, 1); 
function ovacrs_woocommerce_before_calculate_totals( $cart_object ){



    foreach ( $cart_object->get_cart() as $cart_item_key => $cart_item) {
        
        // Check custom product type is ovacrs_car_rental
        if( !$cart_item['data']->is_type('ovacrs_car_rental') ) continue;

    	$product_id = $cart_item['product_id'];

        // Calculate Rent Time
    	$room_check_in = strtotime( $cart_item['room_check_in'] );
    	$room_check_out = strtotime( $cart_item['room_check_out'] );
        $room_rooms = intval( $cart_item['room_rooms'] );

        $ovacrs_cal_real_qr = ovacrs_cal_real_qr( $room_check_in, $room_check_out, $product_id );
        $line_total = $ovacrs_cal_real_qr['line_total'];

        $cart_item['data']->set_price( $line_total * $room_rooms );
        $cart_object->cart_contents[ $cart_item_key ]['quantity'] = 1;


    } // End foreach

    
}









