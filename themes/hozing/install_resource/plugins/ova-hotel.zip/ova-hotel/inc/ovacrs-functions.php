<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if( !function_exists( 'ovacrs_locate_template' ) ){
	function ovacrs_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		
		// Set variable to search in ovacrs-templates folder of theme.
		if ( ! $template_path ) :
			$template_path = 'ova-hotel/';
		endif;

		// Set default plugin templates path.
		if ( ! $default_path ) :
			$default_path = OVACRS_PLUGIN_PATH . 'ova-hotel/'; // Path to the template folder
		endif;

		// Search template file in theme folder.
		$template = locate_template( array(
			$template_path . $template_name
			// ,$template_name
		) );

		// Get plugins template file.
		if ( ! $template ) :
			$template = $default_path . $template_name;
		endif;

		return apply_filters( 'ovacrs_locate_template', $template, $template_name, $template_path, $default_path );
	}

}


function ovacrs_get_template( $template_name, $args = array(), $tempate_path = '', $default_path = '' ) {
	if ( is_array( $args ) && isset( $args ) ) :
		extract( $args );
	endif;
	$template_file = ovacrs_locate_template( $template_name, $tempate_path, $default_path );
	if ( ! file_exists( $template_file ) ) :
		_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
		return;
	endif;

	
	include $template_file;
}



// Change Name Product to Hotel
add_filter( 'woocommerce_register_post_type_product', 'ovacrs_custom_post_type_label_woo' );
function ovacrs_custom_post_type_label_woo( $args ){
    $labels = array(
        'name'               => __( 'Room', 'ova-hotel' ),
        'singular_name'      => __( 'Room', 'ova-hotel' ),
        'menu_name'          => _x( 'Rooms', 'Admin menu name', 'ova-hotel' ),
        'add_new'            => __( 'Add Room', 'ova-hotel' ),
        'add_new_item'       => __( 'Add New Room', 'ova-hotel' ),
        'edit'               => __( 'Edit Room', 'ova-hotel' ),
        'edit_item'          => __( 'Edit Room', 'ova-hotel' ),
        'new_item'           => __( 'New Room', 'ova-hotel' ),
        'view'               => __( 'View Room', 'ova-hotel' ),
        'view_item'          => __( 'View Room', 'ova-hotel' ),
        'search_items'       => __( 'Search Room', 'ova-hotel' ),
        'not_found'          => __( 'No Room found', 'ova-hotel' ),
        'not_found_in_trash' => __( 'No Room found in trash', 'ova-hotel' ),
        'parent'             => __( 'Parent Element', 'ova-hotel' )
    );

    $args['labels'] = $labels;
    $args['description'] = __( 'This is where you can add new hotel to your store.', 'ova-hotel' );
    return $args;
}


// Hide some fields in Checkout Woocommerce
add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields' );
  
function custom_override_checkout_fields( $fields ) {
 	
 	// unset($fields['billing']['billing_first_name']);
	// unset($fields['billing']['billing_last_name']);
	unset($fields['billing']['billing_company']);
	// unset($fields['billing']['billing_address_1']);
	unset($fields['billing']['billing_address_2']);
	unset($fields['billing']['billing_city']);
	unset($fields['billing']['billing_postcode']);
	unset($fields['billing']['billing_country']);
	unset($fields['billing']['billing_state']);
	// unset($fields['billing']['billing_phone']);
	// unset($fields['order']['order_comments']);
	// unset($fields['billing']['billing_email']);
	// unset($fields['account']['account_username']);
	// unset($fields['account']['account_password']);
	// unset($fields['account']['account_password-2']);

    return $fields;
}


// Get Array Product ID with WPML
function get_arr_product_ids( $product_id_original ){

	
	$translated_ids = Array();


	if ( function_exists('icl_object_id') ) {

	    global $sitepress;
		
		if(!isset($sitepress)) return;
		
		$trid = $sitepress->get_element_trid($product_id_original, 'post_product');
		$translations = $sitepress->get_element_translations($trid, 'product');
		foreach( $translations as $lang=>$translation){
		    $translated_ids[] = $translation->element_id;
		}

	}else{
		$translated_ids[] = $product_id_original;
	}

	return $translated_ids;

}


