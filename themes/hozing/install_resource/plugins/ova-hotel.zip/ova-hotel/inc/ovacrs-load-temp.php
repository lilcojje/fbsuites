<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class ovacrs_load_template {

	
	/**
	 * The Constructor
	 */
	public function __construct() {

		add_filter( 'template_include', array( $this, 'ovacrs_template_loader' ) );
		
	}

	public function ovacrs_template_loader( $template ) {

		$search = isset( $_REQUEST['ovahotel_search'] ) ? $_REQUEST['ovahotel_search'] : '';

		if( $search != ''){
			ovacrs_get_template( 'search.php' );
			exit();
		}

		return $template;

	}


}

new ovacrs_load_template();
