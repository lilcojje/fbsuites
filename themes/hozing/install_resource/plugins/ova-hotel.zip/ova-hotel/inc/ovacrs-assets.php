<?php defined( 'ABSPATH' ) || exit();

if( !class_exists( 'OVACRS_Assets' ) ){
	class OVACRS_Assets{

		public function __construct(){
			add_action( 'admin_footer', array( $this, 'ovacrs_admin_enqueue_scripts' ), 10, 2 );
			add_action( 'wp_enqueue_scripts', array( $this, 'ovacrs_enqueue_scripts' ), 10, 2 );

		}

		public function ovacrs_admin_enqueue_scripts(){
			// Date Picker
			wp_enqueue_script('datepicker', OVACRS_PLUGIN_URI.'assets/plugins/jquery-ui/jquery-ui.min.js', array('jquery'), null, true );
			wp_enqueue_style('datepicker', OVACRS_PLUGIN_URI.'assets/plugins/jquery-ui/jquery-ui.min.css', array(), null);
			
			wp_enqueue_script('ova_crs_admin', OVACRS_PLUGIN_URI.'assets/ova-crs-admin.js', array('jquery'), null, true );


			// Admin Css
			wp_enqueue_style('ovacrs-default', OVACRS_PLUGIN_URI.'assets/ovacrs_admin.css', array(), null);

		}
		public function ovacrs_enqueue_scripts(){

			wp_enqueue_script('datepicker', OVACRS_PLUGIN_URI.'assets/plugins/jquery-ui/jquery-ui.min.js', array('jquery'), null, true );
			wp_enqueue_style('datepicker', OVACRS_PLUGIN_URI.'assets/plugins/jquery-ui/jquery-ui.min.css', array(), null);

			$choice_cal_lang = get_theme_mod( 'choice_cal_lang', '' );
			if( $choice_cal_lang ){
				wp_enqueue_script('datepicker_lang', OVACRS_PLUGIN_URI.'assets/plugins/jquery-ui/lang/datepicker-'.$choice_cal_lang.'.js', array('jquery'), null, true );	
			}
			

			wp_enqueue_script('select2', OVACRS_PLUGIN_URI.'assets/plugins/select2/select2.min.js', array('jquery'), null, true );
			wp_enqueue_style('select2', OVACRS_PLUGIN_URI.'assets/plugins/select2/select2.min.css', array(), null);

			wp_enqueue_script('validate', OVACRS_PLUGIN_URI.'assets/plugins/jquery.validate.min.js', array('jquery'), null, true );
			


			// Calendar
			if( is_product() && class_exists('woocommerce') ){

				wp_enqueue_script('moment', OVACRS_PLUGIN_URI.'assets/plugins/fullcalendar/moment.min.js', array('jquery'),null,true);
	    		wp_enqueue_script('fullcalendar', OVACRS_PLUGIN_URI.'assets/plugins/fullcalendar/fullcalendar.min.js', array('jquery'),null,true);
	    		wp_enqueue_style('fullcalendar_print', OVACRS_PLUGIN_URI.'assets/plugins/fullcalendar/fullcalendar.print.min.css', array(), null, 'print');
	    		wp_enqueue_style('fullcalendar', OVACRS_PLUGIN_URI.'assets/plugins/fullcalendar/fullcalendar.min.css', array(), null);

	    		$event_calendar_language = get_theme_mod( 'event_calendar_language', '' );
	    		if( $event_calendar_language ){
	    			wp_enqueue_script('fullcalendar-locales', OVACRS_PLUGIN_URI.'assets/plugins/fullcalendar/locale/'.$event_calendar_language.'.js', array('jquery'),null,true);	
	    		}
				
    		}


    		wp_enqueue_script('ova_hotel', OVACRS_PLUGIN_URI.'assets/ova-hotel.js', array('jquery'), null, true );

			// // Hotel Css
			wp_enqueue_style( 'ova-hotel', OVACRS_PLUGIN_URI.'/assets/ova-hotel.css', array(), null);


			
		}


	}
	new OVACRS_Assets();
}
