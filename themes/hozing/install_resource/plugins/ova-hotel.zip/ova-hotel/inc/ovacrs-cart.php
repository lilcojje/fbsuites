<?php
defined( 'ABSPATH' ) || exit();

// Validate Rent Day Min
if ( ! function_exists( 'ovacrs_val_day_min' ) ) {
    function ovacrs_val_day_min( $room_check_out, $room_check_in, $ovacrs_rent_day_min ){
        return ( $room_check_out - $room_check_in ) <= $ovacrs_rent_day_min*24*60 ? true : false;
    }
}



// Get Order ID include Product ID
function ovacrs_get_orders_ids_by_product_id( $product_id, $order_status = array( 'wc-completed' ) ){
    global $wpdb;
    
    $results = array();

    if( is_array( $product_id ) ){
        foreach ($product_id as $key => $value) {

            $orders_id = $wpdb->get_col("
                SELECT Distinct order_items.order_id
                FROM {$wpdb->prefix}woocommerce_order_items as order_items
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
                LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
                WHERE posts.post_type = 'shop_order'
                AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
                AND order_items.order_item_type = 'line_item'
                AND order_item_meta.meta_key = '_product_id'
                AND order_item_meta.meta_value = '$value'
            ");

            $results = array_merge( $results, $orders_id );
        }
    }else{

        $results = $wpdb->get_col("
            SELECT Distinct order_items.order_id
            FROM {$wpdb->prefix}woocommerce_order_items as order_items
            LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
            LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
            WHERE posts.post_type = 'shop_order'
            AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
            AND order_items.order_item_type = 'line_item'
            AND order_item_meta.meta_key = '_product_id'
            AND order_item_meta.meta_value = '$product_id'
        ");
    }
    

    return $results;
}


// 0: Validate Booking Form And Rent Time
add_filter( 'woocommerce_add_to_cart_validation', 'ovacrs_validation_booking_form', 10, 5 );      
function ovacrs_validation_booking_form( $passed ) {

    // Check product type is ovacrs_car_rental
    $custom_product_type = filter_input( INPUT_POST, 'custom_product_type' );
    if( $custom_product_type != 'ovacrs_car_rental' ) return true;
    

    // Get Value From Booking Form
    $room_check_in = strtotime( filter_input( INPUT_POST, 'room_check_in' ) );
    $room_check_out = strtotime( filter_input( INPUT_POST, 'room_check_out' ) );
    $room_adults = intval( filter_input( INPUT_POST, 'room_adults' ) );
    $room_childrens = intval( filter_input( INPUT_POST, 'room_childrens' ) );
    $room_rooms = intval( filter_input( INPUT_POST, 'room_rooms' ) );
    $room_id = intval( filter_input( INPUT_POST, 'room_id' ) );


    // Total Car in the Store
    $total_car_store = get_post_meta( $room_id, 'ovacrs_car_count', true );

    // Rent day min
    $ovacrs_rent_day_min = (int)get_post_meta( $room_id, 'ovacrs_rent_day_min', true );
   

    if ( empty( $room_check_in ) || empty( $room_check_out ) ) {
        wc_clear_notices();
        echo wc_add_notice( __("Put Check-in, Check-out", 'ova-hotel'), 'error');
        return false;
    }

    // Error Pick Up Date > Pick Off Date
    if( $room_check_in >  $room_check_out){
        wc_clear_notices();
        echo wc_add_notice( __("Check-in Date must be greater than Check-out Date", 'ova-hotel'), 'error');
        return false;
    }

    // Error Pick Up Date < Current Time
    if( $room_check_in+24*60*60 < current_time('timestamp') ){
        wc_clear_notices();
        echo wc_add_notice( __("Check-in Date must be greater than Current Time", 'ova-hotel'), 'error');   
        return false;
    }

    // Error Rent Time Min

    if( ovacrs_val_day_min( $room_check_out, $room_check_in, $ovacrs_rent_day_min ) ){
        wc_clear_notices();
        echo wc_add_notice( sprintf( esc_html__( 'Rent Hour Min %d hour', 'ova-hotel' ), $ovacrs_rent_hour_min ), 'error');   
        return false;
    }

    // Error: Unvailable time for renting
    $ovacrs_untime_startdate = get_post_meta( $room_id, 'ovacrs_untime_startdate', true );
    $ovacrs_untime_enddate = get_post_meta( $room_id, 'ovacrs_untime_enddate', true );
    if( $ovacrs_untime_startdate ){
        foreach ($ovacrs_untime_startdate as $key => $value) {
            if( ! ($room_check_out < strtotime( $ovacrs_untime_startdate[$key] ) || strtotime( $ovacrs_untime_enddate[$key] ) < $room_check_in ) ){
                wc_clear_notices();
                echo wc_add_notice( esc_html__( 'This time is not available for renting', 'ova-hotel' ), 'error');
                return false;
                break;
            }
        }
    }
    
    // Check Max Adults
    $room_adults_max = get_post_meta( $room_id, 'ovacrs_car_max_adults', true );
    if( $room_adults_max < $room_adults ){
        wc_clear_notices();
        echo wc_add_notice( sprintf( esc_html__( 'Max Adults is %d', 'ova-hotel' ), $room_adults_max ), 'error');   
        return false;
    }

    // Check Max Childrents
    $room_childrents_max = get_post_meta( $room_id, 'ovacrs_car_max_childrens', true );
    if( $room_childrents_max < $room_childrens ){
        wc_clear_notices();
        echo wc_add_notice( sprintf( esc_html__( 'Max Childrents is %d', 'ova-hotel' ), $room_childrents_max ), 'error');   
        return false;
    }


    // Compare Rent Day with database
    // Set the orders statuses
    $statuses = array( 'wc-completed', 'wc-processing', 'wc-on-hold' );
    
    // Get array product_ids for case use WPML
    $translated_ids = get_arr_product_ids( $room_id );


    $orders_ids = ovacrs_get_orders_ids_by_product_id( $translated_ids, $statuses );

    $car_in_store = get_post_meta( $room_id, 'ovacrs_car_count', true ); /* Get total room in store */
    $car_using_this_time = 0; /* Count car is using in time need to rent  */
    $cart_room_rented_array = $store_room_rented_array = array();
    $store_room_rented_count = $cart_room_rented_count = 0;



    // For Order ID
    foreach ($orders_ids as $key => $value) {
        
        // Get Order Detail by Order ID
        $order = wc_get_order($value);

        // Get Meta Data type line_item of Order
        $order_line_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
        

        // For Meta Data
        foreach ( $order_line_items as $item_id => $item ) {
            
            $room_check_in_store = $room_check_out_store = '';
            $id_room_rented = array();
            

            // Check Line Item have item ID is room_id
            if( in_array($item->get_product_id(), $translated_ids) ){

                // Get value of pickup date, pickoff date
                foreach ( $item->get_formatted_meta_data() as $meta_id => $meta ) {
                    if( $meta->key == 'room_check_in' ){
                        $room_check_in_store = strtotime( str_replace('/', '-', $meta->value) );
                    }
                    if( $meta->key == 'room_check_out' ){
                        $room_check_out_store = strtotime( str_replace('/', '-', $meta->value) );
                    }

                    if( $meta->key == 'id_room_code' ){
                        $id_room_rented = explode( ',', $meta->value );
                    }

                }


                // Only compare date when "PickOff Date in Store" > "Current Time" becaue "PickOff Date Rent" have to > "Current Time"
                if( $room_check_out_store >= current_time( 'timestamp' ) ){
                    if( ! ($room_check_out <= $room_check_in_store || $room_check_out_store <= $room_check_in ) ){
                        if( $id_room_rented != '' ){
                            foreach ($id_room_rented as $key => $value) {
                                array_push( $store_room_rented_array, trim( $value ) );    
                            }
                            
                        }
                    }
                }
                
                
            }

        } 

    }


    

    $store_room_rented_array = ($store_room_rented_array != null) ? array_unique( $store_room_rented_array ) : array();


    // Check Count car in Cart current
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
        if( $product_id == $room_id && !( $room_check_out <= strtotime( $cart_item['room_check_in'] )  || strtotime( $cart_item['room_check_out'] ) <= $room_check_in ) ){
            if( $cart_item['id_room_code'] != ''  ){
                $id_room_code_array = explode( ',', $cart_item['id_room_code'] );
                foreach ($id_room_code_array as $key => $value) {
                    array_push( $cart_room_rented_array, trim($value) );
                }
            }
            
        }
    }
    
    $cart_room_rented_array = ( $cart_room_rented_array != null ) ? array_unique( $cart_room_rented_array ) : array();
    


    $id_room_code_rented = array_unique( array_merge( $store_room_rented_array, $cart_room_rented_array ) );
    



    $available_room = $total_car_store - count( $id_room_code_rented );
    
    if( $available_room < $room_rooms ){
        wc_clear_notices();
        echo wc_add_notice( sprintf( esc_html__( 'Room is unavailable for this time, Room available is %d', 'ova-hotel' ), $available_room ), 'error');
        return false;
    }


    

    // Set id_room_code_available
    if( !is_admin() ){
        
        $id_room_codes_store = explode( ',', str_replace( ' ', '', get_post_meta( $room_id, 'ovacrs_id_vehicles', true ) ) );
        
        $id_room_code_available = array_values( array_diff( $id_room_codes_store, $id_room_code_rented ) );

        $code_room_available = array();
        for( $i = 0 ; $i < $room_rooms; $i++ ){
            array_push( $code_room_available, $id_room_code_available[$i] );
        }

        foreach ($id_room_code_available as $key => $value) {
            WC()->session->set( 'id_room_code_available' , implode( ',', $code_room_available ) );
            break;
        }
    }


    return $passed;
}



// 1: Add Extra Data To Cart Item

add_filter( 'woocommerce_add_cart_item_data', 'ovacrs_add_extra_data_to_cart_item', 1, 10 );
function ovacrs_add_extra_data_to_cart_item( $cart_item_data, $product_id, $variation_id ) {

    
    
    $room_check_in = filter_input( INPUT_POST, 'room_check_in' );
    $room_check_out = filter_input( INPUT_POST, 'room_check_out' );
    $room_adults = filter_input( INPUT_POST, 'room_adults' );
    $room_childrens = filter_input( INPUT_POST, 'room_childrens' );
    $room_rooms = filter_input( INPUT_POST, 'room_rooms' );
    
    
    if (  empty( $room_check_in ) && empty( $room_check_out ) ) {
        return $cart_item_data;
    }
    
    $cart_item_data['room_check_in'] = $room_check_in;
    $cart_item_data['room_check_out'] = $room_check_out;
    $cart_item_data['room_adults'] = $room_adults;
    $cart_item_data['room_childrens'] = $room_childrens;
    $cart_item_data['room_rooms'] = $room_rooms;
    

    $id_room_code_available = '';
    if( WC()->session->__isset( 'id_room_code_available' ) ){
        $id_room_code_available = WC()->session->get( 'id_room_code_available' );
        WC()->session->__unset( 'id_room_code_available' );
    }

    $cart_item_data['id_room_code'] = trim( $id_room_code_available );
 
    return $cart_item_data;
}
 



// 2: Display Extra Data in the Cart
add_filter( 'woocommerce_get_item_data', 'ovacrs_display_extra_data_cart', 10, 2 );
function ovacrs_display_extra_data_cart( $item_data, $cart_item ) {

    if( !$cart_item['data']->is_type('ovacrs_car_rental') ) return $item_data;

    if (   empty( $cart_item['room_check_in'] ) && empty( $cart_item['room_check_out'] ) ) {
        wc_clear_notices();
        wc_add_notice( __("Insert full data in booking form"), 'notice');
        return false;
    }

    $item_data[] = array(
        'key'     => esc_html__( 'Check-in', 'ova-hotel' ),
        'value'   => wc_clean( $cart_item['room_check_in'] ),
        'display' => '',
    );

    $item_data[] = array(
        'key'     => esc_html__( 'Check-out', 'ova-hotel' ),
        'value'   => wc_clean( $cart_item['room_check_out'] ),
        'display' => '',
    );

    $item_data[] = array(
        'key'     => esc_html__( 'Adults', 'ova-hotel' ),
        'value'   => wc_clean( $cart_item['room_adults'] ),
        'display' => '',
    );

    $item_data[] = array(
        'key'     => esc_html__( 'Childrens', 'ova-hotel' ),
        'value'   => wc_clean( $cart_item['room_childrens'] ),
        'display' => '',
    );

    $item_data[] = array(
        'key'     => esc_html__( 'Rooms', 'ova-hotel' ),
        'value'   => wc_clean( $cart_item['room_rooms'] ),
        'display' => '',
    );

    $item_data[] = array(
        'key'     => esc_html__( 'Room Code', 'ova-hotel' ),
        'value'   => wc_clean( trim( $cart_item['id_room_code'] ) ),
        'display' => '',
    );
    
    
 
    return $item_data;
}
 



// 3: Save to Order
add_action( 'woocommerce_checkout_create_order_line_item', 'ovacrs_add_extra_data_to_order_items', 10, 4 );
function ovacrs_add_extra_data_to_order_items( $item, $cart_item_key, $values, $order ) {

    if (  empty( $values['room_check_in'] ) && empty( $values['room_check_out'] ) ) {
        return;
    }
    
    $item->add_meta_data( 'room_check_in', $values['room_check_in'] );
    $item->add_meta_data( 'room_check_out', $values['room_check_out'] );
    
    $product_id = $item->get_product_id();
    $real_quantity = get_real_quantity( 1, $product_id, strtotime( $values['room_check_in'] ), strtotime( $values['room_check_out'] ) );
    $item->add_meta_data( 'ovacrs_total_days', $real_quantity );

    $real_price = get_real_price( 1, $product_id, strtotime( $values['room_check_in'] ), strtotime( $values['room_check_out'] ) );
    $item->add_meta_data( 'ovacrs_price_detail', $real_price );

    $item->add_meta_data( 'room_adults', $values['room_adults'] );
    $item->add_meta_data( 'room_childrens', $values['room_childrens'] );
    $item->add_meta_data( 'room_rooms', $values['room_rooms'] );
    
    $item->add_meta_data( 'id_room_code', trim( $values['id_room_code'] ) );
}
 



