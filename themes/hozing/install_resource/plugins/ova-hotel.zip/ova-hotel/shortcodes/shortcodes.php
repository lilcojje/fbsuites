<?php if ( !defined( 'ABSPATH' ) ) exit();



add_shortcode( 'ovahotel_search', 'ovahotel_search' );
function ovahotel_search( $atts, $content = null ){

    $atts = extract( shortcode_atts(
    array(
        'style' => 'default',
        'show_check_in' => '',
        'show_check_out' => '',
        'show_adults' => '',
        'show_childrens' => '',
        'show_rooms' => '',
        'show_night' => '',
        'show_night_ipad' => '',
        'req_input_check_in'  => '',
        'req_input_check_out'  => '',
        'req_input_adults'  => '',
        'req_input_childrens'  => '',
        'req_input_rooms'  => '',
        'max_adults' => '',
        'max_childrens' => '',
        'max_rooms' => '',
        'date_format_display'    => 'Y-m-d',
        'date_format_popup'   => 'Y-m-d',
        'type'  => 'checking',
        'slug_product'  => '',
        'button_text'   => esc_html__( 'Check Available', 'ova-hotel' ),
        'button_icon'   => 'icon_box-checked',
        'class'   => '',
    ), $atts) );

    if( strpos( $class, 'elementor_sc')){
        $class_columns = '';
    } else{
        $class_columns = 'col-lg-3 col-md-4';
    }

    if( strpos($class, 'seach_sc')){
        $class_btn_sc = 'btn_seach_sc';
    } else {
        $class_btn_sc = '';
    }

    $post = get_page_by_path( $slug_product, OBJECT, 'product' );
    $product_id = $post != '' ? $post->ID : '';


    // Show/Hide field in Form
    $total_fields = 6;

    $show_check_in      = $show_check_in == '' ? get_theme_mod( 'show_check_in', 'true' ) : $show_check_in;
    $show_check_out     = $show_check_out == '' ? get_theme_mod( 'show_check_out', 'true' ) : $show_check_out;
    $show_adults        = $show_adults == '' ? get_theme_mod( 'show_adults', 'true' ) : $show_adults;
    $show_childrens     = $show_childrens == '' ? get_theme_mod( 'show_childrens', 'true' ) : $show_childrens;
    $show_rooms         = $show_rooms == '' ? get_theme_mod( 'show_rooms', 'false' ) : $show_rooms;
    $show_night         = $show_night == '' ? get_theme_mod( 'show_night', 'false' ) : $show_night;
    $show_night_ipad    = $show_night_ipad == '' ? get_theme_mod( 'show_night_ipad', 'false' ) : $show_night_ipad;

    if( $show_childrens == 'false' ) $total_fields = $total_fields - 1;
    if( $show_night == 'false' ) $total_fields = $total_fields - 1;

    $max_adults         = $max_adults == '' ? intval( get_theme_mod( 'max_adults', '5' ) ) : intval( $max_adults );
    $max_childrens       = $max_childrens == '' ? intval( get_theme_mod( 'max_childrens', '5' ) ) : intval( $max_childrens );
    $max_rooms          = $max_rooms == '' ? intval( get_theme_mod( 'max_rooms', '10' ) ) : intval( $max_rooms );

    $date_format_popup        = $date_format_popup == '' ? get_theme_mod( 'date_format_popup', 'Y-m-d' ) : $date_format_popup;
    $date_format_display        = $date_format_display == '' ? get_theme_mod( 'date_format_display', 'Y-m-d' ) : $date_format_display;
    
    
    // Check Field requirement
    $is_req_check_in = $is_req_check_out = $is_req_adults = $is_req_childrens = $is_req_rooms = '';
    
    if( $req_input_check_in == '' ){
        $is_req_check_in = get_theme_mod( 'req_input_check_in', 'true' ) == 'true' ? 'required' : '';
    }else{
        $is_req_check_in =  $req_input_check_in;
    }
    
    if( $req_input_check_out == '' ){
        $is_req_check_out = get_theme_mod( 'req_input_check_out', 'true' ) == 'true' ? 'required' : '';
    }else{
        $is_req_check_out = $req_input_check_out;
    }
    
    
    if( $req_input_adults == '' ){
        $is_req_adults = get_theme_mod( 'req_input_adults', 'true' ) == 'true' ? 'required' : '';
    }else{
        $is_req_adults = $req_input_adults;
    }


    if( $req_input_childrens == '' ){
        $is_req_childrens = get_theme_mod( 'req_input_childrens', 'true' ) == 'true' ? 'required' : '';
    }else{
        $is_req_childrens = $req_input_childrens;
    }

    if( $req_input_rooms == '' ){
        $is_req_rooms = get_theme_mod( 'req_input_rooms', 'false' ) == 'true' ? 'required' : '';
    }else{
        $is_req_rooms = $req_input_rooms;
    }

    
    // Today date
    $current_time = current_time( 'timestamp', true  );
    $current_timestamp = strtotime( date_i18n( 'Y-m-d', $current_time ) );
    $today_date =  date_i18n( 'Y-m-d', $current_timestamp );
    $next_date =  date_i18n( 'Y-m-d',  $current_timestamp+86400 );
    $next2_date = date_i18n( 'Y-m-d',  $current_timestamp+86400+86400 );

    
    // Get Value Form After Submit 
    if( $type == 'booking' ){
        $room_check_in = isset( $_POST["room_check_in"] ) ? $_POST["room_check_in"] : $next_date;
        $room_check_out = isset( $_POST["room_check_out"] ) ? $_POST["room_check_out"] : $next2_date;
        $room_adults = isset( $_POST["room_adults"] ) ? $_POST["room_adults"] : 0;
        $room_childrens = isset( $_POST["room_childrens"] ) ? $_POST["room_childrens"] : 0;
        $room_rooms = isset( $_POST["room_rooms"] ) ? $_POST["room_rooms"] : 1;
    }else{
        $room_check_in = isset( $_GET["room_check_in"] ) ? $_GET["room_check_in"] : $next_date;
        $room_check_out = isset( $_GET["room_check_out"] ) ? $_GET["room_check_out"] : $next2_date;
        $room_adults = isset( $_GET["room_adults"] ) ? $_GET["room_adults"] : 0;
        $room_childrens = isset( $_GET["room_childrens"] ) ? $_GET["room_childrens"] : 0;
        $room_rooms = isset( $_GET["room_rooms"] ) ? $_GET["room_rooms"] : 1;
    }

    
    // Set Check-in default
    $checkin_default_day_digit = date_i18n( 'd', strtotime( $room_check_in ) );
    $checkin_default_year_month = date_i18n( 'F, Y', strtotime( $room_check_in ));
    $checkin_default_day_name = date_i18n( 'l', strtotime( $room_check_in ) );


    // Set Check-out default
    $checkout_default_day_digit = date_i18n( 'd', strtotime( $room_check_out ) );
    $checkout_default_year_month = date_i18n( 'F, Y', strtotime( $room_check_out ));
    $checkout_defaultday_name = date_i18n( 'l', strtotime( $room_check_out ) );

    // Total between 2 days
    $nights = total_between_2_days($room_check_in, $room_check_out );

    $method = 'GET';
    $action_url = home_url( '/' );
    if( $type == 'booking' ){
        global $wp;
        $action_url = home_url( $wp->request );
        $method = 'POST';
    }

    $html = '<form action="'.$action_url.'"  class="'.$class.' '.$style.' '.$type.' '. 'total_fields_'.$total_fields.' ovahotel_search row"  method="'.$method.'" enctype="multipart/form-data" data-mesg_required="'.esc_html__( 'This field is required.', 'ova-hotel' ).'">
            <div class="wrap-check-form"><div class="row">';
                $padding = $padding_ip = $bdr_0 = '';
                if( $show_night == 'true' ){
                    $padding = 'prl_columns';
                }
                if( $show_night_ipad == 'true'){
                    $padding_ip = 'prl_columns_ip';
                    $bdr_0 = 'border-right-0';
                }
                // Display Check-In
                if(($show_check_in == 'true')){
                $html .= '<div class="hotel_field '.$class_columns.' room_check-in '.$padding.' '.$padding_ip.'">
                    <label>'. esc_html__( 'Check-In', 'ova-hotel' ) .'</label>
                    <div class="hotel_field_date">
                        <input type="text" name="room_check_in" value="'.$room_check_in.'" autocomplete="off"  class=" datetpicker '.$is_req_check_in.' room_check_in" data-dateformat_popup="'.esc_attr( $date_format_popup ).'" data-dateformat_display="'.esc_attr( $date_format_display ).'" data-today_date="'.$today_date.'" />
                        <div class="show_date">
                            <div class="day_digit">'.$checkin_default_day_digit.'</div>
                            <div class="month_year">
                                <div class="m_y">'.$checkin_default_year_month.'</div>
                                <div class="day_name">'.$checkin_default_day_name.'</div>
                            </div>
                        </div>
                    </div>';
                $html .='</div>';
                }
                
                // Display Check-Out
                if( ($show_check_out == 'true')){
                $html .= '<div class="hotel_field '.$class_columns.' room_check-out '.$padding.' '.$padding_ip.'">
                    <label>'. esc_html__( 'Check-Out', 'ova-hotel' ) .'</label>
                    <div class="hotel_field_date">
                        <input type="text" name="room_check_out" value="'.$room_check_out.'" autocomplete="off"  class=" datetpicker '.$is_req_check_out.' room_check_out" data-dateformat_popup="'.esc_attr( $date_format_popup ).'" data-dateformat_display="'.esc_attr( $date_format_display ).'" data-today_date="'.$today_date.'" />
                        <div class="show_date">
                            <div class="day_digit">'.$checkout_default_day_digit.'</div>
                            <div class="month_year">
                                <div class="m_y">'.$checkout_default_year_month.'</div>
                                <div class="day_name">'.$checkout_defaultday_name.'</div>
                            </div>
                        </div>
                    </div>';
                $html .='</div>';
                }

                // Display Adults
                if( ($show_adults == 'true') ){
                    $html .= '<div class="hotel_field '.$class_columns.' col-ht room_adults '.$padding.' '.$padding_ip.'">
                    <label>'.esc_html__( 'Adults', 'ova-hotel' ).'</label>
                    <div class="room_infor d-flex flex-column">
                        <span class="amount">'.esc_html__( 'Amount', 'ova-hotel' ).'</span>
                        <span class="people">'.esc_html__( 'People', 'ova-hotel' ).'</span>
                    </div>
                    <select name="room_adults" class="'.$is_req_adults.'">';
                        $html .= '<option value="">0</option>';        
                        if( $max_adults > 0 ){
                            for ($i = 1; $i <= $max_adults; $i++  ) {
                                $html .= '<option value="'.$i.'" '.selected( $room_adults, $i, false ).' >'.$i.'</option>';        
                            }
                        }
                    $html .= '</select></div>';
                }
                               
                // Display Childrens
                if($show_childrens == 'true'){
                    $html .= '<div class="hotel_field '.$class_columns.' col-ht room_childrens '.$padding.' '.$padding_ip.'">
                        <label>'.esc_html__( 'Childrens', 'ova-hotel' ).'</label>
                        <div class="room_infor d-flex flex-column">
                            <span class="amount">'.esc_html__( 'Amount', 'ova-hotel' ).'</span>
                            <span class="people">'.esc_html__( 'People', 'ova-hotel' ).'</span>
                        </div>
                        <select name="room_childrens" class="'.$is_req_childrens.'">';
                        $html .= '<option value="">0</option>';
                        if( $max_childrens > 0 ){
                            for ($i = 1;  $i <= $max_childrens; $i++ ) {
                                $html .= '<option value="'.$i.'" '.selected( $room_childrens, $i, false ).' >'.$i.'</option>';        
                            }
                        }
                    $html .= '</select></div>';
                }

                // Display Rooms
                if($show_rooms == 'true'){
                $html .= '<div class="hotel_field '.$class_columns.' col-ht room_drawer '.$padding.' '.$padding_ip.' '.$bdr_0.'">
                    <label>'.esc_html__( 'Rooms', 'ova-hotel' ).'</label>
                    <div class="room_infor d-flex flex-column">
                        <span class="amount">'.esc_html__( 'Amount', 'ova-hotel' ).'</span>
                        <span class="people">'.esc_html__( 'Room', 'ova-hotel' ).'</span>
                    </div>
                    <select name="room_rooms" class="'.$is_req_rooms.'">';
                        if( $max_rooms > 0 ){
                            for ($i = 1; $i <= $max_rooms; $i++  ) {
                                $html .= '<option value="'.$i.'" '.selected( $room_rooms, $i, false ).' >'.$i.'</option>';        
                            }
                        }
                    $html .= '</select></div>';
                }

                // Display Night
                if($show_night == 'true'){

                $html .= '<div class="hotel_field '.$class_columns.' col-ht show_night '.$padding.'">
                    <label>'.esc_html__( 'Nights', 'ova-hotel' ).'</label>
                    <div class="room_nights">'.$nights.'</div></div>';
                }

                if($show_night_ipad == 'true'){

                $html .= '<div class="hotel_field '.$class_columns.' col-ht show_night_ip'.$padding.' '.$padding_ip.'">
                    <label>'.esc_html__( 'Nights', 'ova-hotel' ).'</label>
                    <div class="room_nights">'.$nights.'</div></div>';
                }

                // Submit
                $html .= '<div class="hotel_field col btn_search '.$class_btn_sc.'">
                            <span class="wrap_btn_2">
                                <button class="btn_tran submit" type="submit"><i class="'.$button_icon.'"></i>'.$button_text.'</button>
                            </span>
                        </div>';

                    

            $html .= '</div>  
            <div class="s_submit">
                <input type="hidden" name="post_type" value="product" />';
                if( $type == 'booking' ){

                    $html .= '<input type="hidden" name="ovahotel_booking" value="booking-room" />';

                    $html .= '<input type="hidden" name="room_id" value="'.$product_id.'" />';

                    $ovacrs_car_rental = 'ovacrs_car_rental';
                    $html .= '<input type="hidden" name="custom_product_type" value="'.$ovacrs_car_rental.'" />';

                    $html .= '<input type="hidden" name="add-to-cart" value="'.$product_id.'" />';

                    $html .= '<input type="hidden" name="quantity" value="1" />';

                    if($show_rooms == 'false'){
                        $html .= '<input type="hidden" name="room_rooms" value="1" />';
                    }

                }else{
                    $html .= '<input type="hidden" name="ovahotel_search" value="search_rooms" />';    
                    if($show_rooms == 'false'){
                        $html .= '<input type="hidden" name="room_rooms" value="1" />';
                    }
                }
                
                
            $html .= '</div>
            

        </div></form>';

    return $html;
}







// Account
add_shortcode('ovacrs_account', 'ovacrs_account');
function ovacrs_account($atts, $content = null) {

      $atts = extract( shortcode_atts(
        array(
            'login_link'  => '',
            'login_text'  => '',
            'register_link'  => '',
            'register_text'  => '',
            'show_slash' => true
        ), $atts) );

    $html = '<div class="ireca_account">';
    if( !is_user_logged_in() ){
        $html .= '<a href="'.$login_link.'">'.$login_text.'</a>';
        $html .= $show_slash ? '<span></span>' : '';
        $html .= '<a href="'.$register_link.'">'.$register_text.'</a>';    
    }else{
        $wp_current_user = wp_get_current_user();
        $html .=   '<a href='.get_edit_user_link().'>'.esc_html('Welcome ', 'ova-hotel').$wp_current_user->user_login.'</a>';
    }
    
    $html .= '</div>';

    return $html;

}


// Search Woo
add_shortcode('ovacrs_search_woo', 'ovacrs_search_woo');
function ovacrs_search_woo($atts, $content = null) {

      $atts = extract( shortcode_atts(
        array(
            'class'  => '',
        ), $atts) );
      ob_start();
?>
    <?php if(class_exists('Woocommerce')){ ?>
        <div class="ovacrs_searchwoo">
            <i class="icon_search"></i>
            <form role="search" method="get" class="woocommerce-product-search d-flex <?php echo esc_url($class); ?>" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                <label class="screen-reader-text"><?php _e( 'Search for:', 'ova-hotel' ); ?></label>
                <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search Products&hellip;', 'placeholder', 'ova-hotel' ); ?>" value="<?php echo get_search_query(); ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'ova-hotel' ); ?>" />
                <input type="submit" value="<?php echo esc_attr_x( 'Search', 'submit button', 'ova-hotel' ); ?>" />
                <input type="hidden" name="post_type" value="product" />
            </form>    
        </div>
        
    <?php } ?>
 <?php return ob_get_clean();

}









add_shortcode('ovacrs_list_cat', 'ovacrs_list_cat');
function ovacrs_list_cat($atts, $content = null) {

    $atts = extract( shortcode_atts(
    array(
      'child_of' => 0,
      'depth'   => 0,
      'exclude'  => '',
      'show_count' => 1,
      'hide_empty' => 0,
      'class' => '',
    ), $atts) );

     $args = array(
        'child_of'            => $child_of,
        'current_category'    => 0,
        'depth'               => $depth,
        'echo'                => 0,
        'exclude'             => $exclude,
        'exclude_tree'        => '',
        'feed'                => '',
        'feed_image'          => '',
        'feed_type'           => '',
        'hide_empty'          => $hide_empty,
        'hide_title_if_empty' => false,
        'hierarchical'        => true,
        'order'               => 'ASC',
        'orderby'             => 'name',
        'separator'           => '<br />',
        'show_count'          => $show_count,
        'show_option_all'     => '',
        'show_option_none'    => __( 'No categories' ),
        'style'               => 'list',
        'taxonomy'            => 'product_cat',
        'title_li'            => '',
        'use_desc_for_title'  => 1,
    );

    $html = '<ul class="rental_list '.$class.'">';
        $html .= wp_list_categories($args);
    $html .= '</ul>';

    return $html;
    
    
}









