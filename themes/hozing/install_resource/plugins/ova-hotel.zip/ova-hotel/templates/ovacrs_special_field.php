<tr class="tr_rt_special">

	<td width="30%">
      <input type="text" name="ovacrs_specials_icon[]" placeholder="<?php esc_html_e( 'Icon', 'ova-hotel' ); ?>" value="" />
    </td>

    <td width="40%">
      <input type="text" name="ovacrs_specials_label[]" placeholder="<?php esc_html_e( 'Label', 'ova-hotel' ); ?>" value="" />
    </td>

    <td width="19%">
      <select  name="ovacrs_specials_featured[]" class="short_dura">
    		<option value="yes" ><?php esc_html_e( 'Yes', 'ova-hotel' ); ?></option>
    		<option value="no"  ><?php esc_html_e( 'No', 'ova-hotel' ); ?></option>
    	</select>
    </td>
    
    <td width="10%"><a href="#" class="delete_special">x</a></td>
    
</tr>