<tr class="row_rt_record" data-pos="">

    <td width="15%">
        <input type="text"  placeholder="<?php esc_html_e('Price', 'ova-hotel'); ?>" name="ovacrs_rt_price[]" value="" class="ovacrs_rt_price"/>
    </td>

    

    <td width="20%">
      <input type="text" name="ovacrs_rt_startdate[]" value="" class="ovacrs_rt_startdate datepicker " placeholder="<?php esc_html_e( 'From YYYY-MM-DD', 'ova-hotel' ); ?>" autocomplete="off"/>
    </td>

    <td width="20%">
      <input type="text" name="ovacrs_rt_enddate[]" value="" class="ovacrs_rt_enddate datepicker " placeholder="<?php esc_html_e( 'End YYYY-MM-DD', 'ova-hotel' ); ?>" autocomplete="off"/>
    </td>


    <td width="39%">
    	<table width="100%" class="ovacrs_rt_discount">
	      	<thead>
				<tr>
					<th><?php esc_html_e( 'Price', 'ova-hotel' ); ?></th>
					<th><?php esc_html_e( 'Length of Stay (Night)', 'ova-hotel' ); ?></th>
				</tr>
			</thead>

			<tbody class="real">

			</tbody>

			<tfoot>
				
					<tr>
						<th colspan="6">
							<a href="#" class="button insert_rt_discount">
								<?php esc_html_e( 'Add PST', 'ova-hotel' ); ?>
								<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_rt_discount.php' ); ?>
							</a>
						</th>
					</tr>
				
				
			</tfoot>

      	
      	</table>
    </td>


    <td width="1%"><a href="#" class="delete_rt">x</a></td>
</tr>