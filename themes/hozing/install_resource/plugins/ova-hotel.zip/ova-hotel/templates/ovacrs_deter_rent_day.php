<br>
<span><?php esc_html_e( '1 day = 24 hours', 'ova-hotel' ); ?></span>

