<?php
/*
Plugin Name: Ovatheme Hotel Plugin
Plugin URI: http://ovatheme.com
Description: Hotel Plugin developed by Ovatheme
Author: Ovatheme
Version: 1.1.2
Author URI: http://ovatheme.com
Text Domain: ova-hotel
Domain Path: /languages/
*/
if ( !defined( 'ABSPATH' ) ) exit();


if( !class_exists( 'OVACRS' ) ){

	 class OVACRS{

		/**
		 * OVACRS Constructor
		 */

		public function __construct(){
			
				$this->define_constants();
				$this->includes();
				add_action('init',array($this, 'hozing_manage_booking' ) );

		}


		/**
		 * Define constants
		 */
		public function define_constants(){
			define( 'OVACRS_PLUGIN_FILE', __FILE__ );
			define( 'OVACRS_PLUGIN_URI', plugin_dir_url( __FILE__ ) );
			define( 'OVACRS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
			load_plugin_textdomain( 'ova-hotel', false, basename( dirname( __FILE__ ) ) .'/languages' ); 
		}

		


		/**
		 * Include files
		 */

		public function includes(){

			if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
					
				
			// Funciton
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-functions.php' );

			// Loader Template
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-load-temp.php' );

			// Customize
			require_once( OVACRS_PLUGIN_PATH.'/customize/register-customize.php' );


			

			// Add Js Css
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-assets.php' );
			
			// Make Custom Product Type WooCommerce
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-admin-woo.php' );
			
			// Cart
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-cart.php' );

			// Calculate Before add to cart
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-cus-cal-cart.php' );

			// Get order
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-get-data.php' );
			

			// Filter name
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs_filters.php' );


			// Shortcode
			require_once( OVACRS_PLUGIN_PATH.'/shortcodes/shortcodes.php' );
			

			// Add field to category
			require_once( OVACRS_PLUGIN_PATH.'/inc/ovacrs-add-field-woocat.php' );

			}

			
			
				
		}

		public function hozing_manage_booking(){
			if( current_user_can( 'administrator' ) ){
				require_once( OVACRS_PLUGIN_PATH.'/admin/init.php' );
			}
		}


	}
}

new OVACRS();


?>
