<?php

namespace ova_framework;

use ova_framework\widgets\ova_menu;
use ova_framework\widgets\ova_button;
use ova_framework\widgets\ova_logo;
use ova_framework\widgets\ova_heading;
use ova_framework\widgets\ova_menu_canvas;

use ova_framework\widgets\ova_instagram;
use ova_framework\widgets\ova_blog_slide;
use ova_framework\widgets\ova_search;
use ova_framework\widgets\ova_contact_us;
use ova_framework\widgets\ova_language;
use ova_framework\widgets\ova_social;
use ova_framework\widgets\ova_room_slider;
use ova_framework\widgets\ova_room_category;
use ova_framework\widgets\ova_room_images;
use ova_framework\widgets\ova_room_search;
use ova_framework\widgets\ova_header;
use ova_framework\widgets\ova_offers_1;
use ova_framework\widgets\ova_offers_countdown;
use ova_framework\widgets\ova_offers_3;
use ova_framework\widgets\ova_offers_4;
use ova_framework\widgets\ova_offers_5;
use ova_framework\widgets\ova_slideshow;
use ova_framework\widgets\ova_info_footer;
use ova_framework\widgets\ova_logo_footer;
use ova_framework\widgets\ova_copyright;
use ova_framework\widgets\ova_show_on_map;
use ova_framework\widgets\ova_line;
use ova_framework\widgets\ova_menu_footer;

use ova_framework\widgets\ova_blog;
use ova_framework\widgets\ova_blog_slider;
use ova_framework\widgets\ova_blog_half_layout;

use ova_framework\widgets\ova_service_1;
use ova_framework\widgets\ova_service_tab;
use ova_framework\widgets\ova_service_slider;
use ova_framework\widgets\ova_service_image;
use ova_framework\widgets\ova_service_box;

use ova_framework\widgets\ova_about;
use ova_framework\widgets\ova_about_type_2;
use ova_framework\widgets\ova_about_coloumn;

use ova_framework\widgets\ova_testimonial;
use ova_framework\widgets\ova_icon_hozing;

use ova_framework\widgets\ova_info_contact;

use ova_framework\widgets\ova_price_table;



if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly




/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class Ova_Register_Elementor {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {
		$this->add_actions();
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function add_actions() {

		// Register Header Footer Category in Pane
	    add_action( 'elementor/elements/categories_registered', array( $this, 'add_hf_category' ) );

	     // Register Ovatheme Category in Pane
	    add_action( 'elementor/elements/categories_registered', array( $this, 'add_ovatheme_category' ) );
	    
		
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );
		

	}

	
	public  function add_hf_category(  ) {
	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'hf',
	        [
	            'title' => __( 'Header Footer', 'ova-framework' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	}

	
	public function add_ovatheme_category(  ) {

	    \Elementor\Plugin::instance()->elements_manager->add_category(
	        'ovatheme',
	        [
	            'title' => __( 'Ovatheme', 'ova-framework' ),
	            'icon' => 'fa fa-plug',
	        ]
	    );

	}


	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function on_widgets_registered() {
		$this->includes();
		$this->register_widget();
	}

	/**
	 * Includes
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function includes() {
		
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-menu.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-button.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-logo.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_heading.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_instagram.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_blog_slide.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_search.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_contact_us.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_language.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_social.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_offers_1.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_offers_countdown.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_offers_3.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_offers_4.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_offers_5.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_slideshow.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_room_slider.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_room_category.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_room_images.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_room_search.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_info_footer.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_logo_footer.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_copyright.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_show_on_map.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_line.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_menu_footer.php';
		
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-menu-canvas.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-header.php';

		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-blog.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_blog_slider.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-blog-half-layout.php';

		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-service.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_service_tab.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_service_slider.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-service-image.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-service-box.php';

		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-about.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-about-type-2.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-about-coloumn.php';

		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_testimonial.php';
		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova-icon-hozing.php';

		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_info_contact.php';

		require OVA_PLUGIN_PATH . 'ova-elementor/widgets/ova_price_table.php';
		
	}

	/**
	 * Register Widget
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function register_widget() {

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_menu() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_logo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_button() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_heading() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_menu_canvas() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_instagram() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_blog_slide() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_search() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_contact_us() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_language() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_social() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_room_slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_room_category() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_room_images() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_room_search() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_header() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_offers_1() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_offers_countdown() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_offers_3() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_offers_4() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_offers_5() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_slideshow() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_info_footer() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_logo_footer() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_copyright() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_show_on_map() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_line() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_menu_footer() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_blog() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_blog_slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_blog_half_layout() );
		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_service_1() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_service_tab() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_service_slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_service_image() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_service_box() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_about() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_about_type_2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_about_coloumn() );
		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_testimonial() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_icon_hozing() );
		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_info_contact() );
		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ova_price_table() );
	}
	    
	

}

new Ova_Register_Elementor();





