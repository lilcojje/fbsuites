<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class ova_room_slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'ova_room_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Room Slider', 'ova-framework' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-product-images';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ovatheme' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

	protected function _register_controls() {

		$categories = get_categories(
                array(
                'type'                     => 'product',
                'child_of'                 => 0,
                'parent'                   => '',
                'orderby'                  => 'name',
                'order'                    => 'ASC',
                'hide_empty'               => 1,
                'hierarchical'             => 1,
                'exclude'                  => '',
                'include'                  => '',
                'number'                   => '',
                'taxonomy'                 => 'product_cat',
                'pad_counts'               => false 

              )
     	);
		$term_ids = array();
		if ($categories) {
			foreach ( $categories as $cate ) {				
				$key = get_term_meta( $cate->term_id, 'ovacrs_cat_dis', true );
			    if( $key == 'hotel' ) {
			        $term_ids[$cate->slug] = $cate->cat_name;
			    }
			}
		}

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			
			$this->add_control(
				'category',
				[
					'label'       => __( 'Select Room Category', 'ova-framework' ),
					'type'        => Controls_Manager::SELECT,
					'default'     => '',
					'options'     => $term_ids,
					'description' => __( 'Select Room Category', 'ova-framework' ),
				]
			);

			$this->add_control(
				'order',
				[
					'label'   => __( 'Order', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'DESC',
					'options' => [
						'DESC' => __( 'Decrease', 'ova-framework' ),
						'ASC'  => __( 'Ascending', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'total_items_cat',
				[
					'label'       => __( 'Total items in each category', 'ova-framework' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Insert -1 to display all items in category', 'ova-framework' ),
					'min'         => -1,
					"default"     => 100
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_product',
			[
				'label' => __( 'Product Settings', 'ova-framework' ),
			]
		);

			$this->add_control(
				'product_style',
				[
					'label'   => __( 'Product Style', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'style1',
					'options' => [
						'style1' => __( 'Style 1', 'ova-framework' ),
						'style2' => __( 'Style 2', 'ova-framework' ),
						'style3' => __( 'Style 3', 'ova-framework' ),
						'style4' => __( 'Style 4', 'ova-framework' ),
						'style5' => __( 'Style 5', 'ova-framework' ),
						'style6' => __( 'Style 6', 'ova-framework' ),
						'style7' => __( 'Style 7', 'ova-framework' ),
					],

				]
			);

			$this->add_control(
				'text_background',
				[
					'label' => __('Text Background', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'default' => 'C',
					'condition' => [
						'product_style' => 'style6'
					]
				]
			);

			$this->add_control(
				'total_columns_slide',
				[
					'label'   => __( 'Desktop: Total item each slide', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => '2',
					'options' => [
						'1' => __('1 items', 'ova-framework'),
						'2' => __( '2 items', 'ova-framework' ),
						'3' => __( '3 items', 'ova-framework' ),
						'4' => __( '4 items', 'ova-framework' ),
					],
					'condition' => [
						'product_style!' => ['style3','style6'],  
					]
				]
			);

			$this->add_control(
				'items_ipad',
				[
					'label'   => __( 'Ipad: Total item each slide', 'ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => '2',
					'options' => [
						'1' => __( '1 items', 'ova-framework'),
						'2' => __( '2 items', 'ova-framework'),
						'3' => __( '3 items', 'ova-framework'),
						'4' => __( '4 items', 'ova-framework'),
					],
					'condition' => [
						'product_style!' => ['style3','style6'],

					]
				]
			);

			$this->add_control(
				'items_mobile',
				[
					'label'   => __( 'Mobile: Total item each slide', 'ova-framework'),
					'type'    => Controls_Manager::SELECT,
					'default' => '1',
					'options' => [
						'1' => __( '1 items', 'ova-framework'),
						'2' => __( '2 items', 'ova-framework'),
						'3' => __( '3 items', 'ova-framework'),
						'4' => __( '4 items', 'ova-framework'),
					],
					'condition' => [
						'product_style!' => ['style3','style6'],
					]
				]
			);

			$this->add_control(
				'total_items_column',
				[
					'label'   => __( 'Total items in each column', 'ova-framework' ),
					'type'    => Controls_Manager::NUMBER,
					'min'     => 1,
					'default' => 1,
					'condition' => [
						'product_style' => 'style3',
					]
				]
			);

			$this->add_control(
				'show_price',
				[
					'label'   => __( 'Show Price', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'show_acreage',
				[
					'label'   => __( 'Show Acreage', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'show_special_info',
				[
					'label'   => __( 'Show Special Info', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'product_style!' => 'style6'
					]

				]
			);

			$this->add_control(
				'number_show_special',
				[
					'label' => __( 'Show Special Number', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'default' => 2,
					'condition' => [
						'show_special_info' => 'true',
						'product_style!'    => 'style6'
					]
				]
			);

			$this->add_control(
				'show_adults_max',
				[
					'label'   => __( 'Show Adults Max', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'false',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);
			
			$this->add_control(
				'show_childrens_max',
				[
					'label'   => __( 'Show Childrens Max', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'false',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'show_amenities_featured',
				[
					'label'   => __( 'Show Amenities Featured', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'number_show_amenities',
				[
					'label' => __( 'Amenities Featured Number', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'default' => 4,
					'condition' => [
						'show_amenities_featured' => 'true'
					]
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_slider',
			[
				'label' => __( 'Slider Settings', 'ova-framework' ),
			]
		);

			$this->add_control(
				'margin_items',
				[
					'label' => __( 'Margin Right Items', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 30,
				]
				
			);

			$this->add_control(
				'arows_control',
				[
					'label' => __('Show Navigation', 'ova-framework'),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
				]
			);

			$this->add_control(
				'dots_control',
				[
					'label'   => __('Show Paging', 'ova-framework'),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);


			$this->add_control(
				'pause_on_hover',
				[
					'label'   => __( 'Pause on Hover', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'   => __( 'Autoplay', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label'     => __( 'Autoplay Speed', 'ova-framework' ),
					'type'      => Controls_Manager::NUMBER,
					'default'   => 5000,
					'condition' => [
						'autoplay' => 'yes',
					]
				]
			);

			$this->add_control(
				'infinite',
				[
					'label'   => __( 'Infinite Loop', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);

			$this->add_control(
				'smartspeed',
				[
					'label'   => __( 'Smart Speed', 'ova-framework' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500
				]
			);

			$this->add_control(
				'slideby',
				[
					'label' => __( "Navigation slide by x. 'page' string can be set to slide by page.", 'ova-framework' ),
					'type'  => Controls_Manager::NUMBER,
					'description' => __( 'Example: 1', 'ova-framework' ),
					'default'     => '1'
				]
			);

			$this->add_control(
				'nav_prev',
				[
					'label' => __( 'Prev Navigation', 'ova-framework' ),
					'type'  => Controls_Manager::TEXT,
					'default'     => '<i class="arrow_carrot-left"></i>'
				]
			);

			$this->add_control(
				'nav_next',
				[
					'label' => __( 'Next Navigation', 'ova-framework' ),
					'type'  => Controls_Manager::TEXT,
					'default'     => '<i class="arrow_carrot-right"></i>'
				]
			);

			$this->add_control(
				'center',
				[
					'label'   => __( 'Center', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'product_style' => 'style7'
					]
				]
			);


		$this->end_controls_section();

		// SEtting Tabs Style

		$this->start_controls_section(
			'section_background_text',
			[
				'label' => __( 'Text Background', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'product_style' => 'style6',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_bgr_typography',
				'selector' => '{{WRAPPER}} .hozing_product_slider.style6 .text-background .second_font',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'text_bgr_color',
			[
				'label' => __( 'Text Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider.style6 .text-background .second_font' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_bgr_opacity',
			[
				'label' => __( 'Text Opacity', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => "0.1",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider.style6 .text-background .second_font' => 'opacity : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_brg_fontsize',
			[
				'label' => __( 'Font Size', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 300,
				],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider.style6 .text-background .second_font' => 'font-size: {{SIZE}}{{UNIT}};'
				],
			]
		);

		$this->add_control(
			'text_brg_position',
			[
				'label' => __( 'Position', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 90,
				],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider.style6 .text-background' => 'left: calc(100% + -{{SIZE}}{{UNIT}});',
				],
			]
		);


		$this->end_controls_section(); 

		$this->start_controls_section(
			'section_room_navigation',
			[
				'label' => __( 'Navigation', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'arows_control' => 'yes',
					'product_style!' => 'style6'
				],
			]
		);
			

			$this->add_control(
				'room_navigation_fontsize_',
				[
					'label' => __( 'Font Size Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next' => 'font-size: {{SIZE}}{{UNIT}}!important;',
					],
				]
			);

			$this->add_control(
				'room_navigation_position',
				[
					'label' => __( 'Position Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 300,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev' => 'left: -{{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next' => 'right: -{{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'room_navigation_width_height',
				[
					'label' => __( 'Width And Height Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'room_navigation_border_radius',
				[
					'label' => __( 'Border Radius Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'room_navigation_color',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'room_navigation_hover_color',
				[
					'label' => __( 'Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'room_navigation_background_color',
				[
					'label' => __( 'Background Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next' => 'background-color : {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'room_navigation_background_hover_color',
				[
					'label' => __( 'Background Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .hozing_product_slider .owl-carousel .owl-nav .owl-next:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_dots',
			[
				'label' => __( 'Paging', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'dots_control!' => '',
				],
			]
		);
			

			$this->add_control(
				'room_dots_fontsize_',
				[
					'label' => __( 'Font Size Paging', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 100,
						],
					],

					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot span:before' => 'font-size: {{SIZE}}{{UNIT}}!important;',
					],
				]
			);

			$this->add_control(
				'room_dots_width_height',
				[
					'label' => __( 'Width And Height Paging', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'condition' => [
						'product_style!' => 'style1'
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'room_dots_border_radius',
				[
					'label' => __( 'Border Radius Paging', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'condition' => [
						'product_style!' => 'style1'
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot span' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'room_dots_color',
				[
					'label' => __( 'Color Paging', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot span' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'room_dots_active_color',
				[
					'label' => __( 'Color Paging Active', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot.active span' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'room_dots_hover_color',
				[
					'label' => __( 'Color Hover Paging', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot span:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'room_dots_background_color',
				[
					'label' => __( 'Background Color Paging', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'condition' => [
						'product_style!' => 'style1'
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot span' => 'background-color : {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'room_dots_background_hover_color',
				[
					'label' => __( 'Background Color Hover Paging', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'condition' => [
						'product_style!' => 'style1'
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot span:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'room_dots_border_color',
				[
					'label' => __( 'Border Color Paging', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'condition' => [
						'product_style!' => 'style1'
					],
					'selectors' => [
						'{{WRAPPER}} .hozing_product_slider .owl-dots .owl-dot.active span' => 'border-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_room_typography',
				'selector' => '{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content h3.second_font',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_room_color',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content h3.second_font a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_room_hover_color',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content h3.second_font a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_room_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content h3.second_font' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_room_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content h3.second_font' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_price',
			[
				'label' => __( 'Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_room_typography',
				'selector' => '{{WRAPPER}} .hozing_product_slider .rental_item .border-box .amount',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'price_room_color',
			[
				'label' => __( 'Price Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .amount' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'price_room_hover_color',
			[
				'label' => __( 'Price Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .amount:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_info',
			[
				'label' => __( 'Room Info', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'info_room_typography',
				'selector' => '{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content ul.specical-infor li span',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'info_room_color',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content ul.specical-infor li span' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'info_room_hover_color',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content ul.specical-infor li span:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'info_room_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content ul.specical-infor li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'info_room_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content ul.specical-infor li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_excerpt_room',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_room_typography',
				'selector' => '{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_room_color',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_room_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_romm_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_amenities_featured_room',
			[
				'label' => __( 'Amenities Featured', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'amenities_featured_room_color',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content .features .feature-item' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'amenities_featured_room_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content .features .feature-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'amenities_featured_romm_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .content .features .feature-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_booking_bt',
			[
				'label' => __( 'Button Booking', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'booking_bt_room_typography',
				'selector' => '{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'booking_bt_color',
			[
				'label' => __( 'Button Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'booking_bt_hover_color',
			[
				'label' => __( 'Button Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'booking_bt_background',
			[
				'label' => __( 'Button Background', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a' => 'background : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'booking_bt_background_hover',
			[
				'label' => __( 'Button Background Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a:hover' => 'background : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'booking_bt_border_color',
			[
				'label' => __( 'Button Border Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a' => 'border-color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'booking_bt_border_hover_color',
			[
				'label' => __( 'Button Border Hover Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a:hover' => 'border-color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'booking_bt_room_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'booking_bt_room_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_product_slider .rental_item .border-box .discorver a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
	?>
		<?php $settings = $this->get_settings(); ?>

        <div class="woocommerce hozing_wrap_product">
        	<div class="<?php if( $settings['product_style'] != 'style7'){ echo 'container';} else { echo 'room_style7';}?>">

				<?php 
		            $args_room = array(
						'post_type'   => 'product',
						'post_status' => 'publish',
						'tax_query'   => array(
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'slug',
								'terms'    => $settings['category'],
							)
						),
						'posts_per_page' => $settings['total_items_cat'],
						'order'          => $settings['order'],
		            );

		            $hozing_products = new \WP_Query($args_room); 

	            ?>

	          	<div class="hozing_product_slider <?php echo $settings['product_style'];?>">
	          		<?php if( $settings['product_style'] == 'style6' && $settings['text_background'] != '' ){?>
	          		<div class="text-background">
	          			<span class="second_font"><?php echo $settings['text_background']; ?></span>
	          		</div>
	          		<?php } ?>
	          	<?php
	          		if( $settings['product_style'] == 'style3' || $settings['product_style'] == 'style6'){
						$data_option['total_columns_slide'] =  absint(1);
						$data_option['items_ipad'] =  absint(1);
						$data_option['items_mobile'] =  absint(1);
	          		}else{
	          			$data_option['total_columns_slide'] = absint( $settings['total_columns_slide'] ); 
	          			$data_option['items_ipad']          = absint( $settings['items_ipad'] ); 
						$data_option['items_mobile']        = absint( $settings['items_mobile'] ); 
	          		}					
					
					$data_option['smartSpeed']          = absint( $settings['smartspeed'] );
					$data_option['margin']              = absint( $settings['margin_items'] ); 
					$data_option['loop']                =  ( $settings['infinite'] == 'yes') ? true : false;
					$data_option['autoplay']            =  ( $settings['autoplay'] == 'yes') ? true : false;
					$data_option['autoplayTimeout']     = absint( $settings['autoplay_speed'] );
					$data_option['autoplayHoverPause']  =  ( $settings['pause_on_hover'] == 'yes') ? true : false;
					$data_option['dots']                =  ( $settings['dots_control'] == 'yes') ? true : false;
					
					if( $settings['product_style'] == 'style6'){
						$data_option['nav'] = true;
					}else{
						$data_option['nav']            	=  ( $settings['arows_control'] == 'yes') ? true : false;
					}

					$data_option['slideBy']             = absint( $settings['slideby'] );
					$data_option['prev'] = $settings['nav_prev'];
					$data_option['next'] = $settings['nav_next'];

					if( $settings['product_style'] == 'style7'){
						$data_option['center'] = $settings['center'];
					}


					$data_option_encode = wp_json_encode($data_option);

	          	?>	
	        		<div class="owl-carousel owl-theme" data-options="<?php echo esc_attr($data_option_encode);?>">
						<?php
							$count = 0;
							$group_slide = $t_items_cat = 1; 
		                  	if( $hozing_products->have_posts() ): while( $hozing_products->have_posts() ):  $hozing_products->the_post();

		                        global $product;

		                    	$img  = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
		                		$img_hozing_list  = wp_get_attachment_image_url( get_post_thumbnail_id(), 'hozing_list' );
								$img_hozing_m  = wp_get_attachment_image_url( get_post_thumbnail_id(), 'hozing_m' );
								$hozing_room_suits  = wp_get_attachment_image_url( get_post_thumbnail_id(), 'hozing_room_suits' );

		            	?>
		            	<?php 
	                    if( $settings['product_style'] == 'style3'){ 
	                    	if( $group_slide == $settings['total_items_column'] + 1 ){ $group_slide = 1; }   
	                        if( $group_slide == 1 ){ ?>
	                            <div class="rental_item item product_room_list">
	                        <?php }
	                    }else{ ?>
							<div class="rental_item item <?php if( $settings['product_style'] == 'style1'){ echo 'colums_no_sidebar_2v1'; }elseif( $settings['product_style'] == 'style2'){ echo 'colums_no_sidebar_2v2';}elseif( $settings['product_style'] == 'style3'){ echo 'product_room_list';}elseif($settings['product_style'] == 'style4'){echo 'colums_no_sidebar_3v2';}elseif( $settings['product_style'] == 'style5'){ echo 'colums_no_sidebar_3v1';} elseif($settings['product_style'] == 'style6'){ echo 'room_suits';}elseif( $settings['product_style'] == 'style7'){ echo 'room_style7';} ?> item-<?php echo $count; ?>"> <?php } ?>
							    
							    <?php if( $settings['product_style'] == 'style3'){
								    if($count %2 == 0){
								        echo '<div class="border-box d-lg-inline-flex d-xl-inline-flex flex-row" >';
								    }else{
								        echo '<div class="border-box d-lg-inline-flex d-xl-inline-flex flex-row-reverse" >';
								    }
							    }else{ ?>
							    <div class="border-box">
							    <?php } ?>
							        <div class="wrap_img <?php if( $settings['product_style'] == 'style3'){ echo 'col-lg-6 col-md-12';} ?>">
							            <div class="images_thumb">

							            	<?php if( $settings['product_style'] == 'style1' || $settings['product_style'] == 'style2' || $settings['product_style'] == 'style3' || $settings['product_style'] == 'style4' || $settings['product_style'] == 'style5'){ ?>
							               		<img src="<?php echo esc_url( $img ); ?>" alt="<?php the_title();?>" srcset="<?php echo esc_url( $img_hozing_m ); ?> 600w" sizes="(max-width: 600px) 100vw, 600px" >
					           		 		<?php } ?>

							                <?php if( $settings['product_style'] == 'style6'){ ?>
												<img src="<?php echo esc_url( $img ); ?>" alt="" >
							                <?php } ?>

											<?php if( $settings['product_style'] == 'style7'){ ?>
												<img src="<?php echo $img; ?>" alt="" >
											<?php } ?>

							            </div>
							            <?php 
							            	if( $settings['product_style'] == 'style6'){ ?> 
												<div class="enjoy_now">
													<span><?php esc_html_e( 'Enjoy now', 'ova-framework' );?></span>
												</div>
						            		<?php }
							            ?>
							            <?php if ( $settings['product_style'] == 'style1' || $settings['product_style'] == 'style2' || $settings['product_style'] == 'style3' || $settings['product_style'] == 'style4' || $settings['product_style'] == 'style5') : ?>
							            <?php if( $settings['show_price'] == 'true') { ?> 
								            <div class="price_night">               
								                <span class="wrap_content">
								                	<?php if( $settings['product_style'] == 'style1' || $settings['product_style'] == 'style3' || $settings['product_style'] == 'style4' || $settings['product_style'] == 'style5'){?>
									                    <span class="time-night"><?php esc_html_e( 'From:', 'ova-framework' ); ?></span>
									                    <?php echo wp_kses_post( $product->get_price_html() ); ?>
									                    <span class="time-night"><?php esc_html_e( '/ Night', 'ova-framework' ); ?></span>
								                	<?php } ?>
								                	<?php if( $settings['product_style'] == 'style2'){?>
									                    <span class="time-night"><?php esc_html_e( 'Price Only:', 'ova-framework' ); ?></span>
	                    								<?php echo wp_kses_post( $product->get_price_html() ); ?>
								                	<?php } ?>
								                </span>              
								            </div>
								        <?php } ?>
							            <?php endif; ?>
							            <?php if( $settings['product_style'] == 'style2'){ ?>
								            <?php if( get_theme_mod( 'rl_type_show_button', 'true' ) == 'yes') : ?>
								            <div class="discorver">
								                <a href="<?php the_permalink(); ?> " class="discover-now">
								                    <span class="text"><?php esc_html_e( 'Book Now', 'ova-framework' ); ?></span>
								                </a>
								            </div>
								            <?php endif; ?>
										<?php } ?>

							        </div> <!-- End wrap_img -->

							        <div class="content <?php if( $settings['product_style'] == 'style3'){ echo 'col-lg-6 col-md-12';} ?>">
										<?php if( $settings['product_style'] == 'style6'){ ?>
										<div class="enjoy_now">
											<span><?php esc_html_e( 'Enjoy now', 'ova-framework' );?></span>
										</div>
										<?php if( $settings['show_price'] == 'true') : ?>
										<div class="price_night">               
							                <span class="wrap_content">
							                    <?php echo wp_kses_post( $product->get_price_html() ); ?>
							                    <span class="time-night"><?php esc_html_e( 'Night', 'ova-framework' ); ?></span>
							                </span>              
							            </div>
							        	<?php endif; ?>
										<?php } ?>
							            <h3 class="second_font"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							            <?php if( $settings['product_style'] == 'style7'){ ?>
											<div class="wrap-content">
											<?php if( $settings['show_price'] == 'true') { ?> 
									                           
									                <span class="price">
									                	<?php echo wp_kses_post( $product->get_price_html() ); ?>
									                </span>              
									            
									        <?php } ?>

									        <?php 
									        $ovacrs_car_acreage = get_post_meta( get_the_id(), 'ovacrs_car_acreage', true );

									        if( $settings['show_acreage'] == 'true'){
							                    if ( $ovacrs_car_acreage != '') : ?>
							                    <span class="acreage"><?php echo $ovacrs_car_acreage;?></span>

							                    <?php endif;
							                } ?>
											</div>
							           <?php }
							            ?>
							            <?php 
							                $ovacrs_car_acreage = get_post_meta( get_the_id(), 'ovacrs_car_acreage', true );
							                $ovacrs_car_max_adults = get_post_meta( get_the_id(), 'ovacrs_car_max_adults', true );
							                $ovacrs_car_max_childrens = get_post_meta( get_the_id(), 'ovacrs_car_max_childrens', true );

							                $ovacrs_specials_featured = get_post_meta( get_the_id(), 'ovacrs_specials_featured', true );
							                $ovacrs_specials_label = get_post_meta( get_the_id(), 'ovacrs_specials_label', true );

							                $number_show_special = absint( $settings['number_show_special'] );
							            ?>
							            <?php if($settings['product_style'] == 'style6') : ?>
											<p><?php echo wp_trim_words( get_the_excerpt(),20,'' ); ?></p>
							            <?php endif; ?>
							            <?php if( $settings['product_style'] == 'style1' || $settings['product_style'] == 'style2' || $settings['product_style'] == 'style3' || $settings['product_style'] == 'style4' || $settings['product_style'] == 'style5') : ?>
							            <ul class="specical-infor">
							                <?php if( $settings['show_acreage'] == 'true'){
							                    if ( $ovacrs_car_acreage != '') : ?>
							                    <li class="d-inline-flex"><span>
							                        <?php echo $ovacrs_car_acreage;?></span></li><?php endif;} ?>
							                <?php if( $settings['show_adults_max'] == 'true'){ 
							                    if ( $ovacrs_car_max_adults != '' ) : ?>
							                    <li class="d-inline-flex"><span>
							                        <?php echo $ovacrs_car_max_adults;?>
							                        <?php esc_html_e( 'Adults', 'ova-framework' ); ?></span></li><?php endif;} ?>
							                <?php if( $settings['show_childrens_max'] == 'true'){
							                    if ( $ovacrs_car_max_childrens != '' ) : ?>
							                    <li class="d-inline-flex"><span>
							                        <?php echo $ovacrs_car_max_childrens;?>
							                        <?php esc_html_e( 'Childrens', 'ova-framework' ); ?></span></li><?php endif;} ?>
							                <?php
							                $item_specials = 0;
							                if( $settings['show_special_info'] == 'true' ) :  
							                    if( $ovacrs_specials_featured ){
							                        
							                        foreach ($ovacrs_specials_featured as $key => $value) {
							                            if( $value == 'yes' && trim( $ovacrs_specials_label[$key] ) != '' ){
								                            ?>                               
								                            <li class="d-inline-flex">
								                                <span class="label"><?php echo esc_attr( $ovacrs_specials_label[$key] ); ?></span>
								                            </li>
								                            <?php $item_specials++;                                     
							                            }
							                            if( $item_specials >= $number_show_special){
							                            	break;
							                            }
							                        }                            
							                    }
							                endif;        
							                ?>
							            </ul>
							        	<?php endif; ?>
										<?php if( $settings['product_style'] == 'style1' || $settings['product_style'] == 'style2' || $settings['product_style'] == 'style3' || $settings['product_style'] == 'style4' || $settings['product_style'] == 'style5') : ?>
							            	<p><?php echo wp_trim_words( get_the_excerpt(),20,'' ); ?></p>
							        	<?php endif; ?>
							            <?php if( $settings['product_style'] == 'style1'){ ?>
								            <?php if( get_theme_mod( 'rl_type_show_button', 'true' ) == 'yes') : ?>
								            <div class="discorver">
								                <a href="<?php the_permalink(); ?> " class="discover-now">
								                    <span class="text"><?php esc_html_e( 'Discover Now', 'ova-framework' ); ?></span>
								                </a>
								            </div>
								            <?php endif; ?>
										<?php } ?>
										<?php if( $settings['product_style'] == 'style1' || $settings['product_style'] == 'style2' || $settings['product_style'] == 'style3' || $settings['product_style'] == 'style4' || $settings['product_style'] == 'style5' || $settings['product_style'] == 'style6' ) : ?>
							            <?php if( $settings['show_amenities_featured'] == 'true' ) : ?>
							            <div class="features">
							                <div class="container-fluid">
							                    <div class="row">

							                        <?php
							                        $features = get_post_meta( get_the_id(), 'ovacrs_features_special', true );
							                        $icon = get_post_meta( get_the_id(), 'ovacrs_features_icons', true );
							                        $label = get_post_meta( get_the_id(), 'ovacrs_features_label', true );
							                       	$number_show_amenities = absint( $settings['number_show_amenities'] );
							                        $d = 0;
							                        
							                        if( $features ){
							                            foreach ($features as $key => $value) {
							                                if( $value == 'yes' && trim( $icon[$key] ) != '' && trim( $label[$key] ) != '' ){
							                                    $class = ($d%2) ? 'eve' : 'odd'; ?>
							                                    <div class="feature-item <?php echo esc_attr( $class ); ?> ">
							                                        <i class="<?php echo esc_attr( $icon[$key] ); ?>"> </i>
							                                        <span class="label-tooltip"><?php echo esc_html( $label[$key] ); ?></span>
							                                    </div>
							                                    <?php $d++;
							                                }
							                                if( $d >= $number_show_amenities ){
							                                	break;
							                                }
							                            }
							                        } ?>
							                    
							                    </div>
							                </div>
							            </div>
							            <?php endif; endif;?>
							            <?php if( $settings['product_style'] == 'style3' || $settings['product_style'] == 'style4' ) : ?>
											<?php if( get_theme_mod( 'rl_type_show_button', 'true' ) == 'yes'){ ?>
								            <div class="discorver">
								                <a href="<?php the_permalink(); ?> " class="discover-now">
								                    <span class="text"><?php esc_html_e( 'Book Now', 'ova-framework' ); ?></span>
								                </a>
								            </div>
								            <?php } 
							            endif; ?>
							            <?php 
							            	if( $settings['product_style'] == 'style6'){ 
												if( get_theme_mod( 'rl_type_show_button', 'true' ) == 'yes'){ ?>
										            <div class="discorver">
										                <a href="<?php the_permalink(); ?> " class="discover-now">
										                    <span class="text"><?php esc_html_e( 'Discover Now', 'ova-framework' ); ?></span>
										                </a>
										            </div>
							            		<?php }
							            	}
							            ?>  

							        </div> <!-- End content -->
							    </div> <!-- border-box -->							    
							
							<?php 
							if( $settings['product_style'] == 'style3'){
								if( $group_slide == $settings['total_items_column']  || $t_items_cat == $hozing_products->post_count ){ ?>       
                                 	</div>
	                            <?php }
								$group_slide++;
	                            $t_items_cat++; 
                        	}else{ ?>
                        		</div>
                        	<?php }
							$count++; ?>
						<?php endwhile; endif; wp_reset_postdata(); ?>

	            	</div> <!-- End owl-carousel -->
	            </div> <!-- hozing_product_slider -->
         	</div>                	                               	                            	                          	              	        
	    </div> <!-- hozing_product_slider -->

	<?php } 
	
}
