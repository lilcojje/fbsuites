<?php
namespace ova_framework\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\REPEATER;



if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class ova_copyright extends Widget_Base {

	public function get_name() {
		return 'ova_copyright';
	}

	public function get_title() {
		return __( 'Copyright', 'ova-framework' );
	}

	public function get_icon() {
		return ' eicon-text-area';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_keywords() {
		return [ 'footer', 'text', 'info' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
			]
		);

		$this->add_control(
			'text',
			[
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'rows' => 3,
				'default' => __( 'Copyright by HoZing Theme Demo. Theme by ovatheme', 'ova-framework' ),
				'placeholder' => __( 'Copyright by Ovatheme', 'ova-framework' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typo_info',
				'selector' => '{{WRAPPER}} .ova_copyright p, {{WRAPPER}} .ova_copyright',
			]
		);

		$this->add_control(
			'color_info',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_copyright, {{WRAPPER}} .ova_copyright p ' => 'color: {{VALUE}}',
				],
				'separator' => 'after',
			]
		);

		$this->add_control(
			'text_align',
			[
				'label' => __( 'Alignment', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		?>
		<div class="ova_copyright" style="align-items: <?php echo $settings['text_align']?>"><?php echo $settings['text']; ?></div>
		<?php
	}	
}
