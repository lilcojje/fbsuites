<?php
namespace ova_framework\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_offers_1 extends Widget_Base {

	public function get_name() {
		return 'ova_offers_1';
	}

	public function get_title() {
		return __( 'Offers 1', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-product-upsell ';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		$animation_array =array(
			'bounce'  => 'bounce',
			'flash'  => 'flash',
			'pulse'  => 'pulse',
			'rubberBand'  => 'rubberBand',
			'shake'  => 'shake',
			'swing'  => 'swing',
			'tada'  => 'tada',
			'wobble'  => 'wobble',
			'jello'  => 'jello',
			'bounceIn'  => 'bounceIn',
			'bounceInDown'  => 'bounceInDown',
			'bounceInLeft'  => 'bounceInLeft',
			'bounceInRight'  => 'bounceInRight',
			'bounceInUp'  => 'bounceInUp',
			'bounceOut'  => 'bounceOut',
			'bounceOutDown'  => 'bounceOutDown',
			'bounceOutLeft'  => 'bounceOutLeft',
			'bounceOutRight'  => 'bounceOutRight',
			'bounceOutUp'  => 'bounceOutUp',
			'fadeIn'  => 'fadeIn',
			'fadeInDown'  => 'fadeInDown',
			'fadeInDownBig'  => 'fadeInDownBig',
			'fadeInLeft'  => 'fadeInLeft',
			'fadeInLeftBig'  => 'fadeInLeftBig',
			'fadeInRight'  => 'fadeInRight',
			'fadeInRightBig'  => 'fadeInRightBig',
			'fadeInUp'  => 'fadeInUp',
			'fadeInUpBig'  => 'fadeInUpBig',
			'fadeOut'  => 'fadeOut',
			'fadeOutDown'  => 'fadeOutDown',
			'fadeOutDownBig'  => 'fadeOutDownBig',
			'fadeOutLeft'  => 'fadeOutLeft',
			'fadeOutLeftBig'  => 'fadeOutLeftBig',
			'fadeOutRight'  => 'fadeOutRight',
			'fadeOutRightBig'  => 'fadeOutRightBig',
			'fadeOutUp'  => 'fadeOutUp',
			'fadeOutUpBig'  => 'fadeOutUpBig',
			'flip'  => 'flip',
			'flipInX'  => 'flipInX',
			'flipInY'  => 'flipInY',
			'flipOutX'  => 'flipOutX',
			'flipOutY'  => 'flipOutY',
			'lightSpeedIn'  => 'lightSpeedIn',
			'lightSpeedOut'  => 'lightSpeedOut',
			'rotateIn'  => 'rotateIn',
			'rotateInDownLeft'  => 'rotateInDownLeft',
			'rotateInDownRight'  => 'rotateInDownRight',
			'rotateInUpLeft'  => 'rotateInUpLeft',
			'rotateInUpRight'  => 'rotateInUpRight',
			'rotateOut'  => 'rotateOut',
			'rotateOutDownLeft'  => 'rotateOutDownLeft',
			'rotateOutDownRight'  => 'rotateOutDownRight',
			'rotateOutUpLeft'  => 'rotateOutUpLeft',
			'rotateOutUpRight'  => 'rotateOutUpRight',
			'slideInUp'  => 'slideInUp',
			'slideInDown'  => 'slideInDown',
			'slideInLeft'  => 'slideInLeft',
			'slideInRight'  => 'slideInRight',
			'slideOutUp'  => 'slideOutUp',
			'slideOutDown'  => 'slideOutDown',
			'slideOutLeft'  => 'slideOutLeft',
			'slideOutRight'  => 'slideOutRight',
			'zoomIn'  => 'zoomIn',
			'zoomInDown'  => 'zoomInDown',
			'zoomInLeft'  => 'zoomInLeft',
			'zoomInRight'  => 'zoomInRight',
			'zoomInUp'  => 'zoomInUp',
			'zoomOut'  => 'zoomOut',
			'zoomOutDown'  => 'zoomOutDown',
			'zoomOutLeft'  => 'zoomOutLeft',
			'zoomOutRight'  => 'zoomOutRight',
			'zoomOutUp'  => 'zoomOutUp',
			'hinge'  => 'hinge',
			'jackInTheBox'  => 'jackInTheBox',
			'rollIn'  => 'rollIn',
			'rollOut'  => 'rollOut'
		);

		/*************** Section Imgages Offers ***************/
		$this->start_controls_section(
			'section_content_offers',
			[
				'label' => __( 'Images', 'ova-framework' ),
			]
		);
			$this->add_control(
				'images',
				[
					'type' => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);

			$this->add_control(
				'link_images',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => false,
					],
				]
			);

			$this->add_control(
				'show_animation_image',
				[
					'label' => __( 'Animate', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => '',
				]
			);

			$this->add_control(
				'animation_style_image',
				[
					'label' => __( 'Animation', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => $animation_array,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_image',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_dur_image',
				[
					'label' => __( 'Animation Dur', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 1000,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_image',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_delay_image',
				[
					'label' => __( 'Animation Delay', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 500,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_image',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);
			
			$this->add_control(
				'heading_text_discount',
				[
					'label' => __( 'Text Discount', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_discount',
				[
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Sale Off', 'ova-framework' ),
					'placeholder' => 'Sale',
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_discount_typo',
					'selector' => '{{WRAPPER}} .ova_offers_1 .discount .text_discount',
				]
			);

			$this->add_control(
				'text_discount_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .discount .text_discount' => 'color: {{VALUE}}',
					],
				]
			);


			$this->add_control(
				'heading_number_discount',
				[
					'label' => __( 'Number Discount', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
				]
			);

			$this->add_control(
				'number_discount',
				[
					'type' => Controls_Manager::TEXT,
					'default' => __( '-50%', 'ova-framework' ),
					'placeholder' => '-5%',
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'number_discount_typo',
					'selector' => '{{WRAPPER}} .ova_offers_1 .discount .number_discount',
				]
			);

			$this->add_control(
				'number_discount_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .discount .number_discount' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'show_animation_discount',
				[
					'label' => __( 'Animate', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => '',
				]
			);

			$this->add_control(
				'animation_style_discount',
				[
					'label' => __( 'Animation', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => $animation_array,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_discount',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_dur_discount',
				[
					'label' => __( 'Animation Dur', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 1500,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_discount',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_delay_discount',
				[
					'label' => __( 'Animation Dur', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 1500,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_discount',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);
		$this->end_controls_section();

		/*************** Section Info Offers ***************/
		$this->start_controls_section(
			'section_info_offers',
			[
				'label' => __( 'Info Images', 'ova-framework' ),
			]
		);
			$this->add_control(
				'heading_title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
				]
			);

			$this->add_control(
				'title_images',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'COFFEE & BAR', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_images_typo',
					'label' => __( 'Typography', 'ova-framework' ),
					'selector' => '{{WRAPPER}} .ova_offers_1 .info_images .title_images',
				]
			);

			$this->add_control(
				'title_images_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .info_images .title_images' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'heading_des',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'description_images',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'description_images_typo',
					'selector' => '{{WRAPPER}} .ova_offers_1 .info_images .description_images',
				]
			);

			$this->add_control(
				'description_images_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .info_images .description_images' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'show_animation_info',
				[
					'label' => __( 'Animate', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => '',
					'separator' => 'before',
				]
			);

			$this->add_control(
				'animation_style_info',
				[
					'label' => __( 'Animation', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => $animation_array,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_info',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_dur_info',
				[
					'label' => __( 'Animation Dur', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 1500,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_info',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_delay_info',
				[
					'label' => __( 'Animation Dur', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 2500,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_info',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);
		$this->end_controls_section();


		/*************** Section Style ***************/
		$this->start_controls_section(
			'section_discount_style',
			[
				'label' => __( 'Discount', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'discount_background',
				[
					'label' => __( 'Discount Background', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .content .discount' => 'background-color: {{VALUE}}',
					],
				]
			);
			$this->add_responsive_control(
				'width_height_discount',
				[
					'label' => __( 'Width x Height', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'min' => 30,
					'max' => 500,
					'step' => 1,
					'default' => 150,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .content .discount' => 'width: {{VALUE}}px; height: {{VALUE}}px',
					],
				]

			);
			$this->add_responsive_control(
				'spacing_text_number',
				[
					'label' => __( 'Spacing', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 20,
					],
					'selectors' => [
						'{{WRAPPER}} .text_discount' => 'padding-bottom: {{SIZE}}{{UNIT}};',
					],
				]
			);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'section_description_style',
			[
				'label' => __( 'Info Images', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_responsive_control(
				'padding_title_images',
				[
					'label' => __( 'Padding Title Images', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .info_images .title_images' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_description_images',
				[
					'label' => __( 'Padding Description Images', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .info_images .description_images' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			
		$this->end_controls_section();

		/*************** Section Button ***************/
		$this->start_controls_section(
			'section_button',
			[
				'label' => __( 'Button', 'ova-framework' ),
			]
		);
			$this->add_control(
				'text_button',
				[
					'label' => __( 'Text Button', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'VIEW OUR OFFERS', 'ova-framework' ),
					'label_block' => true,
					'separator' => 'before',
				]
			);

			$this->start_controls_tabs( 'tabs_button_style' );

			$this->start_controls_tab(
				'tab_button_normal',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_color',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a' => 'border-color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_button_hover',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_hover_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_hover_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_hover_border_color',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_hover_animation',
				[
					'label' => __( 'Hover Animation', 'ova-framework' ),
					'type' => Controls_Manager::HOVER_ANIMATION,
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_control(
				'show_animation_button',
				[
					'label' => __( 'Animate', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => '',
				]
			);

			$this->add_control(
				'animation_style_button',
				[
					'label' => __( 'Animation', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => $animation_array,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_button',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_dur_button',
				[
					'label' => __( 'Animation Dur', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 1500,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_button',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'animation_delay_button',
				[
					'label' => __( 'Animation Delay', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => 3500,
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_animation_button',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'border_style',
				[
					'label' => __( 'Border Style', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'solid',
					'options' => [
						'solid'  => __( 'Solid', 'ova-framework' ),
						'dashed' => __( 'Dashed', 'ova-framework' ),
						'dotted' => __( 'Dotted', 'ova-framework' ),
						'double' => __( 'Double', 'ova-framework' ),
						'none' => __( 'None', 'ova-framework' ),
					],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a' => 'border-style: {{VALUE}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'width_border',
				[
					'label' => __( 'Width Border', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
				]
			);

			$this->add_control(
				'border_radius',
				[
					'label' => __( 'Border Radius', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
				]
			);
			$this->add_responsive_control(
				'padding_button',
				[
					'label' => __( 'Padding Button', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'show_line',
				[
					'label' => __( 'Show Line', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'default' => 'yes',
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers .line_button:before' => 'display: block',
					],
				]
			);

			$this->add_responsive_control(
				'line_spacing',
				[
					'label' => __( 'Line Spacing', 'plugin-domain' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 400,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .ova_offers_1 .button_offers .text_button' => 'padding-right: {{SIZE}}{{UNIT}}; padding-left: {{SIZE}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_line',
								'operator' => '=',
								'value' => 'yes',
							],
						],
					],
				]
			);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		$images = $settings['images']['url'] != '' ? $settings['images']['url'] : '';

		$link_images = $settings['link_images']['url'] ? $settings['link_images']['url'] : '';
		$target = $settings['link_images']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link_images']['nofollow'] ? ' rel="nofollow"' : '';

		?>
			<div class="ova_offers_1">

				<div class="content">
					<a href="<?php echo esc_html( $link_images ); ?>" <?php echo esc_html( $target); echo esc_html( $nofollow); ?> >
						<img src="<?php echo esc_url($images); ?>" alt="" class="animated <?php echo esc_html( $settings['animation_style_image'] ); ?>" style="animation-duration: <?php echo esc_html( $settings['animation_dur_image']. 'ms'); ?>; animation-delay: <?php echo esc_html( $settings['animation_delay_image'] . 'ms'); ?>;">
						<div class="wrap_discount animated <?php echo esc_html( $settings['animation_style_discount'] ); ?>" style="animation-duration: <?php echo esc_html( $settings['animation_dur_discount']. 'ms'); ?>; animation-delay: <?php echo esc_html( $settings['animation_delay_discount'] . 'ms'); ?>;">
							<div class="discount ">
								<div class="text_discount second_font"><?php echo esc_html( $settings['text_discount'] ); ?></div>
								<div class="number_discount second_font"><?php echo esc_html( $settings['number_discount'] ); ?></div>
							</div>
						</div>
					</a>
				</div>

				<div class="info_images animated <?php echo esc_html( $settings['animation_style_info'] ); ?>" style="animation-duration: <?php echo esc_html( $settings['animation_dur_info']. 'ms'); ?>; animation-delay: <?php echo esc_html( $settings['animation_delay_info'] . 'ms'); ?>;">
					<div class="title_images second_font"><?php echo esc_html( $settings['title_images'] ); ?></div>
					<div class="description_images"><?php echo esc_html( $settings['description_images'] ); ?></div>
				</div>
				<div class="button_offers animated <?php echo esc_html( $settings['animation_style_button'] ); ?>" style="animation-duration: <?php echo esc_html( $settings['animation_dur_button']. 'ms'); ?>; animation-delay: <?php echo esc_html( $settings['animation_delay_button'] . 'ms'); ?>;">
					<div class="line_button"></div>

					<div class="text_button">
						<a class="<?php echo 'elementor-animation-'.esc_html( $settings['button_hover_animation'] ); ?>" href="<?php echo esc_html( $link_images ); ?>" <?php echo esc_html( $target); echo esc_html( $nofollow); ?>><?php echo esc_html( $settings['text_button'] ); ?></a>
					</div>
				</div>
			</div>
		<?php

	}
}