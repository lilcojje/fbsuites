<?php
namespace ova_framework\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class ova_logo_footer extends Widget_Base {

	public function get_name() {
		return 'ova_logo_footer';
	}

	public function get_title() {
		return __( 'Logo Footer', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-logo';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_keywords() {
		return [ 'image', 'photo', 'logo' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_logo',
			[
				'label' => __( 'Logo', 'ova-framework' ),
			]
		);
		$this->add_control(
			'logo',
			[
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_responsive_control(
			'width_img',
			[
				'label' => __( 'Desktop Logo Width', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 1000,
						'step' => 1,
					]
				],
				'default' => [
					'unit' => 'px',
					'size' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .logo_footer img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'height_img',
			[
				'label' => __( 'Desktop Logo Height', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 1000,
						'step' => 1,
					]
				],
				'default' => [
					'unit' => 'px',
					'size' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .logo_footer img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_des',
			[
				'type'      => \Elementor\Controls_Manager::HEADING,
				'label'     => __( 'Description', 'ova-framework' ),
				'separator' => 'before',
			]
		);
		$this->add_control(
			'description',
			[
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Luxury where you most expect it', 'ova-framework' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'color',
			[
				'label'     => __( 'Color', 'ova-framework' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .logo_footer .des' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .logo_footer .des',
			]
		);
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		?>

		<div class="logo_footer">
			<img src="<?php echo esc_url( $settings['logo']['url'] ); ?>" alt="<?php bloginfo('name');  ?>">
			<div class="des"><?php echo esc_html ($settings['description'])?></div>
		</div>

		<?php
	}	
}