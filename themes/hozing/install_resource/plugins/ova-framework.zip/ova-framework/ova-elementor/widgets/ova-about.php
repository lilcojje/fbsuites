<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_about extends Widget_Base {

	public function get_name() {
		return 'ova_about';
	}

	public function get_title() {
		return __( 'About', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$this->add_control(
				'version_about',
				[
					'label' => __( 'Choose Version About', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'about_version_1',
					'options' => [
						'about_version_1' => __( 'About Version 1', 'ova-framework' ),
						'about_version_2' => __( 'About Version 2', 'ova-framework' ),
						'about_version_3' => __( 'About Version 3', 'ova-framework' ),
					],
				]
			);
			
			/*******************************************************************************
						ABOUT VERSION 1
			********************************************************************************/

			$this->add_control(
				'text_background_ver_1',
				[
					'label' => __( 'Text Background', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'B', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			$this->add_control(
				'image_1_ver_1',
				[
					'label' => __( 'Choose Image 1', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			$this->add_control(
				'image_2_ver_1',
				[
					'label' => __( 'Choose Image 2', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			$this->add_control(
				'link_ver_1',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			$this->add_control(
				'sub_title_ver_1',
				[
					'label' => __( 'Sub Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'SERVICE SINCE 1890', 'ova-framework' ),
					'placeholder' => __( 'Type your sub title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			$this->add_control(
				'title_ver_1',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'The Pool', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);
			

			$this->add_control(
				'description_ver_1',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::WYSIWYG,
					'rows' => 5,
					'default' => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto.Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			$this->add_control(
				'text_view_ver_1',
				[
					'label' => __( 'Text View', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'VIEW OUR HISTORY', 'ova-framework' ),
					'placeholder' => __( 'Type your text view here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_1',
					],
				]
			);

			##################### END SECTION CONTENT ABOUT VERSION 1 ############################



			/*******************************************************************************
						ABOUT VERSION 2
			********************************************************************************/

			$this->add_control(
				'image_1_ver_2',
				[
					'label' => __( 'Choose Image 1', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'image_2_ver_2',
				[
					'label' => __( 'Choose Image 2', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'image_3_ver_2',
				[
					'label' => __( 'Choose Image 3', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'link_ver_2',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'sub_title_ver_2',
				[
					'label' => __( 'Sub Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Welcome!', 'ova-framework' ),
					'placeholder' => __( 'Type your sub title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'title_ver_2',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'WONDERFUL HOTEL IN THE HEART OF ATHENS, GREECE', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);
			

			$this->add_control(
				'description_ver_2',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::WYSIWYG,
					'rows' => 5,
					'default' => __( '<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure</p><p>dolor in reprehenderit in voluptate velit esse cillum dolore. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p><p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis  praesentium</p><p>voluptatum deleniti atque corrupti quos dolores.</p>', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			$this->add_control(
				'text_view_ver_2',
				[
					'label' => __( 'Text View', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'VIEW OUR HISTORY', 'ova-framework' ),
					'placeholder' => __( 'Type your text view here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_2',
					],
				]
			);

			##################### END SECTION CONTENT ABOUT VERSION 2 ############################

			/*******************************************************************************
						ABOUT VERSION 3
			********************************************************************************/

			$this->add_control(
				'image_icon_ver_3',
				[
					'label' => __( 'Choose Image Icon', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);

			$this->add_control(
				'title_ver_3',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Our online booking service is the best', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);

			$this->add_control(
				'link_ver_3',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => false,
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
					],
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);
			

			$this->add_control(
				'description_ver_3',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::WYSIWYG,
					'rows' => 5,
					'default' => __( 'Call Us On 1800-1111-2222 or Email hozing@website.com', 'ova-framework' ),
					 'placeholder' => __( 'Type your description here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);

			$this->add_control(
				'text_view_ver_3',
				[
					'label' => __( 'Text View', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Online Booking', 'ova-framework' ),
					'placeholder' => __( 'Type your text view here', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);

			$this->add_control(
				'text_class_icon_ver_3',
				[
					'label' => __( 'Class Icon', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( ' arrow_carrot-right', 'ova-framework' ),
					'condition' => [
						'version_about' => 'about_version_3',
					],
				]
			);

			##################### END SECTION CONTENT ABOUT VERSION 3 ############################

		$this->end_controls_section();


		/*******************************************************************************
						TAB STYLE ABOUT
		********************************************************************************/

		/*******************************************************************************
						ABOUT VERSION 1
		********************************************************************************/

		/*************  section controll text background *******************/

		$this->start_controls_section(
			'section_text_background_ver_1',
			[
				'label' => __( 'Text Background', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_background_ver_1',
					'selector' => '{{WRAPPER}} .ova-about .text-background span',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_text_background_ver_1',
				[
					'label' => __( 'Color Text Background', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .text-background span' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'position_text_background_ver_1',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -200,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about .text-background' => 'right: calc(100% + {{SIZE}}{{UNIT}});',
					],
				]
			);

			$this->add_control(
				'font_size_text_background_ver_1',
				[
					'label' => __( 'Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about .text-background span' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll text background ###############################

		/*************  section controll sub title. *******************/

		$this->start_controls_section(
			'section_sub_title_ver_1',
			[
				'label' => __( 'Sub Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'sub_title_ver_1_typography',
					'selector' => '{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_sub_title_ver_1',
				[
					'label' => __( 'Color Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_sub_title_ver_1',
				[
					'label' => __( 'Margin Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_sub_title_ver_1',
				[
					'label' => __( 'Padding Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll sub title ###############################


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_ver_1',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_ver_1_typography',
					'selector' => '{{WRAPPER}} .ova-about .wrap-ova-about .content .title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_ver_1',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title_ver_1_hover',
				[
					'label' => __( 'Color Title Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title_ver_1',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_ver_1',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_ver_1',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_ver_1_typography',
					'selector' => '{{WRAPPER}} .ova-about .wrap-ova-about .content .desc p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_ver_1',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .desc p' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_ver_1',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_ver_1',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################


		/*************  section controll read more. *******************/

		$this->start_controls_section(
			'section_readmore_ver_1',
			[
				'label' => __( 'Text View', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_1',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_view_ver_1_typography',
					'selector' => '{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_text_view_ver_1',
				[
					'label' => __( 'Color Text View', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_text_view_ver_1_hover',
				[
					'label' => __( 'Color Text View Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_text_view_ver_1',
				[
					'label' => __( 'Margin Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_text_view_ver_1',
				[
					'label' => __( 'Padding Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll read more ###############################


		/*************  section controll line. *******************/

		$this->start_controls_section(
			'section_line_ver_1',
			[
				'label' => __( 'Line', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_1',
				],
			]
		);	

			$this->add_control(
				'width_line_ver_1',
				[
					'label' => __( 'Line Width', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 300,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title:after' => 'width: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more:before' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'height_line_ver_1',
				[
					'label' => __( 'Line Height', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 10,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title:after' => 'height: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more:before' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);



			$this->add_control(
				'background_line_ver_1',
				[
					'label' => __( 'Background Line', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title:after' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more:before' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'distance_ver_1',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -50,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .sub-title:after' => 'left: calc(100% + {{SIZE}}{{UNIT}});',
						'{{WRAPPER}} .ova-about .wrap-ova-about .content .read-more:before' => 'right: calc(100% + {{SIZE}}{{UNIT}});',
					],
				]
			);

		$this->end_controls_section();
		#################### section controll line ###############################

		######################## END TAB STYLE ABOUT VERSION 1 ############################


		/*******************************************************************************
						ABOUT VERSION 2
		********************************************************************************/

		/*************  section controll sub title. *******************/

		$this->start_controls_section(
			'section_sub_title_ver_2',
			[
				'label' => __( 'Sub Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'sub_title_ver_2_typography',
					'selector' => '{{WRAPPER}} .ova-about.about_version_2 .content .sub-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_sub_title_ver_2',
				[
					'label' => __( 'Color Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .sub-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_sub_title_ver_2',
				[
					'label' => __( 'Margin Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_sub_title_ver_2',
				[
					'label' => __( 'Padding Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll sub title ###############################


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_ver_2',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_ver_2_typography',
					'selector' => '{{WRAPPER}} .ova-about.about_version_2 .content .title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_ver_2',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title_ver_2_hover',
				[
					'label' => __( 'Color Title Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title_ver_2',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_ver_2',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_ver_2',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_ver_2_typography',
					'selector' => '{{WRAPPER}} .ova-about.about_version_2 .content .desc p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_ver_2',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .desc p' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_ver_2',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_ver_2',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################


		/*************  section controll read more. *******************/

		$this->start_controls_section(
			'section_readmore_ver_2',
			[
				'label' => __( 'Text View', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_2',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_view_ver_2_typography',
					'selector' => '{{WRAPPER}} .ova-about.about_version_2 .content .read-more',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_text_view_ver_2',
				[
					'label' => __( 'Color Text View', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .read-more' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_text_view_ver_2_hover',
				[
					'label' => __( 'Color Text View Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .read-more:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_text_view_ver_2',
				[
					'label' => __( 'Margin Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_text_view_ver_2',
				[
					'label' => __( 'Padding Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_2 .content .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll read more ###############################


		######################## END TAB STYLE ABOUT VERSION 2 ############################

		/*******************************************************************************
						ABOUT VERSION 3
		********************************************************************************/

		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_ver_3',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_3',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_ver_3_typography',
					'selector' => '{{WRAPPER}} .ova-about.about_version_3 .content .title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title_ver_3',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title_ver_3',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title_ver_3',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc_ver_3',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_3',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_ver_3_typography',
					'selector' => '{{WRAPPER}} .ova-about.about_version_3 .content .desc, {{WRAPPER}} .ova-about.about_version_3 .content .desc p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc_ver_3',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .desc p' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova-about.about_version_3 .content .desc' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc_ver_3',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc_ver_3',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################


		/*************  section controll read more. *******************/

		$this->start_controls_section(
			'section_readmore_ver_3',
			[
				'label' => __( 'Text View', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_3',
				],
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_view_ver_3_typography',
					'selector' => '{{WRAPPER}} .ova-about.about_version_3 .content .more .read-more',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_text_view_ver_3',
				[
					'label' => __( 'Color Text View', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .more .read-more' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova-about.about_version_3 .content .more .read-more i' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_text_view_ver_3_hover',
				[
					'label' => __( 'Color Text View Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .more .read-more:hover' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova-about.about_version_3 .content .more .read-more:hover i' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_text_view_ver_3',
				[
					'label' => __( 'Margin Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_text_view_ver_3',
				[
					'label' => __( 'Padding Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll read more ###############################

		/*************  section controll class icon *******************/

		$this->start_controls_section(
			'section_class_icon_ver_3',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_about' => 'about_version_3',
				],
			]
		);	

			$this->add_control(
				'font-size_icon_ver_3',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						]
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .more .read-more i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'space_icon_ver_3',
				[
					'label' => __( 'Space Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 50,
							'step' => 1,
						]
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about.about_version_3 .content .more .read-more i' => 'margin-left: {{SIZE}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll class icon ###############################


		######################## END TAB STYLE ABOUT VERSION 3 ############################

		


	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$text_background = $image_1 = $image_2 = $image_3 = $link = $target = $nofollow = $sub_title = $title = $description = $text_view = $image_icon = $text_class_icon = '';

		$version_about = $settings['version_about'];

 		switch ($version_about) {
 			case "about_version_1" : {
 				$text_background 	= $settings['text_background_ver_1'];
				$image_1			= $settings['image_1_ver_1']['url'];
				$image_2			= $settings['image_2_ver_1']['url'];
				$link				= $settings['link_ver_1']['url'];
				$target      		= $settings['link_ver_1']['is_external'] ? ' target="_blank" ' : '';
				$nofollow   		= $settings['link_ver_1']['nofollow'] ? ' rel="nofollow" ' : '';
				$sub_title 			= $settings['sub_title_ver_1'];
				$title 				= $settings['title_ver_1'];
				$description 	 	= $settings['description_ver_1'];
				$text_view 		 	= $settings['text_view_ver_1'];
				break;
 			}
 			case "about_version_2" : {
 				$image_1			= $settings['image_1_ver_2']['url'];
				$image_2			= $settings['image_2_ver_2']['url'];
				$image_3			= $settings['image_3_ver_2']['url'];
				$link				= $settings['link_ver_2']['url'];
				$target      		= $settings['link_ver_2']['is_external'] ? ' target="_blank" ' : '';
				$nofollow   		= $settings['link_ver_2']['nofollow'] ? ' rel="nofollow" ' : '';
				$sub_title 			= $settings['sub_title_ver_2'];
				$title 				= $settings['title_ver_2'];
				$description 	 	= $settings['description_ver_2'];
				$text_view 		 	= $settings['text_view_ver_2'];
				break;
 			}
 			case "about_version_3" : {
 				$image_icon = $settings['image_icon_ver_3']['url'];
 				$link	= $settings['link_ver_3']['url'];
				$target = $settings['link_ver_3']['is_external'] ? ' target="_blank" ' : '';
 				$title = $settings['title_ver_3'];
 				$description = $settings['description_ver_3'];
 				$text_view = $settings['text_view_ver_3'];
 				$text_class_icon = $settings['text_class_icon_ver_3'];
 				break;
 			}
 		}
		?>

		<?php if ($version_about === 'about_version_1') : ?>
			<div class="ova-about <?php echo $version_about ?>">
				<div class="text-background">
					<span class="second_font"><?php echo $text_background ?></span>
				</div>
				<div class="wrap-ova-about">
					<div class="cover-image">
						<a href="<?php echo esc_url($link) ?>" class="image-1" style="background-image: url(<?php echo $image_1 ?>)" <?php echo $target ?>>
						</a>
						<a href="<?php echo esc_url($link) ?>" class="image-2" style="background-image: url(<?php echo $image_2 ?>)" <?php echo $target ?>>
						</a>
					</div>
					<div class="content">
						<h4 class="sub-title second_font"><?php echo $sub_title ?></h4>
						<h3 class="title second_font"><a href="<?php echo esc_url($link) ?>"><?php echo $title ?></a></h3>
						<div class="desc">
							<?php echo $description ?>
						</div>
						<a href="<?php echo esc_url($link) ?>" class="read-more" <?php echo $target ?>><?php echo $text_view ?></a>
					</div>
				</div>
			</div>
		<?php endif ?>

		<?php if ($version_about === 'about_version_2') : ?>
			<div class="ova-about <?php echo $version_about ?>">
				<div class="cover-image">
					<a class="image-1" href="<?php echo esc_url($link) ?>" <?php echo $target ?>>
						<img src="<?php echo $image_1 ?>" alt="">
					</a>
					<a class="image-2" href="<?php echo esc_url($link) ?>" <?php echo $target ?>>
						<img src="<?php echo $image_2 ?>" alt="">
					</a>
					<a class="image-3" href="<?php echo esc_url($link) ?>" <?php echo $target ?>>
						<img src="<?php echo $image_3 ?>" alt="">
					</a>
				</div>
				<div class="wp-content">
					<div class="content">
						<h4 class="sub-title second_font"><?php echo $sub_title ?></h4>
						<h3 class="title second_font"><a href="<?php echo esc_url($link) ?>"><?php echo $title ?></a></h3>
						<div class="desc">
							<?php echo $description ?>
						</div>
						<a href="<?php echo esc_url($link) ?>" class="read-more" <?php echo $target ?>><?php echo $text_view ?></a>
					</div>
				</div>
			</div>
		<?php endif ?>

		<?php if( $version_about === 'about_version_3' ) : ?>
			<div class="ova-about <?php echo $version_about ?>">
				<div class="img-icon">
					<img src="<?php echo $image_icon ?>" alt="">
				</div>
				<div class="content">
					<h3 class="title"><?php echo $title ?></h3>
					<div class="desc">
						<?php echo $description ?>
					</div>
					<div class="more">
						<a href="<?php echo esc_url($link) ?>" class="read-more" <?php echo $target ?>><?php echo $text_view ?><i class=<?php echo $text_class_icon ?>></i></a>
					</div>
					
				</div>
			</div>
		<?php endif ?>

	<?php
	}
}
