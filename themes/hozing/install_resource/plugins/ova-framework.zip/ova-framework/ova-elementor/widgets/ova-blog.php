<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class ova_blog extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'ova_blog';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog', 'ova-framework' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ovatheme' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ova-elementor' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {

		$args = array(
		  'orderby' => 'name',
		  'order' => 'ASC'
		  );

		$categories=get_categories($args);
		$cate_array = array();
		$arrayCateAll = array( 'all' => 'All categories ' );
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->cat_name] = $cate->slug;
			}
		} else {
			$cate_array["No content Category found"] = 0;
		}

		/*******************************************************************************
						START SECTION CONTENT
		********************************************************************************/
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
			$this->add_control(
				'version_blog',
				[
					'label' => __( 'Choose Version Blog', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'blog_version_1',
					'options' => [
						'blog_version_1' => __( 'Blog Version 1', 'ova-framework' ),
						'blog_version_2' => __( 'Blog Version 2', 'ova-framework' ),
						'blog_version_3' => __( 'Blog Version 3', 'ova-framework' ),
						'blog_version_4' => __( 'Blog Version 4', 'ova-framework' ),
					],
				]
			);

			/*******************************************************************************
						BLOG VERSION 1
			********************************************************************************/

			$this->add_control(
				'category_ver_1',
				[
					'label' => __( 'Category', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'options' => array_merge($arrayCateAll,$cate_array),
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'total_count_ver_1',
				[
					'label' => __( 'Total Post', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 2,
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'show_title_ver_1',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'show_date_ver_1',
				[
					'label' => __( 'Show Date', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'show_excerpt_ver_1',
				[
					'label' => __( 'Show Excerpt', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'show_read_more_ver_1',
				[
					'label' => __( 'Show Read More', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'show_view_all_ver_1',
				[
					'label' => __( 'Show Button View All', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'icon_overlay_ver_1',
				[
					'label' => __( 'Icon Hover Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => 'icon_image',
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'text_read_more_ver_1',
				[
					'label' => __( 'Text Read More', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'Read More',
					'placeholder' => 'Text',
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);

			$this->add_control(
				'text_view_all_blog_ver_1',
				[
					'label' => __( 'Text View All Blog', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'View All Blog',
					'placeholder' => 'Text',
					'condition' => [
						'version_blog' => ['blog_version_1'],
					],
				]
			);
			############################ END BLOG VER 1 #################################



			/*******************************************************************************
						BLOG VERSION 2
			********************************************************************************/

			$this->add_control(
				'category_ver_2',
				[
					'label' => __( 'Category', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'options' => array_merge($arrayCateAll,$cate_array),
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'total_count_ver_2',
				[
					'label' => __( 'Total Post', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 2,
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'show_title_ver_2',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'show_date_ver_2',
				[
					'label' => __( 'Show Date', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'show_excerpt_ver_2',
				[
					'label' => __( 'Show Excerpt', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'show_read_more_ver_2',
				[
					'label' => __( 'Show Read More', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'show_view_all_ver_2',
				[
					'label' => __( 'Show Button View All', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'icon_overlay_ver_2',
				[
					'label' => __( 'Icon Hover Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => 'icon_image',
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'text_read_more_ver_2',
				[
					'label' => __( 'Text Read More', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'Read More',
					'placeholder' => 'Text',
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);

			$this->add_control(
				'text_view_all_blog_ver_2',
				[
					'label' => __( 'Text View All Blog', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'View All Blog',
					'placeholder' => 'Text',
					'condition' => [
						'version_blog' => ['blog_version_2'],
					],
				]
			);
			############################ END BLOG VER 2 #################################




			/*******************************************************************************
						BLOG VERSION 3
			********************************************************************************/

			$this->add_control(
				'category_ver_3',
				[
					'label' => __( 'Category', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'options' => array_merge($arrayCateAll,$cate_array),
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'total_count_ver_3',
				[
					'label' => __( 'Total Post', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 2,
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'show_title_ver_3',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'show_date_ver_3',
				[
					'label' => __( 'Show Date', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'show_excerpt_ver_3',
				[
					'label' => __( 'Show Excerpt', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'show_read_more_ver_3',
				[
					'label' => __( 'Show Read More', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'show_view_all_ver_3',
				[
					'label' => __( 'Show Button View All', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'icon_overlay_ver_3',
				[
					'label' => __( 'Icon Hover Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => 'icon_image',
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'text_read_more_ver_3',
				[
					'label' => __( 'Text Read More', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'Read More',
					'placeholder' => 'Text',
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);

			$this->add_control(
				'text_view_all_blog_ver_3',
				[
					'label' => __( 'Text View All Blog', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'View All Blog',
					'placeholder' => 'Text',
					'condition' => [
						'version_blog' => ['blog_version_3'],
					],
				]
			);
			############################ END BLOG VER 3 #################################


			/*******************************************************************************
						BLOG VERSION 4
			********************************************************************************/

			$this->add_control(
				'category_ver_4',
				[
					'label' => __( 'Category', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'all',
					'options' => array_merge($arrayCateAll,$cate_array),
					'condition' => [
						'version_blog' => ['blog_version_4'],
					],
				]
			);

			$this->add_control(
				'show_title_ver_4',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_4'],
					],
				]
			);

			$this->add_control(
				'show_date_ver_4',
				[
					'label' => __( 'Show Date', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_4'],
					],
				]
			);

			$this->add_control(
				'show_excerpt_ver_4',
				[
					'label' => __( 'Show Excerpt', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
					'condition' => [
						'version_blog' => ['blog_version_4'],
					],
				]
			);

			$this->add_control(
				'show_view_all_ver_4',
				[
					'label' => __( 'Show Button View All', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'condition' => [
						'version_blog' => ['blog_version_4'],
					],
				]
			);

			$this->add_control(
				'text_view_all_blog_ver_4',
				[
					'label' => __( 'Text View All Blog', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => 'View All Blog',
					'placeholder' => 'Text',
					'condition' => [
						'version_blog' => ['blog_version_4'],
					],
				]
			);
			############################ END BLOG VER 4 #################################

		$this->end_controls_section();
		################ END SECTION CONTROL CONTENT VER 1, 2, 3, 4 ############################



		/*******************************************************************************
						TAB STYLE BLOG VERSION 1
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_ver_1',
			[
				'label' => __( 'Cover Image Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_1'],
				],
			]
		);		

		$this->add_control(
			'cover_image_background_color_ver_1',
			[
				'label' => __( 'Background Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.7)',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay:hover' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cover_image_fontsize_ver_1',
			[
				'label' => __( 'Font Size Icon', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color_ver_1',
			[
				'label' => __( 'Color Icon', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay i' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_style_ver_1',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_1 .content .post-title a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_color_ver_1',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .content .post-title a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color_ver_1',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .content .post-title a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .content .post-title a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .content .post-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll date. *******************/

		$this->start_controls_section(
			'section_date_style_ver_1',
			[
				'label' => __( 'Date And Comment', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'date_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'date_color_ver_1',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "rgba(0,0,0,0.6)",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'date_hover_color_ver_1',
			[
				'label' => __( 'Comment Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll date. ###############



		/*************  section controll excerpt. *******************/

		$this->start_controls_section(
			'section_excerpt_style_ver_1',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_color_ver_1',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll excerpt. ###############


		/*************  section controll readmore. *******************/

		$this->start_controls_section(
			'section_readmore_style_ver_1',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'readmore_ver_1_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'readmore_color_ver_1',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_hover_color_ver_1',
			[
				'label' => __( 'Read More Hover Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a:hover' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'readmore_margin_ver_1',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'readmore_padding_ver_1',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll read more. ###############


		/*************  section controll line title read more *******************/

		$this->start_controls_section(
			'section_line_style_ver_1',
			[
				'label' => __( 'Line Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_1'],
				],
			]
		);
		

		$this->add_control(
			'line_color_ver_1',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .even .content .post-title a:before, {{WRAPPER}} .ova-blog-element.blog_version_1 .odd .content .post-readmore a:after ' => 'background-color : {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'line_width_ver_1',
			[
				'label' => __( 'Width', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .even .content .post-title a:before, .ova-blog-element.blog_version_1 .odd .content .post-readmore a:after' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'line_height_ver_1',
			[
				'label' => __( 'Height', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .even .content .post-title a:before, .ova-blog-element.blog_version_1 .odd .content .post-readmore a:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'line_position_ver_1',
			[
				'label' => __( 'Position', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => -20,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .even .content .post-title a:before, .ova-blog-element.blog_version_1 .odd .content .post-readmore a:after' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'line_distance_ver_1',
			[
				'label' => __( 'Distance Line Read More Or Title', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .even .content .post-title a:before' => 'right: calc(100% + {{SIZE}}{{UNIT}});',
					'{{WRAPPER}} .ova-blog-element.blog_version_1 .odd .content .post-readmore a:after' => 'left: calc(100% + {{SIZE}}{{UNIT}});',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll line title read more. ###############



		/*************  section controll button *******************/

		$this->start_controls_section(
			'section_button_style_ver_1',
			[
				'label' => __( 'Button View All', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_1'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography_ver_1',
				'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a',
			]
		);
		
		$this->start_controls_tabs( 'tabs_button_style_ver_1' );

			$this->start_controls_tab(
				'tab_button_normal_ver_1',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_ver_1',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_ver_1',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_ver_1',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_button_hover_ver_1',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_hover_ver_1',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_hover_ver_1',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_hover_ver_1',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			
			$this->end_controls_tab();
			$this->end_controls_tabs();

			$this->add_control(
				'button_position_ver_1',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'left'  => __( 'Left', 'ova-framework' ),
						'center' => __( 'Center', 'ova-framework' ),
						'right' => __( 'Right', 'ova-framework' ),
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_width_button_ver_1',
				[
					'label' => __( 'Border Width', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 10,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'text_button_margin_ver_1',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_responsive_control(
				'text_button_padding_ver_1',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_1 .ova-button-view-all a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
		

		$this->end_controls_section();
		###############  end section controll button. ###############

		############################ END STYLE TAB VER 1 #################################



		/*******************************************************************************
						TAB STYLE BLOG VERSION 2
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_ver_2',
			[
				'label' => __( 'Cover Image Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_2'],
				],
			]
		);		

		$this->add_control(
			'cover_image_background_color_ver_2',
			[
				'label' => __( 'Background Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.7)',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay:hover' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cover_image_fontsize_ver_2',
			[
				'label' => __( 'Font Size Icon', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color_ver_2',
			[
				'label' => __( 'Color Icon', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay i' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_style_ver_2',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_2 .content .post-title a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_color_ver_2',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_2 .content .post-title a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color_ver_2',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_2 .content .post-title a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_2 .content .post-title a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_2 .content .post-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll date. *******************/

		$this->start_controls_section(
			'section_date_style_ver_2',
			[
				'label' => __( 'Date And Comment', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'date_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'date_color_ver_2',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "rgba(0,0,0,0.6)",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'date_hover_color_ver_2',
			[
				'label' => __( 'Comment Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll date. ###############



		/*************  section controll excerpt. *******************/

		$this->start_controls_section(
			'section_excerpt_style_ver_2',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_color_ver_2',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll excerpt. ###############


		/*************  section controll readmore. *******************/

		$this->start_controls_section(
			'section_readmore_style_ver_2',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'readmore_ver_2_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'readmore_color_ver_2',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#242625",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_hover_color_ver_2',
			[
				'label' => __( 'Read More Hover Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'height_under_line_readmore_bot_ver_2',
			[
				'label' => __( 'Height Underline Read More', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'under_line_readmore_color_ver_2',
			[
				'label' => __( 'Color Underline', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a:after' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'readmore_margin_ver_2',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'readmore_padding_ver_2',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-readmore a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll read more. ###############


		



		/*************  section controll button *******************/

		$this->start_controls_section(
			'section_button_style_ver_2',
			[
				'label' => __( 'Button View All', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_2'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography_ver_2',
				'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a',
			]
		);
		
		$this->start_controls_tabs( 'tabs_button_style_ver_2' );

			$this->start_controls_tab(
				'tab_button_normal_ver_2',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_ver_2',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#242625',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_ver_2',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_ver_2',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_button_hover_ver_2',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_hover_ver_2',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_hover_ver_2',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_hover_ver_2',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			
			$this->end_controls_tab();
			$this->end_controls_tabs();

			$this->add_control(
				'button_position_ver_2',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'left'  => __( 'Left', 'ova-framework' ),
						'center' => __( 'Center', 'ova-framework' ),
						'right' => __( 'Right', 'ova-framework' ),
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_width_button_ver_2',
				[
					'label' => __( 'Border Width', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 10,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'text_button_margin_ver_2',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_responsive_control(
				'text_button_padding_ver_2',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_2 .ova-button-view-all a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
		

		$this->end_controls_section();
		###############  end section controll button. ###############


		############################ END STYLE TAB VER 2 #################################





		/*******************************************************************************
						TAB STYLE BLOG VERSION 3
		********************************************************************************/

		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image_ver_3',
			[
				'label' => __( 'Cover Image Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_3'],
				],
			]
		);		

		$this->add_control(
			'cover_image_background_color_ver_3',
			[
				'label' => __( 'Background Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.7)',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay:hover' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cover_image_fontsize_ver_3',
			[
				'label' => __( 'Font Size Icon', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color_ver_3',
			[
				'label' => __( 'Color Icon', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-media .overlay i' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_style_ver_3',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_3'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_ver_3_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_3 .content .post-title a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_color_ver_3',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_3 .content .post-title a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color_ver_3',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_3 .content .post-title a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin_ver_3',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_3 .content .post-title a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding_ver_3',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_3 .content .post-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll date. *******************/

		$this->start_controls_section(
			'section_date_style_ver_3',
			[
				'label' => __( 'Date And Comment', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_3'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'date_ver_3_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'date_color_ver_3',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.6)',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'date_hover_color_ver_3',
			[
				'label' => __( 'Comment Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_margin_ver_3',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_padding_ver_3',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-date, {{WRAPPER}} .ova-blog-element.general_blog .post-meta .post-comment a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll date. ###############



		/*************  section controll excerpt. *******************/

		$this->start_controls_section(
			'section_excerpt_style_ver_3',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_3'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_ver_3_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_color_ver_3',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_margin_ver_3',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_padding_ver_3',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.general_blog .post-excerpt p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll excerpt. ###############


		/*************  section controll button *******************/

		$this->start_controls_section(
			'section_button_style_ver_3',
			[
				'label' => __( 'Button View All', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_3'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography_ver_3',
				'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a',
			]
		);
		
		$this->start_controls_tabs( 'tabs_button_style_ver_3' );

			$this->start_controls_tab(
				'tab_button_normal_ver_3',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_ver_3',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_ver_3',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_ver_3',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_button_hover_ver_3',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_hover_ver_3',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_hover_ver_3',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_hover_ver_3',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			
			$this->end_controls_tab();
			$this->end_controls_tabs();

			$this->add_control(
				'button_position_ver_3',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'left'  => __( 'Left', 'ova-framework' ),
						'center' => __( 'Center', 'ova-framework' ),
						'right' => __( 'Right', 'ova-framework' ),
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_width_button_ver_3',
				[
					'label' => __( 'Border Width', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 10,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'text_button_margin_ver_3',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_responsive_control(
				'text_button_padding_ver_3',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_3 .ova-button-view-all a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
		

		$this->end_controls_section();
		###############  end section controll button. ###############


		############################ END STYLE TAB VER 3 #################################



		/*******************************************************************************
						TAB STYLE BLOG VERSION 4
		********************************************************************************/


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title_style_ver_4',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_4'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_ver_4_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_4 .content .post-title a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_color_ver_4',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-title h2 a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color_ver_4',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#b9a271',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-title h2 a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin_ver_4',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-title h2 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding_ver_4',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-title h2 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll date. *******************/

		$this->start_controls_section(
			'section_date_style_ver_4',
			[
				'label' => __( 'Date', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_4'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'date_ver_4_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-meta .post-date',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'date_color_ver_4',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgba(0,0,0,0.6)',
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-meta .post-date' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_margin_ver_4',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-meta .post-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'date_padding_ver_4',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-meta .post-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll date. ###############



		/*************  section controll excerpt. *******************/

		$this->start_controls_section(
			'section_excerpt_style_ver_4',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_4'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_ver_4_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_color_ver_4',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_margin_ver_4',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_padding_ver_4',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll excerpt. ###############


		/*************  section controll line style *******************/

		$this->start_controls_section(
			'section_line_style_ver_4',
			[
				'label' => __( 'Line Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_4'],
				],
			]
		);
		

		$this->add_control(
			'line_color_ver_4',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt:after' => 'background-color : {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'line_width_ver_4',
			[
				'label' => __( 'Width', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 350,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt:after' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'line_height_ver_4',
			[
				'label' => __( 'Height', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'line_position_vertical_ver_4',
			[
				'label' => __( 'Position Top Dow', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -50,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt:after' => 'top: calc(100% + {{SIZE}}{{UNIT}});',
				],
			]
		);


		$this->add_control(
			'line_position_hozical_ver_4',
			[
				'label' => __( 'Position Right Left', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -30,
						'max' => 250,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .info-item .post-excerpt:after' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll line style. ###############



		/*************  section controll image alpha *******************/

		$this->start_controls_section(
			'section_image_alpha_ver_4',
			[
				'label' => __( 'Image Alpha', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_4'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_alpha_ver_4_typography',
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .image-alpha a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);
		

		$this->add_control(
			'text_color_image_alpha_ver_4',
			[
				'label' => __( 'Text Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "rgba(0,0,0,0.1)",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .image-alpha a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'background_color_image_alpha_ver_4',
			[
				'label' => __( 'Background Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#f6f6f6",
				'selectors' => [
					'{{WRAPPER}} .ova-blog-element.blog_version_4 .post-item .image-alpha' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll image alpha. ###############


		/*************  section controll button *******************/

		$this->start_controls_section(
			'section_button_style_ver_4',
			[
				'label' => __( 'Button View All', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version_blog' => ['blog_version_4'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography_ver_4',
				'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'selector' => '{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a',
			]
		);
		
		$this->start_controls_tabs( 'tabs_button_style_ver_4' );

			$this->start_controls_tab(
				'tab_button_normal_ver_4',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_ver_4',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_ver_4',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_ver_4',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_button_hover_ver_4',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color_hover_ver_4',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_color_hover_ver_4',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color_hover_ver_4',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			
			$this->end_controls_tab();
			$this->end_controls_tabs();

			$this->add_control(
				'button_position_ver_4',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'left'  => __( 'Left', 'ova-framework' ),
						'center' => __( 'Center', 'ova-framework' ),
						'right' => __( 'Right', 'ova-framework' ),
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_width_button_ver_4',
				[
					'label' => __( 'Border Width', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 10,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'text_button_margin_ver_4',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_responsive_control(
				'text_button_padding_ver_4',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-element.blog_version_4 .ova-button-view-all a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
		

		$this->end_controls_section();
		###############  end section controll button. ###############


		############################ END STYLE TAB VER 4 #################################

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$version_blog = $settings['version_blog'];

		$category = $total_count = $show_title_blog = $show_sub_title_blog = $show_title = $show_date = $show_excerpt = $show_readmore = $show_view_all = $icon_overlay = $text_read_more = $text_view_all = "";

		switch ($version_blog) {
			case "blog_version_1" : {
				$category = $settings['category_ver_1'];
				$total_count = $settings['total_count_ver_1'];
				$show_title = $settings['show_title_ver_1'];
				$show_date = $settings['show_date_ver_1'];
				$show_excerpt = $settings['show_excerpt_ver_1'];
				$show_readmore = $settings['show_read_more_ver_1'];
				$show_view_all = $settings['show_view_all_ver_1'];
				$icon_overlay = $settings['icon_overlay_ver_1'];
				$text_read_more = $settings['text_read_more_ver_1'];
				$text_view_all = $settings['text_view_all_blog_ver_1'];
			}
			break;
			case "blog_version_2" : {
				$category = $settings['category_ver_2'];
				$total_count = $settings['total_count_ver_2'];
				$show_title = $settings['show_title_ver_2'];
				$show_date = $settings['show_date_ver_2'];
				$show_excerpt = $settings['show_excerpt_ver_2'];
				$show_readmore = $settings['show_read_more_ver_2'];
				$show_view_all = $settings['show_view_all_ver_2'];
				$icon_overlay = $settings['icon_overlay_ver_2'];
				$text_read_more = $settings['text_read_more_ver_2'];
				$text_view_all = $settings['text_view_all_blog_ver_2'];
			}
			break;

			case "blog_version_3" : {
				$category = $settings['category_ver_3'];
				$total_count = $settings['total_count_ver_3'];
				$show_title = $settings['show_title_ver_3'];
				$show_date = $settings['show_date_ver_3'];
				$show_excerpt = $settings['show_excerpt_ver_3'];
				$show_readmore = $settings['show_read_more_ver_3'];
				$show_view_all = $settings['show_view_all_ver_3'];
				$icon_overlay = $settings['icon_overlay_ver_3'];
				$text_read_more = $settings['text_read_more_ver_3'];
				$text_view_all = $settings['text_view_all_blog_ver_3'];
			}
			break;

			case "blog_version_4" : {
				$category = $settings['category_ver_4'];
				$total_count = 3;
				$show_title = $settings['show_title_ver_4'];
				$show_date = $settings['show_date_ver_4'];
				$show_excerpt = $settings['show_excerpt_ver_4'];
				$show_view_all = $settings['show_view_all_ver_4'];
				$text_view_all = $settings['text_view_all_blog_ver_4'];
			}
			break;
		} 


		$args =array();
			if ($category == 'all') {
				$args=array('post_type' => 'post', 'posts_per_page' => $total_count );
			}else{
				$args=array('post_type' => 'post', 'category_name'=> $category,'posts_per_page' => $total_count );
			}
		$blog = new \WP_Query($args);

		?>
			<!-- blog 1,2,3 -->
			<?php if ($version_blog === 'blog_version_1' || $version_blog === 'blog_version_2' || $version_blog === 'blog_version_3') : ?>
			<div class="ova-blog-element general_blog <?php echo $version_blog ?>">
				<?php
					$i = 0;
					if($blog->have_posts()) : while($blog->have_posts()) : $blog->the_post();
						$i++;
						$classOdd = ($i % 2 == 0) ? ' odd d-flex flex-row-reverse ' : ' even d-flex flex-row ';
						$thumbnail_url = wp_get_attachment_image_url(get_post_thumbnail_id() , 'full' );
						$the_time = get_the_time( get_option( 'date_format' ));
				?>
						<div class="post-item">
							<div class="row no-gutters <?php echo $classOdd ?>">
								<div class="col-md-6">
									<div class="post-media" style="background-image: url(<?php echo $thumbnail_url ?>)">
										<a class="overlay" href="<?php the_permalink() ?>">
											<i class="<?php echo $icon_overlay ?>"></i>
										</a>
									</div>
								</div>
								<div class="col-md-6">
									<div class="content">
										<?php if ( $show_title === 'yes' ) : ?>
											<div class="post-title">
												<h2><a class="second_font" href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
											</div>
										<?php endif; ?>
										<?php if ($show_date === 'yes') : ?>
											<div class="post-meta">
												<span class="post-date"><?php the_time( get_option( 'date_format' )) ?></span>
												<span class="post-comment">
													<?php comments_popup_link(
										            	esc_html__(' 0 comment', 'hozing'), 
										            	esc_html__(' 1 comment', 'hozing'), 
										            	' % comments'.esc_html__('', 'hozing'),
										            	'',
								                  		esc_html__( 'Comment off', 'hozing' )
										            ); ?>
												</span>
											</div>
										<?php endif; ?>
										<?php if ( $show_excerpt === "yes" ) : ?>
											<div class="post-excerpt">
												<?php the_excerpt() ?>
											</div>
										<?php endif; ?>
										<?php if ($show_readmore === "yes") : ?>
											<div class="post-readmore">
												<a href="<?php the_permalink() ?>"><?php echo $text_read_more ?></a>
											</div>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
				<?php
					endwhile; endif; wp_reset_postdata();
				?>
				<?php if ($show_view_all === "yes") : ?>
					<div class="ova-button-view-all">
						<a href=""><?php echo $text_view_all ?></a>
					</div>
				<?php endif; ?>
						
						
			</div>
				<!-- end ova-blog -->
			<?php endif ?>
			<!-- endif blog 1,2,3 -->

			<!-- blog 4 -->
			<?php if ($version_blog === 'blog_version_4') : ?>
				<div class="ova-blog-element <?php echo $version_blog ?>">
					<div class="grid-list">
						<?php
							$i = 0;
							if($blog->have_posts()) : while($blog->have_posts()) : $blog->the_post();
								$i++;
								$thumbnail_url = wp_get_attachment_image_url(get_post_thumbnail_id() , 'full' );
								$the_time = get_the_time( get_option( 'date_format' ));
								switch ($i) {
									case 1:
										$text_alpha = "a";
										break;
									case 2: 
										$text_alpha = "b";
										break;
									case 3:
										$text_alpha = "c";
										break;
									default:
										$text_alpha = "";
										break;
								}
								
						?>
						<div class="post-item item-<?php echo $i ?>">
							<div class="post-media" style="background-image: url(<?php echo $thumbnail_url ?>)">
								<a href="<?php the_permalink() ?>" class="overlay"></a>
							</div>
							<div class="image-alpha">
								<a href="<?php the_permalink() ?>"><?php echo $text_alpha ?></a>
							</div>
							
							<div class="info-item">
								<?php if ( $show_title === 'yes' ) : ?>
									<div class="post-title">
										<h2><a class="second_font" href="<?php the_permalink() ?>"><?php echo hozing_custom_text(get_the_title(), 4) ?></a></h2>
									</div>
								<?php endif; ?>
								<?php if ($show_date === 'yes') : ?>
									<div class="post-meta">
										<span class="post-date"><?php the_time( get_option( 'date_format' )) ?></span>
									</div>
								<?php endif; ?>
								<?php if ( $show_excerpt === "yes" ) : ?>
									<div class="post-excerpt">
										<?php echo hozing_custom_text(get_the_excerpt(), 12) ?>
									</div>
								<?php endif; ?>
							</div>
							<!-- end info-item -->

						</div>
						<!-- end post-item -->
						<?php endwhile;endif; wp_reset_postdata(); ?>
					</div>
					<!-- end grid-list -->
					<?php if ($show_view_all === "yes") : ?>
						<div class="ova-button-view-all">
							<a href=""><?php echo $text_view_all ?></a>
						</div>
					<?php endif; ?>
				</div>
				<!-- end ova-blog-element -->
			<?php endif ?>
			<!-- endif blog 4 -->
		<?php
	}
}
