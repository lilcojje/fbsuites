<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_room_images extends Widget_Base {

	public function get_name() {
		return 'ova_room_images';
	}

	public function get_title() {
		return __( 'Room Images', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-image-box';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
			'section_room_style',
			[
				'label' => __( 'Room Gallery Style', 'ova-framework' ),
				//'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'room_conditions',
				[
					'label'   => __( 'Gallery Style', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'room_style1',
					'options' => [
						'room_style1' => __( 'Room Image Style 1', 'ova-framework' ),
						'room_style2' => __( 'Room Image Style 2', 'ova-framework' ),
					],

				]
			);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_room_style_1',
			[
				'label' => __( 'Room Gallery style 1', 'ova-framework' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'room_conditions' => 'room_style1',
				]
			]
		);

			$this->add_control(
				'image_1',
				[
					'label' => __( 'Choose Image 1', 'ova-framework' ),
					'type' => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);
		
			$this->add_control(
				'title_room1',
				[
					'label' => __( 'Title & Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( 'Single Bed Room', 'ova-framework' ),
					'placeholder' => __( 'Enter your title', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'price_room1',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( '$200', 'ova-framework' ),
					'placeholder' => __( 'Enter your price', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'acreage_1',
				[
					'label' => __( 'Acreage', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true
					],
					'default' => __( '24m2', 'ova-framework'),
					'placeholder' => __( 'Enter your acreage', 'ova-framework'),
					'label_block' => true
				]
			);

			$this->add_control(
				'adults_1',
				[
					'label' => __( 'Adults Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 2,
				]
			);

			$this->add_control(
				'childrens_1',
				[
					'label' => __( 'Childrens Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 4,
				]
			);

			$this->add_control(
				'link_1',
				[
					'label' => __( 'Link to room 1', 'ova-framework' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'separator' => 'after',
				]
			);

			$this->add_control(
				'image_2',
				[
					'label' => __( 'Choose Image 2', 'ova-framework' ),
					'type' => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);
		
			$this->add_control(
				'title_room2',
				[
					'label' => __( 'Title & Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( 'Single Bed Room', 'ova-framework' ),
					'placeholder' => __( 'Enter your title', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'price_room2',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( '$200', 'ova-framework' ),
					'placeholder' => __( 'Enter your price', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'acreage_2',
				[
					'label' => __( 'Acreage', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true
					],
					'default' => __( '24m2', 'ova-framework'),
					'placeholder' => __( 'Enter your acreage', 'ova-framework'),
					'label_block' => true
				]
			);

			$this->add_control(
				'adults_2',
				[
					'label' => __( 'Adults Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 2,
				]
			);

			$this->add_control(
				'childrens_2',
				[
					'label' => __( 'Childrens Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 4,
				]
			);

			$this->add_control(
				'link_2',
				[
					'label' => __( 'Link to room 2', 'ova-framework' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'separator' => 'after',
				]
			);
			
			$this->add_control(
				'image_3',
				[
					'label' => __( 'Choose Image 3', 'ova-framework' ),
					'type' => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);

			$this->add_control(
				'title_room3',
				[
					'label' => __( 'Title & Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( 'Single Bed Room', 'ova-framework' ),
					'placeholder' => __( 'Enter your title', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'price_room3',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( '$200', 'ova-framework' ),
					'placeholder' => __( 'Enter your price', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'acreage_3',
				[
					'label' => __( 'Acreage', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true
					],
					'default' => __( '24m2', 'ova-framework'),
					'placeholder' => __( 'Enter your acreage', 'ova-framework'),
					'label_block' => true
				]
			);

			$this->add_control(
				'adults_3',
				[
					'label' => __( 'Adults Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 2,
				]
			);

			$this->add_control(
				'childrens_3',
				[
					'label' => __( 'Childrens Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 4,
				]
			);

			$this->add_control(
				'link_3',
				[
					'label' => __( 'Link to room 3', 'ova-framework' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'separator' => 'after',
				]
			);

			$this->add_control(
				'image_4',
				[
					'label' => __( 'Choose Image 4', 'ova-framework' ),
					'type' => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);
		
			$this->add_control(
				'title_room4',
				[
					'label' => __( 'Title & Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( 'Single Bed Room', 'ova-framework' ),
					'placeholder' => __( 'Enter your title', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'price_room4',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( '$200', 'ova-framework' ),
					'placeholder' => __( 'Enter your price', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'acreage_4',
				[
					'label' => __( 'Acreage', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true
					],
					'default' => __( '24m2', 'ova-framework'),
					'placeholder' => __( 'Enter your acreage', 'ova-framework'),
					'label_block' => true
				]
			);

			$this->add_control(
				'adults_4',
				[
					'label' => __( 'Adults Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 2,
				]
			);

			$this->add_control(
				'childrens_4',
				[
					'label' => __( 'Childrens Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 4,
				]
			);

			$this->add_control(
				'link_4',
				[
					'label' => __( 'Link to room 4', 'ova-framework' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'separator' => 'after',
				]
			);

			$this->add_control(
				'image_5',
				[
					'label' => __( 'Choose Image 5', 'ova-framework' ),
					'type' => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);

			$this->add_control(
				'title_room5',
				[
					'label' => __( 'Title & Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( 'Single Bed Room', 'ova-framework' ),
					'placeholder' => __( 'Enter your title', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'price_room5',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( '$200', 'ova-framework' ),
					'placeholder' => __( 'Enter your price', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'acreage_5',
				[
					'label' => __( 'Acreage', 'ova-framework'),
					'type'  => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true
					],
					'default' => __( '24m2', 'ova-framework'),
					'placeholder' => __( 'Enter your acreage', 'ova-framework'),
					'label_block' => true
				]
			);

			$this->add_control(
				'adults_5',
				[
					'label' => __( 'Adults Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 2,
				]
			);

			$this->add_control(
				'childrens_5',
				[
					'label' => __( 'Childrens Max', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 4,
				]
			);

			$this->add_control(
				'link_5',
				[
					'label' => __( 'Link to room 5', 'ova-framework' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'separator' => 'after',
				]
			);

			$this->add_control(
				'title_size',
				[
					'label' => __( 'Title HTML Tag', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'h1' => 'H1',
						'h2' => 'H2',
						'h3' => 'H3',
						'h4' => 'H4',
						'h5' => 'H5',
						'h6' => 'H6',
					],
					'default' => 'h3',
				]
			);

			$this->add_control(
				'view_all_room',
				[
					'label' => __( 'View All Room', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => __( 'view all room', 'ova-framework' ),
					'placeholder' => __( 'Enter your text', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'link_view_room',
				[
					'label' => __( 'Link to room category', 'ova-framework' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'separator' => 'before',
				]
			);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_room_style_2',
			[
				'label' => __( 'Room Gallery Style 2', 'ova-framework' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'room_conditions' => 'room_style2',
				]
			]
		);

		$repeater = new Repeater();

		$repeater->start_controls_tabs( 'slides_repeater' );


		$repeater->start_controls_tab( 'content', [ 'label' => __( 'Content', 'ova-framework' ) ] );

		$repeater->add_control(
			'room_image',
			[
				'label' => __( 'Choose Image', 'ova-framework' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'description',
			[
				'label' => __( 'Content', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias', 'ova-framework' ),
				'dynamic' => [
					'active' => true,
				],
				'show_label' => true,
			]
		);

		$repeater->add_control(
			'room_brand',
			[
				'label' => __( 'Choose Image Brand', 'ova-framework' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => OVA_PLUGIN_URI.'/assets/img/room_brand.png',
				],
			]
		);

		$repeater->add_control(
			'title_rooms',
			[
				'label' => __( 'Title Room', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Single Bed Room', 'ova-framework' ),
				'dynamic' => [
					'active' => true,
				],
				'show_label' => true
			]
		);	

		$repeater->add_control(
			'link_rooms',
			[
				'label' => __( 'Link to room', 'ova-framework' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
			]
		);

		$repeater->add_control(
			'button_text',
			[
				'label' => __( 'Book Now', 'ova-framework'),
				'type'  => Controls_Manager::TEXT,
				'default' => __( 'Book Now', 'ova-framework'),
				'dynamic' => [
					'active' => true,
				],
				'show_label' => true
			]

		);

		$repeater->end_controls_tabs();

		$this->add_control(
			'item_rooms',
			[
				'label' => __( 'Add Room Items', 'ova-framework' ),
				'type' => Controls_Manager::REPEATER,
				'show_label' => true,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'description' => __( 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias', 'ova-framework'),
					],
					[
						'description' => __( 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias', 'ova-framework'),
					],
					[
						'description' => __( 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias', 'ova-framework'),
					],
					[
						'description' => __( 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias', 'ova-framework'),
					],
				],
				'dynamic' => [
					'active' => true,
				],

			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_options',
			[
				'label' => __( 'Room Gallery Options', 'ova-framework' ),
				'type' => Controls_Manager::SECTION,
			]
		);

			$this->add_control(
				'show_view_all',
				[
					'label'   => __('Show View All Room', 'ova-framework'),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'room_conditions' => 'room_style1',
					]
				]
			);

			$this->add_control(
				'show_room_info',
				[
					'label'   => __('Show Room Info', 'ova-framework'),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'room_conditions' => 'room_style1',
					]
				]
				
			);

			$this->add_control(
				'show_logo_brand',
				[
					'label'   => __('Show Logo Brand', 'ova-framework'),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'room_conditions' => 'room_style2',
					]
				]
				
			);

			$this->add_control(
				'show_title_room',
				[
					'label'   => __('Show Logo', 'ova-framework'),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'room_conditions' => 'room_style2',
					]
				]
				
			);

			$this->add_control(
				'show_description',
				[
					'label'   => __('Show Descriotion', 'ova-framework'),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'room_conditions' => 'room_style2',
					]
				]
				
			);

			$this->add_control(
				'show_button_booking',
				[
					'label'   => __('Show Button', 'ova-framework'),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'condition' => [
						'room_conditions' => 'room_style2',
					]
				]
				
			);
								
		$this->end_controls_section();

		// Room Images style 1 start_controls_section

		$this->start_controls_section(
			'section_room_style1',
			[
				'label' => __( 'Background Label Title & Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style1'
				]
			]
		);

			$this->add_control(
				'background_room_style1_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .grid-style1 .room-info' => 'background-color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();	

		$this->start_controls_section(
			'section_title_room_style1',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style1'
				]
			]
		);
			
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_1',
					'label' => __( 'Typography', 'ova-framework' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_3,
					'selector' => '{{WRAPPER}} .room-title',
					'fields_options' => [
						
						'font_weight' => [
							'default' => '400',
						],
						'font_family' => [
							'default' => 'Roboto Condensed',
						],
						'font_size' => [ 'default' => [ 'unit' => 'px', 'size' => 18 ] ]
					],
				]
			);

			$this->add_control(
				'title_room_style1_color',
				[
					'label' => __( 'Title Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000000',
					'selectors' => [
						'{{WRAPPER}} .room-title' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'title_room_style1_hover_color',
				[
					'label' => __( 'Title Hover Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .room-title:hover' => 'color: {{VALUE}};',
					],
				]
			);
			
			$this->add_responsive_control(
				'title_room_style1_padding',
				[
					'label' => __( 'Title Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .room-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'title_room_style1_align',
				[
					'label' => __( 'Title Alignment', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'ova-framework' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'ova-framework' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'ova-framework' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .room-title' => 'text-align: {{VALUE}}',
					],
					'toggle' => true,
				]
			);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'section_price_room_style1',
			[
				'label' => __( 'Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style1'
				]
			]
		);
			
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography',
					'label' => __( 'Typography', 'ova-framework' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .room-title',
					'fields_options' => [
						
						'font_weight' => [
							'default' => '600',
						],
						'font_family' => [
							'default' => 'Roboto Condensed',
						],
						'font_size' => [ 'default' => [ 'unit' => 'px', 'size' => 18 ] ]
					],
				]
			);

			$this->add_control(
				'price_room_color',
				[
					'label' => __( 'Price Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .price_room' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'price_room_hover_color',
				[
					'label' => __( 'Price Hover Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .price_room:hover' => 'color: {{VALUE}};',
					],
				]
			);
			
			$this->add_responsive_control(
				'price_room_padding',
				[
					'label' => __( 'Price Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .price_room' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'price_room_align',
				[
					'label' => __( 'Title Alignment', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'ova-framework' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'ova-framework' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'ova-framework' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .price_room' => 'text-align: {{VALUE}}',
					],
					'toggle' => true,
				]
			);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'section_info_room_style1',
			[
				'label' => __( 'Info Room', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style1'
				]
			]
		);

			$this->add_control(
				'background_color_room_info',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#ffffff',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .specical-infor li' => 'background-color: {{VALUE}};',
					],
				]
			);
			
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'info_room_typography',
					'label' => __( 'Typography', 'ova-framework' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_3,
					'selector' => '{{WRAPPER}} .specical-infor li span',
					'fields_options' => [
						
						'font_weight' => [
							'default' => '400',
						],
						'font_family' => [
							'default' => 'Roboto Condensed',
						],
						'font_size' => [ 'default' => [ 'unit' => 'px', 'size' => 16 ] ]
					],
				]
			);

			$this->add_control(
				'info_room_color',
				[
					'label' => __( 'Info Room Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000000',
					'selectors' => [
						'{{WRAPPER}} .specical-infor li span' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'info_room_hover_color',
				[
					'label' => __( 'Info Room Hover Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'selectors' => [
						'{{WRAPPER}} .specical-infor li span:hover' => 'color: {{VALUE}};',
					],
				]
			);
			
			$this->add_responsive_control(
				'info_room_padding',
				[
					'label' => __( 'Info Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .specical-infor li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'info_room_align',
				[
					'label' => __( 'Title Alignment', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'ova-framework' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'ova-framework' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'ova-framework' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .specical-infor' => 'text-align: {{VALUE}}',
					],
					'toggle' => true,
				]
			);
			
		$this->end_controls_section();
		// Room Images style 2 controls section

		$this->start_controls_section(
			'section_title_room_style2',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style2'
				]
			]
		);
			
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography_2',
					'label' => __( 'Typography', 'ova-framework' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .room-title',
					'fields_options' => [
						'font_style'  => [
							'default' => 'italic'
						],
						'font_weight' => [
							'default' => '500',
						],
						'font_family' => [
							'default' => 'Playfair Display',
						],
						'font_size' => [ 'default' => [ 'unit' => 'px', 'size' => 50 ] ]
					],
				]
			);

			$this->add_control(
				'title_room_style2_color',
				[
					'label' => __( 'Title Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#ffffff',
					'selectors' => [
						'{{WRAPPER}} .room-title' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'title_room_style2_hover_color',
				[
					'label' => __( 'Title Hover Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .room-title:hover' => 'color: {{VALUE}};',
					],
				]
			);
			
			$this->add_responsive_control(
				'title_room_style2_padding',
				[
					'label' => __( 'Title Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .room-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'title_room_style2_align',
				[
					'label' => __( 'Title Alignment', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'ova-framework' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'ova-framework' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'ova-framework' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'selectors' => [
						'{{WRAPPER}} .room-title' => 'text-align: {{VALUE}}',
					],
					'toggle' => true,
				]
			);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'section_description_room_style2',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style2'
				]
			]
		);

		$this->add_control(
			'description_room_style2_color',
			[
				'label'     => __( 'Text Color', 'ova-framework' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .descriptions' => 'color: {{VALUE}}',

				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_2,
				'selector' => '{{WRAPPER}} .descriptions',
			]
		);

		$this->add_responsive_control(
				'description_room_style2_padding',
				[
					'label' => __( 'Description Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .descriptions' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

		$this->add_control(
			'description_room_style2_text_align',
			[
				'label' => __( 'Text Align', 'ova-framework' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'ova-framework' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'ova-framework' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'ova-framework' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .descriptions' => 'text-align: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_booking',
			[
				'label' => __( 'Button Booking', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style2'
				]
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'button_booking_typography',
					'label' => __( 'Typography', 'ova-framework' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .button_booking_now .booking_now',
					'fields_options' => [

						'font_weight' => [
							'default' => '600',
						],
						'font_family' => [
							'default' => 'Roboto Condensed',
						],
						'font_size' => [ 'default' => [ 'unit' => 'px', 'size' => 16 ] ]
					]
				]
			);

			$this->add_control(
				'button_booking_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#ffffff',
					'selectors' => [
						'{{WRAPPER}} .button_booking_now .booking_now' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_booking_hover',
				[
					'label' => __( 'Text Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#ffffff',
					'selectors' => [
						'{{WRAPPER}} .button_booking_now .booking_now:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_booking_background',
				[
					'label' => __( 'Background', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .button_booking_now' => 'background: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_booking_background_hover',
				[
					'label' => __( 'Background Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000000',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .button_booking_now:hover' => 'background: {{VALUE}};',
					],
				]
			);
			
		$this->end_controls_section();
			
		// View ALl coltrols section

		$this->start_controls_section(
			'section_view_all',
			[
				'label' => __( 'View All', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'room_conditions' => 'room_style1'
				]
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'view_all_typography',
					'label' => __( 'Typography', 'ova-framework' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .views-all-room .room_all',
					'fields_options' => [
						'text_transform' => [
							'default' => 'uppercase',
						],
						'font_weight' => [
							'default' => '600',
						],
						'font_family' => [
							'default' => 'Roboto Condensed',
						],
						'font_size' => [ 'default' => [ 'unit' => 'px', 'size' => 16 ] ]
					]
				]
			);

			$this->add_control(
				'view_all_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#000000',
					'selectors' => [
						'{{WRAPPER}} .views-all-room a.room_all' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'view_all_color_hover',
				[
					'label' => __( 'Text Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#ffffff',
					'selectors' => [
						'{{WRAPPER}} .views-all-room a.room_all:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'view_all_background',
				[
					'label' => __( 'Background', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#ffffff',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .views-all-room a.room_all' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'view_all_background_hover',
				[
					'label' => __( 'Background Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .views-all-room a.room_all:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			
			$this->add_control(
				'view_all_border_background',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .views-all-room a.room_all' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'view_all_border_background_hover',
				[
					'label' => __( 'Border Hover Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#b9a271',
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'selectors' => [
						'{{WRAPPER}} .views-all-room a.room_all:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			
		$this->end_controls_section();

		// View All end_coltrols_section
				
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$has_content_one   = ! empty( $settings['title_room1'] ) || ! empty( $settings['price_room1'] );
		$has_content_two   = ! empty( $settings['title_room2'] ) || ! empty( $settings['price_room2'] );
		$has_content_three = ! empty( $settings['title_room3'] ) || ! empty( $settings['price_room3'] );
		$has_content_four  = ! empty( $settings['title_room4'] ) || ! empty( $settings['price_room4'] );
		$has_content_five  = ! empty( $settings['title_room5'] ) || ! empty( $settings['price_room1'] );


		$link_images_1 = $settings['image_1']['url'];
		$link_images_2 = $settings['image_2']['url'];
		$link_images_3 = $settings['image_3']['url'];
		$link_images_4 = $settings['image_4']['url'];
		$link_images_5 = $settings['image_5']['url'];


		$html = '<div class="room-wrapper">';
			if( $settings['room_conditions'] == 'room_style1'){
				$html .= '<div class="grid-style1">';
					$html .= '<div class="item-1 brg-item" style="background-image: url('.$link_images_1.');">';
							if ( ! empty( $settings['link_1']['url'] ) ) {
								$this->add_render_attribute( 'link1', 'href', $settings['link_1']['url'] );

								if ( $settings['link_1']['is_external'] ) {
									$this->add_render_attribute( 'link1', 'target', '_blank' );
								}

								if ( ! empty( $settings['link_1']['nofollow'] ) ) {
									$this->add_render_attribute( 'link1', 'rel', 'nofollow' );
								}
							}

							if ( ! empty( $settings['image_1']['url'] ) ) {
								$this->add_render_attribute( 'image', 'src', $settings['image_1']['url'] );
								$this->add_render_attribute( 'image', 'alt', Control_Media::get_image_alt( $settings['image_1'] ) );
								$this->add_render_attribute( 'image', 'title', Control_Media::get_image_title( $settings['image_1'] ) );

								if ( ! empty( $settings['link_2']['url'] ) ) {
									$image_html = '<a class="room-images" ' . $this->get_render_attribute_string( 'link1' ) . '></a>';
									$html .= $image_html;
								}
							}

							if ( $has_content_one ) {
								$html .= '<div class="room-content"><div class="d-inline-flex room-info">';

								if ( ! empty( $settings['title_room1'] ) ) {
									$this->add_render_attribute( 'title_room1', 'class', 'room-title' );

									$this->add_inline_editing_attributes( 'title_room1', 'none' );

									$title_html = $settings['title_room1'];

									if ( ! empty( $settings['link_1']['url'] ) ) {
										$title_html = '<a ' . $this->get_render_attribute_string( 'link1' ) . '>' . $title_html . '</a>';
									}

									$html .= sprintf( '<%1$s %2$s>%3$s</%1$s>', $settings['title_size'], $this->get_render_attribute_string( 'title_room1' ), $title_html );
								}

								if ( ! empty( $settings['price_room1'] ) ) {
									$this->add_render_attribute( 'price_room1', 'class', 'price_room' );

									$this->add_inline_editing_attributes( 'price_room1' );

									$html .= sprintf( '<span %1$s>%2$s</span>', $this->get_render_attribute_string( 'price_room1' ), $settings['price_room1'] );
								}

								$html .= '</div></div>';
								if( $settings['show_room_info'] == 'yes'){
								$html .= '<ul class="specical-infor">';

									if( ! empty( $settings['acreage_1'] ) ){
										$this->add_render_attribute('acreage_1', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'acreage_1', 'none');

										$data_html = '<span>'.$settings['acreage_1'].'</span>';

										$html .= sprintf( '<li %1$s>%2$s</li>', $this->get_render_attribute_string('acreage_1'), $data_html);
									}

									if( ! empty( $settings['adults_1'] ) ){
										$this->add_render_attribute('adults_1', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'adults_1', 'none');

										$data_html = '<span>'.$settings['adults_1'].esc_html__(' Adults').'</span>';

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('adults_1'), $data_html);
									}

									if( ! empty( $settings['childrens_1'] ) ){
										$this->add_render_attribute('childrens_1', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'childrens_1', 'none');

										$data_html = "<span>".$settings['childrens_1'].esc_html__(' Childrends')."</span>";

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('childrens_1'), $data_html);
									}

								$html .= '</ul>';
								}
							}
					$html .= '</div>';

					$html .= '<div class="item-2 brg-item" style="background-image: url('.$link_images_2.');">';
							if ( ! empty( $settings['link_2']['url'] ) ) {
								$this->add_render_attribute( 'link2', 'href', $settings['link_2']['url'] );

								if ( $settings['link_2']['is_external'] ) {
									$this->add_render_attribute( 'link2', 'target', '_blank' );
								}

								if ( ! empty( $settings['link_2']['nofollow'] ) ) {
									$this->add_render_attribute( 'link2', 'rel', 'nofollow' );
								}
							}

							if ( ! empty( $settings['image_2']['url'] ) ) {
								$this->add_render_attribute( 'image', 'src', $settings['image_2']['url'] );
								$this->add_render_attribute( 'image', 'alt', Control_Media::get_image_alt( $settings['image_2'] ) );
								$this->add_render_attribute( 'image', 'title', Control_Media::get_image_title( $settings['image_2'] ) );

								if ( ! empty( $settings['link_2']['url'] ) ) {
									$image_html = '<a class="room-images" ' . $this->get_render_attribute_string( 'link2' ) . '></a>';
									$html .= $image_html;
								}
							}

							if ( $has_content_two ) {
								$html .= '<div class="room-content"><div class="d-inline-flex room-info">';

								if ( ! empty( $settings['title_room2'] ) ) {
									$this->add_render_attribute( 'title_room2', 'class', 'room-title' );

									$this->add_inline_editing_attributes( 'title_room2', 'none' );

									$title_html = $settings['title_room2'];

									if ( ! empty( $settings['link_2']['url'] ) ) {
										$title_html = '<a ' . $this->get_render_attribute_string( 'link2' ) . '>' . $title_html . '</a>';
									}

									$html .= sprintf( '<%1$s %2$s>%3$s</%1$s>', $settings['title_size'], $this->get_render_attribute_string( 'title_room2' ), $title_html );
								}

								if ( ! empty( $settings['price_room2'] ) ) {
									$this->add_render_attribute( 'price_room2', 'class', 'price_room' );

									$this->add_inline_editing_attributes( 'price_room2' );

									$html .= sprintf( '<span %1$s>%2$s</span>', $this->get_render_attribute_string( 'price_room2' ), $settings['price_room2'] );
								}

								$html .= '</div></div>';
								if( $settings['show_room_info'] == 'yes'){
								$html .= '<ul class="specical-infor">';

									if( ! empty( $settings['acreage_2'] ) ){
										$this->add_render_attribute('acreage_2', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'acreage_2', 'none');

										$data_html = '<span>'.$settings['acreage_2'].'</span>';

										$html .= sprintf( '<li %1$s>%2$s</li>', $this->get_render_attribute_string('acreage_2'), $data_html);
									}

									if( ! empty( $settings['adults_2'] ) ){
										$this->add_render_attribute('adults_2', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'adults_2', 'none');

										$data_html = '<span>'.$settings['adults_2'].esc_html__(' Adults').'</span>';

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('adults_2'), $data_html);
									}

									if( ! empty( $settings['childrens_2'] ) ){
										$this->add_render_attribute('childrens_2', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'childrens_2', 'none');

										$data_html = "<span>".$settings['childrens_2'].esc_html__(' Childrends')."</span>";

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('childrens_2'), $data_html);
									}

								$html .= '</ul>';
								}
							}
					$html .= '</div>';

					$html .= '<div class="item-3 brg-item" style="background-image: url('.$link_images_3.');">';
							if ( ! empty( $settings['link_3']['url'] ) ) {
								$this->add_render_attribute( 'link3', 'href', $settings['link_3']['url'] );

								if ( $settings['link_3']['is_external'] ) {
									$this->add_render_attribute( 'link3', 'target', '_blank' );
								}

								if ( ! empty( $settings['link_3']['nofollow'] ) ) {
									$this->add_render_attribute( 'link3', 'rel', 'nofollow' );
								}
							}

							if ( ! empty( $settings['image_3']['url'] ) ) {
								$this->add_render_attribute( 'image', 'src', $settings['image_3']['url'] );
								$this->add_render_attribute( 'image', 'alt', Control_Media::get_image_alt( $settings['image_3'] ) );
								$this->add_render_attribute( 'image', 'title', Control_Media::get_image_title( $settings['image_3'] ) );

								if ( ! empty( $settings['link_3']['url'] ) ) {
									$image_html = '<a class="room-images" ' . $this->get_render_attribute_string( 'link3' ) . '></a>';
									$html .= $image_html;
								}
							}

							if ( $has_content_three ) {
								$html .= '<div class="room-content"><div class="d-inline-flex room-info">';

								if ( ! empty( $settings['title_room3'] ) ) {
									$this->add_render_attribute( 'title_room3', 'class', 'room-title' );

									$this->add_inline_editing_attributes( 'title_room2', 'none' );

									$title_html = $settings['title_room3'];

									if ( ! empty( $settings['link_3']['url'] ) ) {
										$title_html = '<a ' . $this->get_render_attribute_string( 'link3' ) . '>' . $title_html . '</a>';
									}

									$html .= sprintf( '<%1$s %2$s>%3$s</%1$s>', $settings['title_size'], $this->get_render_attribute_string( 'title_room3' ), $title_html );
								}

								if ( ! empty( $settings['price_room3'] ) ) {
									$this->add_render_attribute( 'price_room3', 'class', 'price_room' );

									$this->add_inline_editing_attributes( 'price_room3' );

									$html .= sprintf( '<span %1$s>%2$s</span>', $this->get_render_attribute_string( 'price_room3' ), $settings['price_room3'] );
								}

								$html .= '</div></div>';
								if( $settings['show_room_info'] == 'yes'){ 
								$html .= '<ul class="specical-infor">';

									if( ! empty( $settings['acreage_3'] ) ){
										$this->add_render_attribute('acreage_3', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'acreage_3', 'none');

										$data_html = '<span>'.$settings['acreage_3'].'</span>';

										$html .= sprintf( '<li %1$s>%2$s</li>', $this->get_render_attribute_string('acreage_3'), $data_html);
									}

									if( ! empty( $settings['adults_3'] ) ){
										$this->add_render_attribute('adults_3', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'adults_3', 'none');

										$data_html = '<span>'.$settings['adults_3'].esc_html__(' Adults').'</span>';

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('adults_3'), $data_html);
									}

									if( ! empty( $settings['childrens_3'] ) ){
										$this->add_render_attribute('childrens_3', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'childrens_3', 'none');

										$data_html = "<span>".$settings['childrens_3'].esc_html__(' Childrends')."</span>";

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('childrens_3'), $data_html);
									}

								$html .= '</ul>';
								}
							}
					$html .= '</div>';

					$html .= '<div class="item-4 brg-item" style="background-image: url('.$link_images_4.');">';
							if ( ! empty( $settings['link_4']['url'] ) ) {
								$this->add_render_attribute( 'link4', 'href', $settings['link_4']['url'] );

								if ( $settings['link_4']['is_external'] ) {
									$this->add_render_attribute( 'link4', 'target', '_blank' );
								}

								if ( ! empty( $settings['link_4']['nofollow'] ) ) {
									$this->add_render_attribute( 'link4', 'rel', 'nofollow' );
								}
							}

							if ( ! empty( $settings['image_4']['url'] ) ) {
								$this->add_render_attribute( 'image', 'src', $settings['image_4']['url'] );
								$this->add_render_attribute( 'image', 'alt', Control_Media::get_image_alt( $settings['image_4'] ) );
								$this->add_render_attribute( 'image', 'title', Control_Media::get_image_title( $settings['image_4'] ) );

								if ( ! empty( $settings['link_4']['url'] ) ) {
									$image_html = '<a class="room-images" ' . $this->get_render_attribute_string( 'link4' ) . '></a>';
									$html .= $image_html;
								}
							}

							if ( $has_content_four ) {
								$html .= '<div class="room-content"><div class="d-inline-flex room-info">';

								if ( ! empty( $settings['title_room4'] ) ) {
									$this->add_render_attribute( 'title_room4', 'class', 'room-title' );

									$this->add_inline_editing_attributes( 'title_room2', 'none' );

									$title_html = $settings['title_room4'];

									if ( ! empty( $settings['link_4']['url'] ) ) {
										$title_html = '<a ' . $this->get_render_attribute_string( 'link4' ) . '>' . $title_html . '</a>';
									}

									$html .= sprintf( '<%1$s %2$s>%3$s</%1$s>', $settings['title_size'], $this->get_render_attribute_string( 'title_room4' ), $title_html );
								}

								if ( ! empty( $settings['price_room4'] ) ) {
									$this->add_render_attribute( 'price_room4', 'class', 'price_room' );

									$this->add_inline_editing_attributes( 'price_room4' );

									$html .= sprintf( '<span %1$s>%2$s</span>', $this->get_render_attribute_string( 'price_room4' ), $settings['price_room4'] );
								}

								$html .= '</div></div>';
								if( $settings['show_room_info'] == 'yes'){
								$html .= '<ul class="specical-infor">';

									if( ! empty( $settings['acreage_4'] ) ){
										$this->add_render_attribute('acreage_4', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'acreage_4', 'none');

										$data_html = '<span>'.$settings['acreage_4'].'</span>';

										$html .= sprintf( '<li %1$s>%2$s</li>', $this->get_render_attribute_string('acreage_4'), $data_html);
									}

									if( ! empty( $settings['adults_4'] ) ){
										$this->add_render_attribute('adults_4', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'adults_4', 'none');

										$data_html = '<span>'.$settings['adults_4'].esc_html__(' Adults').'</span>';

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('adults_4'), $data_html);
									}

									if( ! empty( $settings['childrens_4'] ) ){
										$this->add_render_attribute('childrens_4', 'class', 'd-inline-flex');
										$this->add_inline_editing_attributes( 'childrens_4', 'none');

										$data_html = "<span>".$settings['childrens_4'].esc_html__(' Childrends')."</span>";

										$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('childrens_4'), $data_html);
									}

								$html .= '</ul>';
								}
							}
					$html .= '</div>';

					$html .= '<div class="item-5 brg-item" style="background-image: url('.$link_images_5.');">';
							if ( ! empty( $settings['link_5']['url'] ) ) {
								$this->add_render_attribute( 'link5', 'href', $settings['link_5']['url'] );

								if ( $settings['link_5']['is_external'] ) {
									$this->add_render_attribute( 'link5', 'target', '_blank' );
								}

								if ( ! empty( $settings['link_5']['nofollow'] ) ) {
									$this->add_render_attribute( 'link5', 'rel', 'nofollow' );
								}
							}

							if ( ! empty( $settings['image_5']['url'] ) ) {
								$this->add_render_attribute( 'image', 'src', $settings['image_5']['url'] );
								$this->add_render_attribute( 'image', 'alt', Control_Media::get_image_alt( $settings['image_5'] ) );
								$this->add_render_attribute( 'image', 'title', Control_Media::get_image_title( $settings['image_5'] ) );


								if ( ! empty( $settings['link_5']['url'] ) ) {
									$image_html = '<a class="room-images" ' . $this->get_render_attribute_string( 'link5' ) . '></a>';
									$html .= $image_html;
								}

								
							}

							if ( $has_content_five ) {
								$html .= '<div class="room-content"><div class="d-inline-flex room-info">';

								if ( ! empty( $settings['title_room5'] ) ) {
									$this->add_render_attribute( 'title_room5', 'class', 'room-title' );

									$this->add_inline_editing_attributes( 'title_room5', 'none' );

									$title_html = $settings['title_room5'];

									if ( ! empty( $settings['link_5']['url'] ) ) {
										$title_html = '<a ' . $this->get_render_attribute_string( 'link5' ) . '>' . $title_html . '</a>';
									}

									$html .= sprintf( '<%1$s %2$s>%3$s</%1$s>', $settings['title_size'], $this->get_render_attribute_string( 'title_room5' ), $title_html );
								}

								if ( ! empty( $settings['price_room5'] ) ) {
									$this->add_render_attribute( 'price_room5', 'class', 'price_room' );

									$this->add_inline_editing_attributes( 'price_room5' );

									$html .= sprintf( '<span %1$s>%2$s</span>', $this->get_render_attribute_string( 'price_room5' ), $settings['price_room5'] );
								}

								$html .= '</div></div>';
								if( $settings['show_room_info'] == 'yes'){
									$html .= '<ul class="specical-infor">';

										if( ! empty( $settings['acreage_5'] ) ){
											$this->add_render_attribute('acreage_5', 'class', 'd-inline-flex');
											$this->add_inline_editing_attributes( 'acreage_1', 'none');

											$data_html = '<span>'.$settings['acreage_5'].'</span>';

											$html .= sprintf( '<li %1$s>%2$s</li>', $this->get_render_attribute_string('acreage_5'), $data_html);
										}

										if( ! empty( $settings['adults_5'] ) ){
											$this->add_render_attribute('adults_5', 'class', 'd-inline-flex');
											$this->add_inline_editing_attributes( 'adults_5', 'none');

											$data_html = '<span>'.$settings['adults_5'].esc_html__(' Adults').'</span>';

											$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('adults_5'), $data_html);
										}

										if( ! empty( $settings['childrens_5'] ) ){
											$this->add_render_attribute('childrens_5', 'class', 'd-inline-flex');
											$this->add_inline_editing_attributes( 'childrens_5', 'none');

											$data_html = "<span>".$settings['childrens_5'].esc_html__(' Childrends')."</span>";

											$html .= sprintf('<li %1$s>%2$s</li>', $this->get_render_attribute_string('childrens_5'), $data_html);
										}

									$html .= '</ul>';
								}

							}
					$html .= '</div>';
				$html .= '</div>';
				if ( $settings['show_view_all'] == 'yes'){  
					$html .= '<div class="views-all-room">';
						
						if ( ! empty( $settings['link_view_room']['url'] ) ) {
							$this->add_render_attribute( 'link', 'href', $settings['link_view_room']['url'] );

							if ( $settings['link_view_room']['is_external'] ) {
								$this->add_render_attribute( 'link', 'target', '_blank' );
							}

							if ( ! empty( $settings['link_view_room']['nofollow'] ) ) {
								$this->add_render_attribute( 'link', 'rel', 'nofollow' );
							}
						}

						if ( ! empty( $settings['view_all_room'] ) ) {

							$this->add_render_attribute( 'view_all_room', 'class', 'room_all' );

							$this->add_inline_editing_attributes( 'view_all_room', 'none' );

							$room_all = $settings['view_all_room'];

							if ( ! empty( $settings['link_view_room']['url'] ) ) {

								$html .=  sprintf( '<a %1$s %2$s>%3$s</a>', $this->get_render_attribute_string('view_all_room'), $this->get_render_attribute_string('link'), $room_all );
							} else {

								$html .=  sprintf( '<a %1$s>%2$s</a>', $this->get_render_attribute_string('view_all_room'), $room_all );
							}

						}

					$html .= '</div>';
				}
			} elseif( $settings['room_conditions'] == 'room_style2') {

				$html .= '<div class="grid-style2">';

					if ( empty( $settings['item_rooms'] ) ) {
						return;
					}
					
					foreach ( $settings['item_rooms'] as $index => $item ) {


						$brg_images_room = $item['room_image']['url'];

						$html .= '<div class="item-room" style="background-image: url('.$brg_images_room.');">';

						$html .= '<div class="room-content"><div class="room-info">';

							if ( ! empty( $item['link_rooms']['url'] ) ) {
								$this->add_render_attribute( 'link', 'href', $item['link_rooms']['url'] );

								if ( $item['link_rooms']['is_external'] ) {
									$this->add_render_attribute( 'link', 'target', '_blank' );
								}

								if ( ! empty( $item['link_rooms']['nofollow'] ) ) {
									$this->add_render_attribute( 'link', 'rel', 'nofollow' );
								}
							}

							if ( ! empty( $item['room_brand']['url'] ) ) {
								$this->add_render_attribute( 'room_brand', 'src', $item['room_brand']['url'] );
								$this->add_render_attribute( 'room_brand', 'alt', Control_Media::get_image_alt( $item['room_brand'] ) );
								$this->add_render_attribute( 'room_brand', 'title', Control_Media::get_image_title( $item['room_brand'] ) );


								$image_html = Group_Control_Image_Size::get_attachment_image_html( $item, 'room_brand' );

								if ( ! empty( $settings['link_rooms']['url'] ) ) {
									$image_html = '<a ' . $this->get_render_attribute_string( 'link_rooms' ) . '>' . $image_html . '</a>';
								}
								if( $settings['show_logo_brand'] == 'yes'){
									$html .= '<figure class="img_brand">' . $image_html . '</figure>';
								}

							}

							if ( ! empty( $item['title_rooms'] ) ) {

								$title_rooms = $this->get_repeater_setting_key( 'title_rooms', 'item_rooms', $index );
								$this->add_render_attribute( $title_rooms, 'class', 'room-title' );
								$this->add_inline_editing_attributes( $title_rooms, 'none' );

								$title_html = $item['title_rooms'];

								if ( ! empty( $item['link_rooms']['url'] ) ) {
									$title_html = '<a ' . $this->get_render_attribute_string( 'link' ) . '>' . $title_html . '</a>';
								} else{
									$title_html =  $title_html;
								}
								if( $settings['show_title_room'] == 'yes'){
									$html .= sprintf( '<h3 %1$s >%2$s</h3>', $this->get_render_attribute_string( $title_rooms ), $title_html );
								}
							}
							

							if ( !empty( $item['description'] )) {

								$description = $this->get_repeater_setting_key( 'description', 'item_rooms', $index );
								$this->add_render_attribute( $description , 'class', 'descriptions');
								$this->add_inline_editing_attributes( $description, 'none' );
								if( $settings['show_description'] == 'yes'){
									$html .= sprintf('<p %1$s >%2$s</p>', $this->get_render_attribute_string( $description ), $this->parse_text_editor( $item['description'] ) );
								}
							}

							

							if ( !empty( $item['button_text'])){

								$booking_button = $this->get_repeater_setting_key( 'button_text', 'item_rooms', $index );
								$this->add_render_attribute( $booking_button, 'class', 'button_booking_now' );

								$booking = $item['button_text'];

								$link_att = $this->get_repeater_setting_key( 'link_rooms', 'item_rooms', $index );
								$this->add_render_attribute( $link_att, 'class', 'booking_now' );
								$this->add_inline_editing_attributes( $link_att, 'none' );

								if ( ! empty( $item['link_rooms']['url'] ) ) {
									$booking = sprintf( '<a %1$s%2$s>%3$s</a>', $this->get_render_attribute_string( 'link' ), $this->get_render_attribute_string( $link_att ), $booking );
								} else {
									$booking = sprintf( '<a %1$s>%2$s</a>', $this->get_render_attribute_string( $link_att ), $booking );
								}
								if( $settings['show_button_booking'] == 'yes'){
									$html .=  sprintf( '<div %1$s>%2$s</div>', $this->get_render_attribute_string($booking_button), $booking );
								}								

							}

							
						$html .= '</div></div>';

						$html .= '</div>';						
						
					}

				$html .= '</div>';
			}
		$html .= '</div>';

		echo $html;
	}
	
}
