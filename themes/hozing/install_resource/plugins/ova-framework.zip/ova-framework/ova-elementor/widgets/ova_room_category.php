<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class ova_room_category extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'ova_room_category';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Room Category', 'ova-framework' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-products';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ovatheme' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

	

	protected function _register_controls() {

		$categories = get_categories(
                array(
                'type'                     => 'product',
                'child_of'                 => 0,
                'parent'                   => '',
                'orderby'                  => 'name',
                'order'                    => 'ASC',
                'hide_empty'               => 1,
                'hierarchical'             => 1,
                'exclude'                  => '',
                'include'                  => '',
                'number'                   => '',
                'taxonomy'                 => 'product_cat',
                'pad_counts'               => false 

              )
     	);
		$term_ids = array();
		if ($categories) {
			foreach ( $categories as $cate ) {				
				$key = get_term_meta( $cate->term_id, 'ovacrs_cat_dis', true );
			    if( $key == 'hotel' ) {
			        $term_ids[$cate->slug] = $cate->cat_name;
			    }
			}
		}

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			
			$this->add_control(
				'category',
				[
					'label'       => __( 'Select Room Category', 'ova-framework' ),
					'type'        => Controls_Manager::SELECT,
					'default'     => '',
					'options'     => $term_ids,
					'description' => __( 'Select Room Category', 'ova-framework' ),
				]
			);

			$this->add_control(
				'order',
				[
					'label'   => __( 'Order', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'DESC',
					'options' => [
						'DESC' => __( 'Decrease', 'ova-framework' ),
						'ASC'  => __( 'Ascending', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'total_items_cat',
				[
					'label'       => __( 'Total items in each category', 'ova-framework' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Insert -1 to display all items in category', 'ova-framework' ),
					'min'         => -1,
					"default"     => 3
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_product',
			[
				'label' => __( 'Product Settings', 'ova-framework' ),
			]
		);		

			$this->add_control(
				'show_price',
				[
					'label'   => __( 'Show Price', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'show_acreage',
				[
					'label'   => __( 'Show Acreage', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'show_special_info',
				[
					'label'   => __( 'Show Special Info', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

			$this->add_control(
				'show_number_special',
				[
					'label' => __('Show Special Info Number', 'ova-framework'),
					'type'  => Controls_Manager::NUMBER,
					'min'   => 1,
					'default' => 2,
					'condition' => [
						'show_special_info' => 'true'
					]
				]
			);

			$this->add_control(
				'show_adults_max',
				[
					'label'   => __( 'Show Adults Max', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);
			
			$this->add_control(
				'show_childrens_max',
				[
					'label'   => __( 'Show Childrens Max', 'ova-framework' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'true',
					'options' => [
						'true' => __( 'Yes', 'ova-framework' ),
						'false'  => __( 'No', 'ova-framework' ),
						
					],

				]
			);

		$this->end_controls_section();

		//Tab Style

		$this->start_controls_section(
			'section_room_cat_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_room_cat_typography',
				'selector' => '{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .second_font',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'title_room_cat_color',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .second_font a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_room_cat_hover_color',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .second_font a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_room_cat_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .second_font' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_room_cat_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .second_font' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_cat_price',
			[
				'label' => __( 'Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_room_cat_typography',
				'selector' => '{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .wrap_img .price_night .wrap_content .amount,
							   {{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .price_night .wrap_content .amount',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'price_room_cat_color',
			[
				'label' => __( 'Price Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .wrap_img .price_night .wrap_content .amount,
					{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .price_night .wrap_content .amount' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'price_room_cat_hover_color',
			[
				'label' => __( 'Price Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .wrap_img .price_night .wrap_content .amount:hover,
					{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .price_night .wrap_content .amount:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_cat_info',
			[
				'label' => __( 'Room Info', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'info_room_cat_typography',
				'selector' => '{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .specical-infor li span',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'info_room_cat_color',
			[
				'label' => __( 'Title Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .specical-infor li span' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'info_room_cat_hover_color',
			[
				'label' => __( 'Title Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .specical-infor li span:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'info_room_cat_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .specical-infor li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'info_room_cat_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content .specical-infor li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_excerpt_room_cat',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_room_cat_typography',
				'selector' => '{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content p',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'excerpt_room_cat_color',
			[
				'label' => __( 'Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content p' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'excerpt_room_cat_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_romm_cat_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .rental_item_grid .border-box .content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_room_cat_bt',
			[
				'label' => __( 'Button View All', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cat_bt_typography',
				'selector' => '{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'cat_bt_color',
			[
				'label' => __( 'Button Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cat_bt_hover_color',
			[
				'label' => __( 'Button Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cat_bt_background',
			[
				'label' => __( 'Button Background', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all' => 'background : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cat_bt_background_hover',
			[
				'label' => __( 'Button Background Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all:hover' => 'background : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cat_bt_border_color',
			[
				'label' => __( 'Button Border Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all' => 'border-color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cat_bt_border_hover_color',
			[
				'label' => __( 'Button Border Hover Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "",
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all:hover' => 'border-color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'booking_bt_room_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'booking_bt_room_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .hozing_wrap_product_grid .view_all_room .view-all' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
	?>
		<?php $settings = $this->get_settings(); ?>

		<?php 
            $args_room = array(
				'post_type'   => 'product',
				'post_status' => 'publish',
				'tax_query'   => array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'slug',
						'terms'    => $settings['category'],
					)
				),
				'posts_per_page' => $settings['total_items_cat'],
				'order'          => $settings['order'],
            );

        	$category_link = get_term_link( $settings['category'], 'product_cat' );
            $hozing_products = new \WP_Query($args_room); 

        ?>

        <div class="woocommerce hozing_wrap_product_grid">
        	<div class="container">
				<div class="row">
					
		            <?php 
		            	$count = 0;
		            	if( $hozing_products->have_posts() ) : while( $hozing_products->have_posts() ) : $hozing_products->the_post();

	         			global $product;
	         			$count++;
     					$class_odd_even = ($count % 2 == 0) ? ' even ' : ' odd ';
						$hozing_room_category  = wp_get_attachment_image_url( get_post_thumbnail_id(), 'hozing_room_grid_m' );
	              	?>
	              	
	              	<div class="col-lg-4 col-md-12">
		              	<div class="rental_item_grid">
							<div class="border-box <?php echo $class_odd_even; ?>">
								<div class="wrap_img">
									<div class="images_thumb">
										<img src="<?php echo esc_url( $hozing_room_category ); ?>" alt="" />
									</div>
									<?php if( $settings['show_price'] == 'true') { ?> 
						            <div class="price_night">               
						                <span class="wrap_content">
						                    <span class="time-night"><?php esc_html_e( 'From:', 'ova-framework' ); ?></span>
						                    <?php echo wp_kses_post( $product->get_price_html() ); ?>
						                    <span class="time-night"><?php esc_html_e( '/ Night', 'ova-framework' ); ?></span>
						                </span>              
						            </div>
							        <?php } ?>
								</div>

								<div class="content">
									<?php if( $settings['show_price'] == 'true') { ?> 
						            <div class="price_night">               
						                <span class="wrap_content">
						                    <span class="time-night"><?php esc_html_e( 'From:', 'ova-framework' ); ?></span>
						                    <?php echo wp_kses_post( $product->get_price_html() ); ?>
						                    <span class="time-night"><?php esc_html_e( '/ Night', 'ova-framework' ); ?></span>
						                </span>              
						            </div>
							        <?php } ?>
									<h3 class="second_font"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
									 <?php 
						                $ovacrs_car_acreage = get_post_meta( get_the_id(), 'ovacrs_car_acreage', true );
						                $ovacrs_car_max_adults = get_post_meta( get_the_id(), 'ovacrs_car_max_adults', true );
						                $ovacrs_car_max_childrens = get_post_meta( get_the_id(), 'ovacrs_car_max_childrens', true );

						                $ovacrs_specials_featured = get_post_meta( get_the_id(), 'ovacrs_specials_featured', true );
						                $ovacrs_specials_label = get_post_meta( get_the_id(), 'ovacrs_specials_label', true );
						            ?>

						            <ul class="specical-infor">
						                <?php if( $settings['show_acreage'] == 'true'){
						                    if ( $ovacrs_car_acreage != '') : ?>
						                    <li class="d-inline-flex"><span>
						                        <?php echo $ovacrs_car_acreage;?></span></li><?php endif;} ?>
						                <?php if( $settings['show_adults_max'] == 'true'){ 
						                    if ( $ovacrs_car_max_adults != '' ) : ?>
						                    <li class="d-inline-flex"><span>
						                        <?php echo $ovacrs_car_max_adults;?>
						                        <?php esc_html_e( 'Adults', 'ova-framework' ); ?></span></li><?php endif;} ?>
						                <?php if( $settings['show_childrens_max'] == 'true'){
						                    if ( $ovacrs_car_max_childrens != '' ) : ?>
						                    <li class="d-inline-flex"><span>
						                        <?php echo $ovacrs_car_max_childrens;?>
						                        <?php esc_html_e( 'Childrens', 'ova-framework' ); ?></span></li><?php endif;} ?>
						                <?php
						                $item_special = 0;
						                $show_number_special = absint( $settings['show_number_special'] );
						                if( $settings['show_special_info'] == 'true' ) :  
						                    if( $ovacrs_specials_featured ){
						                        
						                        foreach ($ovacrs_specials_featured as $key => $value) {
						                            if( $value == 'yes' && trim( $ovacrs_specials_label[$key] ) != '' ){
						                            ?>                               
						                            <li class="d-inline-flex">
						                                <span class="label"><?php echo esc_attr( $ovacrs_specials_label[$key] ); ?></span>
						                            </li>
						                            <?php $item_special++;                                   
						                            }
						                            if( $item_special >= $show_number_special){
						                            	break;
						                            } 
						                        }                            
						                    }
						                endif;        
						                ?>
						            </ul>
						            <p><?php echo wp_trim_words( get_the_excerpt(),18,'' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				
					<?php endwhile; endif; wp_reset_postdata();?>
					<div class="view_all_room"><a class="view-all" href="<?php echo esc_url($category_link);?>" ><?php esc_html_e( 'View All Room', 'ova-framework' );?></a></div>
				</div>
         	</div>                	                               	                            	                          	              	        
	    </div> <!-- hozing_product_slider -->

	<?php } 
	
}
