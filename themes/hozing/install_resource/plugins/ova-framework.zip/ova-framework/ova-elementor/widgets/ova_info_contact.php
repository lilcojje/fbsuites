<?php
namespace ova_framework\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\REPEATER;



if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class ova_info_contact extends Widget_Base {

	public function get_name() {
		return 'ova_info_contact';
	}

	public function get_title() {
		return __( 'Info Contact', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-info';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);


			$this->add_control(
				'text_title',
				[
					'label' => __( 'Text Title', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Our Contacts', 'ova-framework' ),
				]
			);


			$repeater = new Repeater();

			$repeater->add_control(
				'text_info',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'icon',
				[
					'label' => __( 'Social Icons', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::ICON,
				]
			);

			$this->add_control(
				'list_info',
				[
					'type' => Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'text_info' => 'HoZing Luxury Hotel',
							'icon' => 'fas fa-map-marker-alt',
						],
						[
							'text_info' => 'support@hozingluxury.com',
							'icon' => 'fa fa-envelope-o',
						],
						[
							'text_info' => 'Tel.: +41 (0)54 2344 00',
							'icon' => 'fa fa-phone',
						],
					],
				]
			);

			

		
		$this->end_controls_section();


		/*******************************************************************************
						TAB STYLE INFO CONTACT
		********************************************************************************/

		/*************  section controll title *******************/

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'typo_title',
					'selector' => '{{WRAPPER}} .ova_info_contact .wrap_title .title',
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .wrap_title .title' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .wrap_title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);

			$this->add_responsive_control(
				'padding_title',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .wrap_title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);


		$this->end_controls_section();

		###############   end title tab ################

		/*************  section controll Icon *******************/

		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Icon', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);

			$this->add_control(
				'color_icon',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .list_info .info i' => 'color: {{VALUE}}',
					],
					'separator' => 'after',
				]
			);

			$this->add_responsive_control(
				'margin_icon',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .list_info .info i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);

			$this->add_responsive_control(
				'padding_icon',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .list_info .info i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);


		$this->end_controls_section();

		################## end style info ################


		/*************  section controll info *******************/

		$this->start_controls_section(
			'section_info',
			[
				'label' => __( 'Info', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'typo_info',
					'selector' => '{{WRAPPER}} .ova_info_contact .list_info .info span',
				]
			);

			$this->add_control(
				'color_info',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .list_info .info span' => 'color: {{VALUE}}',
					],
					'separator' => 'after',
				]
			);

			$this->add_control(
				'position_info',
				[
					'label' => __( 'Position', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => -100,
							'max' => 200,
							'step' => 1,
						]
					],
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .list_info .info span' => 'left: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_info',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .list_info .info span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);

			$this->add_responsive_control(
				'padding_info',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_info_contact .list_info .info span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);


		$this->end_controls_section();

		################## end style info ################

	}

	protected function render() {
		$settings = $this->get_settings();

		?>
		
		<div class="ova_info_contact ">
			<div class="wrap_title">
				<div class="title second_font"><?php echo $settings['text_title']; ?></div>
			</div>
			<ul class="list_info">
				<?php foreach ( $settings['list_info'] as $index => $item ) { ?>
					<li class="info">
						<i class="<?php echo $item['icon']; ?>"></i>
						<span><?php echo $item['text_info']; ?></span>
					</li>
				<?php } ?>
			</ul>
		</div>
		<?php
	}

	
}

