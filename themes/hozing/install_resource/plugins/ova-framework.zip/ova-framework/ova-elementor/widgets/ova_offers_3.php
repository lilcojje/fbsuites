<?php
namespace ova_framework\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_offers_3 extends Widget_Base {

	public function get_name() {
		return 'ova_offers_3';
	}

	public function get_title() {
		return __( 'Offers 3', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-product-upsell ';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_offers',
			[
				'label' => __( 'Images', 'ova-framework' ),
			]
		);

			$this->add_control(
				'images',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);

			$this->add_control(
				'link_images',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => false,
					],
				]
			);

			$this->add_control(
				'price',
				[
					'label' => __( 'Price', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_price',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( '$500', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography',
					'selector' => '{{WRAPPER}} .offers_3 .price, {{WRAPPER}} .offers_3 .price_content ',
				]
			);

			$this->add_control(
				'text_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_3 .price, {{WRAPPER}} .offers_3 .price_content' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_title',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'ON THE BEACH', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .offers_3 .title ',
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_3 .title ' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'margin_title',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .offers_3 .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'description',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_description',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Start from ', 'ova-framework' ),
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .offers_3 .description ',
				]
			);

			$this->add_control(
				'description_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_3 .description ' => 'color: {{VALUE}}',
					],
				]
			);
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings();
		$images = $settings['images']['url'] != '' ? $settings['images']['url'] : '';
		$link_images = $settings['link_images']['url'] ? $settings['link_images']['url'] : '';
		$target = $settings['link_images']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link_images']['nofollow'] ? ' rel="nofollow"' : '';

		?>

		<div class="offers_3 ">
			<a href="<?php echo esc_html( $link_images ); ?>" <?php echo esc_html( $target); echo esc_html( $nofollow); ?> >
				<img src="<?php echo esc_url($images); ?>" alt="">
				<div class="price"><?php echo $settings['text_price']; ?></div>
				<div class="content">
					<div class="title second_font"><?php echo $settings['text_title']; ?></div>
					<div class="wrap_description">
						<span class="description"><?php echo $settings['text_description']; ?></span>
						<span class="price_content"><?php echo $settings['text_price']; ?></span>
					</div>

				</div>
			</a>
		</div>

		<?php
	}
}