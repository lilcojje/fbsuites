<?php
namespace ova_framework\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_offers_4 extends Widget_Base {

	public function get_name() {
		return 'ova_offers_4';
	}

	public function get_title() {
		return __( 'Offers 4', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-product-upsell ';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_offers',
			[
				'label' => __( 'Images', 'ova-framework' ),
			]
		);

			$this->add_control(
				'images',
				[
					'label' => __( 'Choose Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);

			$this->add_control(
				'link_images',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => false,
					],
				]
			);

			$this->add_control(
				'discount',
				[
					'label' => __( 'Discount', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_discount',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( '-50% ', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'discount_typography',
					'selector' => '{{WRAPPER}} .offers_4 .discount ',
				]
			);

			$this->add_control(
				'discount_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_4 .discount' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'content',
				[
					'label' => __( 'Content', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_content',
				[
					'type' => \Elementor\Controls_Manager::WYSIWYG,
					'default' => __( 'WEEKEN SPA OFFER', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'content_typography',
					'selector' => '{{WRAPPER}} .offers_4 .content ',
				]
			);

			$this->add_control(
				'content_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_4 .content p' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'overlay_color',
				[
					'label' => __( 'Overlay', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_4 .overlay_content' => 'background-color: {{VALUE}}',
					],
				]
			);

		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings();
		$images = $settings['images']['url'] != '' ? $settings['images']['url'] : '';

		$link_images = $settings['link_images']['url'] ? $settings['link_images']['url'] : '';
		$target = $settings['link_images']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link_images']['nofollow'] ? ' rel="nofollow"' : '';

		
		?>
		<div class="offers_4">
			<a href="<?php echo esc_html( $link_images ); ?>" <?php echo esc_html( $target); echo esc_html( $nofollow); ?> >
				<img src="<?php echo esc_url($images); ?>" alt="">
				<div class="overlay_content"></div>
				<div class="content second_font "><?php echo $settings['text_content']; ?></div>
				<div class="discount second_font"><?php echo $settings['text_discount']; ?></div>
			</a>
		</div>
		<?php
	}
}