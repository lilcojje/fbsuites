<?php
namespace ova_framework\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_offers_countdown extends Widget_Base {

	public function get_name() {
		return 'ova_offers_countdown';
	}

	public function get_title() {
		return __( 'Offers Countdown', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-product-upsell ';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		/*************** Section Content Offers ***************/
		$this->start_controls_section(
			'section_content_offers',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);
			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
				]
			);

			$this->add_control(
				'text_title',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Limited', 'ova-framework' ),
					'placeholder' => 'Sale',
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .offers_countdown .content .title',
				]
			);

			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .content .title' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'description',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_control(
				'text_description',
				[
					// 'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::WYSIWYG,
					'default' => __( ' 35% Off Couple Package ', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .offers_countdown .content .description',
				]
			);

			$this->add_responsive_control(
				'description_padding',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .content .description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'description_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .content .description, {{WRAPPER}} .offers_countdown .content .description p, {{WRAPPER}} .offers_countdown .content .description h1, {{WRAPPER}} .offers_countdown .content .description h2, {{WRAPPER}} .offers_countdown .content .description h3, {{WRAPPER}} .offers_countdown .content .description h4, {{WRAPPER}} .offers_countdown .content .description h5, {{WRAPPER}} .offers_countdown .content .description h6, {{WRAPPER}} .offers_countdown .content .description pre' => 'color: {{VALUE}}',
					],
				]
			);

		$this->end_controls_section();


		/*************** Section Countdouwn Offers ***************/
		$this->start_controls_section(
			'section_countdown',
			[
				'label' => __( 'Countdown', 'ova-framework' ),
			]
		);
			$this->add_control(
				'due_date',
				[
					'label' => __( 'Due Date', 'ova-framework' ),
					'type' => Controls_Manager::DATE_TIME,
					'default' => date( 'Y-m-d H:i', strtotime( '+1 day' ) + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ),
					'description' => sprintf( __( 'Date set according to your timezone: %s.', 'ova-framework' ), Utils::get_timezone_string() ),
					'separator' => 'after',
				]
			);

			$this->add_control(
				'number_countdown',
				[
					'label' => __( 'Number', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'number_countdown_typo',
					'selector' => '{{WRAPPER}} .offers_countdown .due_date .countdown-amount',
				]
			);

			$this->add_control(
				'number_countdown_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section .countdown-amount' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'number_countdown_hover_color',
				[
					'label' => __( 'Hover Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section:hover .countdown-amount' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'label_countdown',
				[
					'label' => __( 'Label', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'label_typo',
					'selector' => '{{WRAPPER}} .offers_countdown .due_date .countdown-period',
				]
			);

			/* Color Label */
			$this->start_controls_tabs( 'tabs_label_style' );

			$this->start_controls_tab(
				'tab_label_normal',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'label_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-period' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'label_bg_color',
				[
					'label' => __( 'Background', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-period' => 'background-color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_label_hover',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);
			$this->add_control(
				'countdown_hover_color',
				[
					'label' => __( 'Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section:hover .countdown-period' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'label_bg_hover_color',
				[
					'label' => __( 'Background', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section:hover .countdown-period' => 'background-color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_tab();

			$this->end_controls_tabs(); 
			/* End Color Label */

			$this->add_control(
				'show_days',
				[
					'label' => __( 'Days', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'default' => 'yes',
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section:nth-child(1)' => 'display: inline-flex;',
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'show_hours',
				[
					'label' => __( 'Hours', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'default' => 'yes',
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section:nth-child(2)' => 'display: inline-flex;',
					],
				]
			);

			$this->add_control(
				'show_minutes',
				[
					'label' => __( 'Minutes', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'default' => 'yes',
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section:nth-child(3)' => 'display: inline-flex;',
					],
				]
			);

			$this->add_control(
				'show_seconds',
				[
					'label' => __( 'Seconds', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-framework' ),
					'label_off' => __( 'Hide', 'ova-framework' ),
					'default' => 'yes',
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .due_date .countdown-section:nth-child(4)' => 'display: inline-flex;',
					],
				]
			);

			$this->add_responsive_control(
				'spacing_countdown',
				[
					'label' => __( 'Spacing', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .countdown-section:not(:last-child) ' => 'margin-right: {{SIZE}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		/*************** Section Countdouwn Offers ***************/
		$this->start_controls_section(
			'section_button',
			[
				'label' => __( 'Button', 'ova-framework' ),
			]
		);
			$this->add_control(
				'text_button',
				[
					'label' => __( 'Text', 'ova-framework' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'GET IT NOW', 'ova-framework' ),
					'placeholder' => 'Your text',
					'label_block' => true,
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .offers_countdown .button a',
				]
			);

			$this->add_control(
				'link_button',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'ova-framework' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => false,
					],
				]
			);

			$this->add_responsive_control(
				'button_padding',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'button_margin',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->start_controls_tabs( 'tabs_button_style' );

			$this->start_controls_tab(
				'tab_button_normal',
				[
					'label' => __( 'Normal', 'ova-framework' ),
				]
			);

			$this->add_control(
				'button_text_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'border_color',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a' => 'border-color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_button_hover',
				[
					'label' => __( 'Hover', 'ova-framework' ),
				]
			);

			$this->add_control(
				'hover_color',
				[
					'label' => __( 'Text Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_background_hover_color',
				[
					'label' => __( 'Background Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_hover_border_color',
				[
					'label' => __( 'Border Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'conditions' => [
						'terms' => [
							[
								'name' => 'border_style',
								'operator' => '!=',
								'value' => 'none',
							],
						],
					],
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'hover_animation',
				[
					'label' => __( 'Hover Animation', 'ova-framework' ),
					'type' => Controls_Manager::HOVER_ANIMATION,
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_control(
				'border_style',
				[
					'label' => __( 'Border Style', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'solid',
					'options' => [
						'solid'  => __( 'Solid', 'ova-framework' ),
						'dashed' => __( 'Dashed', 'ova-framework' ),
						'dotted' => __( 'Dotted', 'ova-framework' ),
						'double' => __( 'Double', 'ova-framework' ),
						'none' => __( 'None', 'ova-framework' ),
					],
					'selectors' => [
						'{{WRAPPER}} .offers_countdown .button a' => 'border-style: {{VALUE}};',
					],
					'separator' => 'before',
				]
			);

		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings();
		$due_date = $settings['due_date'];
		$link_button = $settings['link_button'];
		$target = $settings['link_button']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link_button']['nofollow'] ? ' rel="nofollow"' : '';
		?>
		<div class="offers_countdown">
			<div class="content">
				<div class="title second_font"><?php echo $settings['text_title']; ?></div>
				<div class="description second_font"><?php echo $settings['text_description']; ?></div>
			</div>
			<div class="due_date" data-day="<?php echo $due_date; ?>"></div>
			<div class="button">
				<a class="<?php echo 'elementor-animation-'.esc_html( $settings['hover_animation'] ); ?>" href="<?php echo $settings['link_button']['url']; ?>" <?php echo esc_html( $target); echo esc_html( $nofollow); ?> ><?php echo $settings['text_button']; ?></a>
			</div>
		</div>
		<?php
	}
}