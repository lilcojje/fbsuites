<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_blog_slide extends Widget_Base {


	public function get_name() {
		return 'ova_blog_slide';
	}

	public function get_title() {
		return __( 'Blog Slide', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		$args = array(
		  'orderby' => 'name',
		  'order' => 'ASC'
		  );

		$categories=get_categories($args);
		$cate_array = array();
		$arrayCateAll = array( 'all' => 'All categories ' );
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->cat_name] = $cate->slug;
			}
		} else {
			$cate_array["No content Category found"] = 0;
		}

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ovatheme' ),
			]
		);

			$this->add_control(
				'category',
				[
					'label'   => __( 'Category', 'ovatheme' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'all',
					'options' => array_merge($arrayCateAll,$cate_array),
				]
			);

			$this->add_control(
				'total_count',
				[
					'label'   => __( 'Total Post', 'ovatheme' ),
					'type'    => Controls_Manager::TEXT,
					'default' => 3
				]
			);

			$this->add_control(
				'show_title',
				[
					'label'        => __( 'Show Title', 'ovatheme' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
					'separator'    => 'before',
				]
			);

			$this->add_control(
				'show_date',
				[
					'label'        => __( 'Show Time', 'ovatheme' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'show_comments',
				[
					'label'        => __( 'Show Comments', 'ovatheme' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'show_excerpt',
				[
					'label'        => __( 'Show Excerpt', 'ovatheme' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'show_read_more',
				[
					'label'        => __( 'Show Read More', 'ovatheme' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
					'separator'    => 'before',
				]
			);

			$this->add_control(
				'text_read_more',
				[
					'label'       => __( 'Text Read More', 'ovatheme' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => 'Read More',
					'placeholder' => 'Text',
					'conditions'  => [
						'terms' => [
							[
								'name' => 'show_read_more',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'show_line_read_more',
				[
					'label' => __( 'Show Line Read More', 'ovatheme' ),
					'type' => Controls_Manager::SWITCHER,
					// 'return_value' => 'no',
					// 'default' => 'yes',
					'selectors' => [
						'{{WRAPPER}} .read_more a span' => 'display:inline-block',
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_read_more',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);

			$this->add_control(
				'line_read_more',
				[
					'label' => __( 'Line Read More Style', 'plugin-domain' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'bottom: 50%; right: -40px;',
					'options' => [
						'top:0; left:50%; margin-left:-20px' => __( 'Top', 'plugin-domain' ),
						'bottom:0; left:50%; margin-left:-20px' => __( 'Bottom', 'plugin-domain' ),
						'bottom: 50%; left: -40px;' => __( 'Left', 'plugin-domain' ),
						'bottom: 50%; right: -40px;' => __( 'Right', 'plugin-domain' ),
					],
					'conditions' => [
						'terms' => [
							[
								'name' => 'show_line_read_more',
								'operator' => '!=',
								'value' => '',
							],
						],
					],
				]
			);
		$this->end_controls_section();

		// section style //////////////////////////
		// Title style
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Title', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'label' => __( 'Typography', 'plugin-domain' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .title',
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'elementor' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .title a' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'title_hover_color',
				[
					'label' => __( 'Title Hover Color', 'elementor' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .title a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			
			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Title Padding', 'elementor' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} a.elementor-button, {{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'title_align',
				[
					'label' => __( 'Title Alignment', 'plugin-domain' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'text-left' => [
							'title' => __( 'Left', 'plugin-domain' ),
							'icon' => 'fa fa-align-left',
						],
						'text-center' => [
							'title' => __( 'Center', 'plugin-domain' ),
							'icon' => 'fa fa-align-center',
						],
						'text-right' => [
							'title' => __( 'Right', 'plugin-domain' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'toggle' => true,
				]
			);
		$this->end_controls_section();

		// time style
		$this->start_controls_section(
			'section_time_style',
			[
				'label' => __( 'Time & Comments', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'time_typography',
					'label' => __( 'Typography', 'plugin-domain' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .time',
				]
			);
			$this->add_control(
				'time_color',
				[
					'label' => __( 'Time & Comment Color', 'elementor' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .time' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_responsive_control(
				'time_padding',
				[
					'label' => __( 'Time Padding', 'elementor' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} a.elementor-button, {{WRAPPER}} .time' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'time_align',
				[
					'label' => __( 'Time Alignment', 'plugin-domain' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'text-left' => [
							'title' => __( 'Left', 'plugin-domain' ),
							'icon' => 'fa fa-align-left',
						],
						'text-center' => [
							'title' => __( 'Center', 'plugin-domain' ),
							'icon' => 'fa fa-align-center',
						],
						'text-right' => [
							'title' => __( 'Right', 'plugin-domain' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'text-center',
					'toggle' => true,
				]
			);
		$this->end_controls_section();

		// excerpt_style
		$this->start_controls_section(
			'section_excerpt_style',
			[
				'label' => __( 'Excerpt', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'excerpt_typography',
					'label' => __( 'Typography', 'plugin-domain' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .excerpt',
				]
			);

			$this->add_control(
				'excerpt_color',
				[
					'label' => __( 'Text Color', 'elementor' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .excerpt' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_responsive_control(
				'excerpt_padding',
				[
					'label' => __( 'Excerpt Padding', 'elementor' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .excerpt' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'excerpt_align',
				[
					'label' => __( 'Excerpt Alignment', 'plugin-domain' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'text-left' => [
							'title' => __( 'Left', 'plugin-domain' ),
							'icon' => 'fa fa-align-left',
						],
						'text-center' => [
							'title' => __( 'Center', 'plugin-domain' ),
							'icon' => 'fa fa-align-center',
						],
						'text-right' => [
							'title' => __( 'Right', 'plugin-domain' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'toggle' => true,
				]
			);
		$this->end_controls_section();

		// read more
		$this->start_controls_section(
			'section_read_more_style',
			[
				'label' => __( 'Read More', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'read_more_typography',
					'label' => __( 'Typography', 'plugin-domain' ),
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .read_more a',
				]
			);

			$this->add_control(
				'read_more_align',
				[
					'label' => __( 'Read More Alignment', 'plugin-domain' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'text-left' => [
							'title' => __( 'Left', 'plugin-domain' ),
							'icon' => 'fa fa-align-left',
						],
						'text-center' => [
							'title' => __( 'Center', 'plugin-domain' ),
							'icon' => 'fa fa-align-center',
						],
						'text-right' => [
							'title' => __( 'Right', 'plugin-domain' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'toggle' => true,
				]
			);

			$this->add_responsive_control(
				'read_more_padding',
				[
					'label' => __( 'Read More Padding', 'elementor' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .read_more a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_responsive_control(
				'read_more_margin',
				[
					'label' => __( 'Read More Margin', 'elementor' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .read_more a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			$this->start_controls_tabs( 'tabs_button_style' );
				$this->start_controls_tab(
					'tab_button_normal',
					[
						'label' => __( 'Normal', 'elementor' ),
					]
				);

				$this->add_control(
					'read_more_text_color',
					[
						'label' => __( 'Text Color', 'elementor' ),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .read_more a' => 'color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'read_more_background_color',
					[
						'label' => __( 'Background Color', 'elementor' ),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .read_more a' => 'background-color: {{VALUE}};',
						],
					]
				);
				
				$this->end_controls_tab();

				// Tab button hover
				$this->start_controls_tab(
					'tab_button_hover',
					[
						'label' => __( 'Hover', 'elementor' ),
					]
				);

					$this->add_control(
						'hover_color',
						[
							'label' => __( 'Text Color', 'elementor' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .read_more a:hover' => 'color: {{VALUE}};',
							],
						]
					);

					$this->add_control(
						'button_background_hover_color',
						[
							'label' => __( 'Background Color', 'elementor' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .read_more a:hover' => 'background-color: {{VALUE}};',
							],
						]
					);

					$this->add_control(
						'button_hover_border_color',
						[
							'label' => __( 'Border Color', 'elementor' ),
							'type' => Controls_Manager::COLOR,
							'condition' => [
								'border_border!' => '',
							],
							'selectors' => [
								'{{WRAPPER}} .read_more a:hover' => 'border-color: {{VALUE}};',
							],
						]
					);

				$this->end_controls_tab();
			$this->end_controls_tabs();

			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'border',
					'placeholder' => '1px',
					'default' => '1px',
					'selector' => '{{WRAPPER}} .read_more a',
					'separator' => 'before',
				]
			);

			$this->add_control(
				'border_radius',
				[
					'label' => __( 'Border Radius', 'elementor' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors' => [
						'{{WRAPPER}} .read_more a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings();

		$args =array();
			if ($settings['category'] == 'all') {
				$args=array('post_type' => 'post', 'posts_per_page' => $settings['total_count']);
			}else{
				$args=array('post_type' => 'post', 'category_name'=>$settings['category'],'posts_per_page' => $settings['total_count']);
			}
		$html = '';

		$blog = new \WP_Query($args);

		
		$html .= '<div  class=" blog2 owl-carousel owl-theme ">';
			if($blog->have_posts()) : while($blog->have_posts()) : $blog->the_post();

				$html .= '<div class="item ">';

					$thumbnail_url_d = wp_get_attachment_image_url(get_post_thumbnail_id() , 'full' );
					$the_time = get_option('time_format');
					$settings = $this->get_settings_for_display();
					$html .= '<img  src="'.$thumbnail_url_d.'" >';

					$html .= '<div class="content">';
						$html .= $settings['show_title'] == 'yes' ? '<h3 class="title '.$settings['title_align'].'"><a href="'.get_the_permalink().'">'.get_the_title( ).'</a></h3>' : '';
						
						$html .= '<div class="time '.$settings['time_align'].'">';
							$html .= $settings['show_date'] == 'yes' ? '<span><i class="fas fa-calendar-alt"></i>&nbsp;'.get_the_time(get_option('date_format')).'</span>' : '';

							$comment_text = ( get_comments_number() == 1 ) ? esc_html__( 'comment', 'ireca' ) : esc_html__( 'comments', 'ireca' );
							$html .= $settings['show_comments'] == 'yes' ? '<span><i class="fas fa-comments"></i>&nbsp;'.get_comments_number().' '.$comment_text.'</span>' : '';
						$html .= '</div>';

						$html .= $settings['show_excerpt'] == 'yes' ? '<p class="excerpt '.$settings['excerpt_align'].'">'.get_the_excerpt().'</p>' : '';
						
						$html .= $settings['show_read_more'] == 'yes' ? '<p class="read_more '.$settings['read_more_align'].'"><a href="'.get_the_permalink().'">'.$settings['text_read_more'].'<span style="'.$settings['line_read_more'].'"></span></a></p>' : '';
					$html .= '</div>';

				$html .= '</div>';

			endwhile; endif; wp_reset_postdata();
		$html .= '</div>';

		echo $html;

	}
}
