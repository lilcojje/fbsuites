<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_about_type_2 extends Widget_Base {

	public function get_name() {
		return 'ova_about_type_2';
	}

	public function get_title() {
		return __( 'About Type 2', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-id-badge';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);



			$this->add_control(
				'image',
				[
					'label' => __( 'Choose Background Image', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
				]
			);

			$this->add_control(
				'link',
				[
					'label' => __( 'Link', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::URL,
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);

			$this->add_control(
				'sub_title',
				[
					'label' => __( 'Sub Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'Welcome to', 'ova-framework' ),
					'placeholder' => __( 'Type your sub title here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( '50 YEAR EXPERIENCE', 'ova-framework' ),
					'placeholder' => __( 'Type your title here', 'ova-framework' ),
				]
			);
			

			$this->add_control(
				'description',
				[
					'label' => __( 'Description', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::WYSIWYG,
					'rows' => 5,
					'default' => __( 'Ut enim minim veniam, quis nostrud exercitation', 'ova-framework' ),
					'placeholder' => __( 'Type your description here', 'ova-framework' ),
				]
			);

			$this->add_control(
				'text_view',
				[
					'label' => __( 'Text View', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,
					'default' => __( 'VIEW OUR HISTORY', 'ova-framework' ),
					'placeholder' => __( 'Type your text view here', 'ova-framework' ),
				]
			);

			##################### END SECTION CONTENT ABOUT VERSION 1 ############################

		$this->end_controls_section();


		/*******************************************************************************
						TAB STYLE ABOUT TYPE 2 
		********************************************************************************/


		/*************  section controll cover background. *******************/

		$this->start_controls_section(
			'section_background',
			[
				'label' => __( 'Cover Image Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);		

		$this->add_control(
			'cover_background_color',
			[
				'label' => __( 'Background Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova-about-type-2 .wp-content .content' => 'background-color : {{VALUE}};',
					'{{WRAPPER}} .ova-about-type-2 .wp-content .content .sub-title' => 'background-color : {{VALUE}};',
					'{{WRAPPER}} .ova-about-type-2 .wp-content .content .title' => 'background-color : {{VALUE}};',
					'{{WRAPPER}} .ova-about-type-2 .wp-content .content .desc' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll backgound cover ###############

		/*************  section controll sub title. *******************/

		$this->start_controls_section(
			'section_sub_title',
			[
				'label' => __( 'Sub Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'sub_title_typography',
					'selector' => '{{WRAPPER}} .ova-about-type-2 .wp-content .content .sub-title',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_sub_title',
				[
					'label' => __( 'Color Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .sub-title' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_sub_title',
				[
					'label' => __( 'Margin Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_sub_title',
				[
					'label' => __( 'Padding Sub Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll sub title ###############################


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Titlte', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova-about-type-2 .wp-content .content .title a',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_title',
				[
					'label' => __( 'Color Title', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .title a' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_title_hover',
				[
					'label' => __( 'Color Title Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .title a:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_title',
				[
					'label' => __( 'Padding Title', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll title ###############################


		/*************  section controll description. *******************/

		$this->start_controls_section(
			'section_desc',
			[
				'label' => __( 'Description', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography',
					'selector' => '{{WRAPPER}} .ova-about-type-2 .wp-content .content .desc p',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_desc',
				[
					'label' => __( 'Color Description', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .desc' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .desc p' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_desc',
				[
					'label' => __( 'Margin Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_desc',
				[
					'label' => __( 'Padding Description', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll description ###############################


		/*************  section controll read more. *******************/

		$this->start_controls_section(
			'section_readmore',
			[
				'label' => __( 'Text View', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'text_view_typography',
					'selector' => '{{WRAPPER}} .ova-about-type-2 .wp-content .content .readmore',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'color_text_view',
				[
					'label' => __( 'Color Text View', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .readmore' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'color_text_view_hover',
				[
					'label' => __( 'Color Text View Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .readmore:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_responsive_control(
				'margin_text_view',
				[
					'label' => __( 'Margin Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .readmore' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'padding_text_view',
				[
					'label' => __( 'Padding Text View', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .readmore' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll read more ###############################


		/*************  section controll border. *******************/

		$this->start_controls_section(
			'section_border',
			[
				'label' => __( 'Border', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_control(
				'width',
				[
					'label' => __( 'Width', 'plugin-domain' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .border-1' => 'border-width: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .border-2' => 'border-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'color_border',
				[
					'label' => __( 'Color border', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .border-1' => 'border-color : {{VALUE}};',
						'{{WRAPPER}} .ova-about-type-2 .wp-content .content .border-2' => 'border-color : {{VALUE}};',
					],
				]
			);


		$this->end_controls_section();
		#################### section controll border ###############################


	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$text_background = $image = $link = $target = $nofollow = $sub_title = $title = $description = $text_view = $has_image = $background_image = '';


		$image				= $settings['image']['url'];
		$link				= $settings['link']['url'];
		$target      		= $settings['link']['is_external'] ? ' target="_blank" ' : '';
		$nofollow   		= $settings['link']['nofollow'] ? ' rel="nofollow" ' : '';
		$sub_title 			= $settings['sub_title'];
		$title 				= $settings['title'];
		$description 	 	= $settings['description'];
		$text_view 		 	= $settings['text_view'];

		$has_image = !empty($image) ? true : false;

		if (!empty($image)) {
			$background_image = 'style="background-image: url('.$image.')"';
		}
	?>
	<div class="ova-about-type-2">
		
		<div class="wp-content" <?php echo $background_image ?> >
			<div class="content">
				<?php if(!$has_image) : ?>
				<div class="border-1"></div>
				<?php endif ?>
				<h4 class="sub-title second_font"><?php echo $sub_title ?></h4>
				<h3 class="title second_font"><a href="<?php echo $link ?>" <?php echo $target . $nofollow ?>><?php echo $title ?></a></h3>
				<div class="desc"><?php echo $description ?></div>
				<?php if (!$has_image) : ?><div class="border-2"><?php endif ?>
					<a href="<?php echo $link ?>" class="readmore" <?php echo $target . $nofollow ?>><?php echo $text_view ?></a>
				<?php if (!$has_image) : ?></div><?php endif ?>
			</div>
		</div>
	</div>
 		
	<?php
	}
}
