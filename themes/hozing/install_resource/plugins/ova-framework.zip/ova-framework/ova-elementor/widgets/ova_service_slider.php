<?php
namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_service_slider extends Widget_Base {

	public function get_name() {
		return 'ova_service_slider';
	}

	public function get_title() {
		return __( 'Service Slider', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

			$repeater_style = new \Elementor\Repeater();

				$repeater_style->add_control(
					'link',
					[
						'label' => __( 'Link ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::URL,
						// 'default' => __( '#', 'ova-framework' ),
					]
				);

				$repeater_style->add_control(
					'icon_overlay',
					[
						'label' => __( 'Icon Hover Image', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::ICON,
						'default' => 'fa fa-image',
					]
				);

				$repeater_style->add_control(
					'title',
					[
						'label' => __( 'Title ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => __( 'Future Thon', 'ova-framework' ),
						'row' => 2,
						'placeholder' => __( 'Type your title here', 'ova-framework' ),
					]
				);


				$repeater_style->add_control(
					'image',
					[
						'label' => __( 'Image', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'label_block' => true,
					]
				);

				$repeater_style->add_control(
					'text_start',
					[
						'label' => __( 'Text Start From ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'rows' => 2,
						'default' => __( 'Start From', 'ova-framework' ),
						'placeholder' => __( 'Type your description here', 'ova-framework' ),
					]
				);


				$repeater_style->add_control(
					'price',
					[
						'label' => __( 'Price ', 'ova-framework' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => __( '$500', 'ova-framework' ),
						'placeholder' => 'Price',
					]
				);

				$this->add_control(
					'tabs_service_slide',
					[
						'label' => __( 'Image Items', 'ova-framework' ),
						'type' => Controls_Manager::REPEATER,
						'fields' => $repeater_style->get_controls(),
						'title_field' => '{{{ title }}}',
					]
				);

		$this->end_controls_section();
		#################### section controll icon ###############################


		$this->start_controls_section(
			'section_choose_version',
			[
				'label' => __( 'Show Hide Content', 'ova-framework' ),
			]
		);

			$this->add_control(
				'show_icon_background',
				[
					'label' => __( 'Show Icon Background', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_title',
				[
					'label' => __( 'Show Title', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_text_start_from',
				[
					'label' => __( 'Show Text Start From', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_text_Price',
				[
					'label' => __( 'Show Text Price', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);

			$this->add_control(
				'show_icon',
				[
					'label' => __( 'Show icon', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
						
					],
				]
			);


		$this->end_controls_section();
		#################### section controll show hide content ###############################


		/*****************************************************************
						START SECTION ADDITIONAL
		******************************************************************/

		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => __( 'Additional Options', 'ova-framework' ),
			]
		);
			$this->add_control(
				'margin_items',
				[
					'label' => __( 'Margin Right Items', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 30,
				]
				
			);

			$this->add_control(
				'navigation',
				[
					'label' => __( 'Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'dots',
					'options' => [
						'dots' => __( 'Dots', 'ova-framework' ),
						'navs' => __( 'Navs', 'ova-framework' ),
						'both' => __( 'Navs and Dots', 'ova-framework' ),
						'none' => __( 'None', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'slides_to_scroll',
				[
					'label' => __( 'Slides to Scroll', 'ova-framework' ),
					'type' => Controls_Manager::SELECT,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-framework' ),
					'default' => '1',
					'options' => [1,2,3,4,5,6,7,8,9,10],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'pause_on_hover',
				[
					'label' => __( 'Pause on Hover', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'infinite',
				[
					'label' => __( 'Infinite Loop', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'center',
				[
					'label' => __( 'Center Slide', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label' => __( 'Autoplay', 'ova-framework' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no' => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label' => __( 'Autoplay Speed', 'ova-framework' ),
					'type' => Controls_Manager::NUMBER,
					'default' => 3000,
					'step' => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smartspeed',
				[
					'label'   => __( 'Smart Speed', 'ova-framework' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500
				]
			);

		$this->end_controls_section();
		//END SECTION ADDITIONAL



		/*******************************************************************************
								TAB STYLE 
		********************************************************************************/

		/*************  section controll Navigation. *******************/
		$this->start_controls_section(
			'section_navigation',
			[
				'label' => __( 'Navigation', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'navigation_fontsize',
				[
					'label' => __( 'Font Size Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 40,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next' => 'font-size: {{SIZE}}{{UNIT}}!important;',
					],
				]
			);

			$this->add_control(
				'navigation_position',
				[
					'label' => __( 'Position Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -200,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 10,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev' => 'right: calc(100% + {{SIZE}}{{UNIT}});',
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next' => 'left: calc(100% + {{SIZE}}{{UNIT}});',
					],
				]
			);

			$this->add_control(
				'navigation_width_height',
				[
					'label' => __( 'Width And Height Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 50,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'navigation_border_radius',
				[
					'label' => __( 'Border Radius Navigation', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'navigation_color',
				[
					'label' => __( 'Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,1)',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'navigation_hover_color',
				[
					'label' => __( 'Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,1)',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next:hover' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'navigation_background_color',
				[
					'label' => __( 'Background Color Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0)',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev, 
						{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next' => 'background-color : {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'navigation_background_hover_color',
				[
					'label' => __( 'Background Color Hover Navigation', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0)',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-prev:hover, 
						{{WRAPPER}} .ova-service-slider .owl-carousel .owl-nav .owl-next:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();
		###############  end section Navigation ###############


		/*************  section controll dots. *******************/
		$this->start_controls_section(
			'section_dots',
			[
				'label' => __( 'Dots', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'dots_fontsize',
				[
					'label' => __( 'Font Size Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots .owl-dot:before' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_position',
				[
					'label' => __( 'Position Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => -200,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots' => 'top: calc(100% + {{SIZE}}{{UNIT}});',
					],
				]
			);

			$this->add_control(
				'dots_width_height',
				[
					'label' => __( 'Width And Height Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_border_radius',
				[
					'label' => __( 'Border Radius Dots', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots .owl-dot' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'dots_color',
				[
					'label' => __( 'Color Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots .owl-dot:before' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'dots_color_hover',
				[
					'label' => __( 'Color Dots Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots .owl-dot:hover:before' => 'color : {{VALUE}};',
					],
				]
			);


			$this->add_control(
				'dots_background_color',
				[
					'label' => __( 'Background Color Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots .owl-dot' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

			$this->add_control(
				'dots_background_hover_color',
				[
					'label' => __( 'Background Color Hover Dots', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .owl-carousel .owl-dots .owl-dot:hover' => 'background-color : {{VALUE}}!important;',
					],
				]
			);

		$this->end_controls_section();
		###############  end section Dots ###############


		/*************  section controll cover image. *******************/

		$this->start_controls_section(
			'section_cover_image',
			[
				'label' => __( 'Cover Image Hover', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'cover_image_background_color_bellow',
				[
					'label' => __( 'Background Color Bellow Center', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(0,0,0,0.4)',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .service-media:before' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_background_color_above',
				[
					'label' => __( 'Background Color Above Center', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(255, 255, 255, 0.1)',
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .list-service-item .owl-item.center .service-item .service-media .overlay' => 'background-color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'cover_image_fontsize',
				[
					'label' => __( 'Font Size Icon', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 200,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Color Icon', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .ova-blog-slider-element .post-item .post-media .overlay i' => 'color : {{VALUE}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll cover image. ###############


		/*************  section controll title. *******************/

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .title h3',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .title h3' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'title_hover_color',
				[
					'label' => __( 'Title Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => "#b9a271",
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .title h3:hover' => 'color : {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .title h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Padding', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .title h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		###############  end section controll title. ###############


		/*************  section controll price. *******************/

		$this->start_controls_section(
			'section_price',
			[
				'label' => __( 'Price', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',
				'selector' => '{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .price',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'text_start_from_color',
			[
				'label' => __( 'Text Prcie Start From Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#000",
				'selectors' => [
					'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .price .text-start' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_price_color',
			[
				'label' => __( 'Text Prcie Color', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'default' => "#b9a271",
				'selectors' => [
					'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .price .text-price' => 'color : {{VALUE}};',
				],
			]
		);


		$this->add_responsive_control(
			'price_margin',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'price_padding',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova-service-slider .list-service-item .service-item .info-item-wrap .info-item .price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		###############  end section controll price. ###############

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$tabs_service_slide = $settings['tabs_service_slide'];
		$show_icon_background = $show_title = $show_text_start_from = $show_text_Price = $show_icon = '';
		$show_icon_background	= $settings['show_icon_background'] === 'yes' ? true : false;;
		$show_title				= $settings['show_title'] === 'yes' ? true : false;;
		$show_text_start_from 	= $settings['show_text_start_from'] === 'yes' ? true : false;
		$show_text_Price 		= $settings['show_text_Price'] === 'yes' ? true : false;
		$show_icon 				= $settings['show_icon'] === 'yes' ? true : false;

		$nav = $settings['navigation'];

		$data_options['items'] 				= 3;
		$data_options['center'] 			= $settings['center'] === 'yes' ? true : false;
		$data_options['slideBy'] 			= $settings['slides_to_scroll'];
		$data_options['margin'] 			= $settings['margin_items'];
		$data_options['autoplayHoverPause'] = $settings['pause_on_hover'] === 'yes' ? true : false;
		$data_options['loop'] 			 	= $settings['infinite'] === 'yes' ? true : false;
		$data_options['autoplay'] 			= $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']	= $settings['autoplay_speed'];
		$data_options['smartSpeed']			= $settings['smartspeed'];
		

		switch ($nav) {
			case 'dots':
				$data_options['dots'] = true;
				$data_options['nav'] = false;
				break;

			case 'navs':
				$data_options['nav'] = true;
				$data_options['dots'] = false;
				break;

			case 'both':
				$data_options['dots'] = true;
				$data_options['nav'] = true;
				break;

			case 'none':
				$data_options['dots'] = false;
				$data_options['nav'] = false;
				break;
		}

	?>

		<div class="ova-service-slider">
			<div class="list-service-item single-slider owl-carousel"  data-options="<?php echo esc_html__(json_encode($data_options)) ?>">
				<?php if (!empty($tabs_service_slide)) : foreach ($tabs_service_slide as $service_item) :  ?>
					<div class="service-item">
						<div class="service-media">
							<a href="<?php echo $service_item['link']['url'] ?>">
								<img src="<?php echo $service_item['image']['url'] ?>" alt="">
							</a>
							<a href="#" class="overlay">
								<?php if ($show_icon_background) : ?>
									<i class="<?php echo $service_item['icon_overlay'] ?>"></i>
								<?php endif ?>
							</a>
						</div>
						<div class="info-item-wrap">
							<div class="info-item">
								<div class="title">
									<?php if ($show_title) : ?>
										<h3 class="second_font"><a href="<?php echo $service_item['link']['url'] ?>"><?php echo $service_item['title'] ?></a></h3>
									<?php endif ?>
								</div>
								<div class="price">
									<?php if ($show_text_start_from) : ?>
										<span class="text-start"><?php echo $service_item['text_start'] ?></span>
									<?php endif ?>
									<?php if ($show_text_Price) : ?>
										<span class="text-price"><?php echo $service_item['price'] ?></span>
									<?php endif ?>
								</div>
								<div class="icon">
									<?php if ($show_icon) : ?>
										<a href="<?php echo $service_item['link']['url'] ?>"><i class="fas fa-long-arrow-alt-right"></i></a>
									<?php endif ?>
								</div>
							</div>
						</div>
						<!-- end info-item-wrap -->
					</div>
					<!-- end service-item -->
				<?php endforeach; endif; ?>
			</div>
			<!-- end list-post-item -->
		</div>
		<!-- end ova-service-slider -->
	<?php
	}
}
