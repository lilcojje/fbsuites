<?php
/*******************************************
		Short code create html contact us
********************************************/
if ( ! function_exists('contact_us_ul')) {
	function contact_us_ul ( $args, $content ) {
		$html = "<ul class='hoz-contac-us'>
		".do_shortcode($content)."
		</ul>";
		return $html;
	}
}
add_shortcode( 'contact_us_ul', 'contact_us_ul' );

if ( ! function_exists('contact_us_li')) {
	function contact_us_li ( $args, $content ) {
		$icon = (!empty($args['icon'])) ? $args['icon'] : '';
		$html = "<li><i class='".$icon."'></i><a>".$content."</a></li>";
		return $html;
	}
}
add_shortcode( 'contact_us_li', 'contact_us_li' );


/*******************************************
Short code create html service element tab
********************************************/
if ( ! function_exists('service_tab_ul_ver_1')) {
	function service_tab_ul_ver_1 ( $args, $content ) {
		$html = "<div class='hoz-service-tab service_ver_1 list-item'>
					<div class='container'>
						<div class='row'>
							".do_shortcode($content)."
						</div>
					</div>
				</div>";
		return $html;
	}
}
add_shortcode( 'service_tab_ul_ver_1', 'service_tab_ul_ver_1' );


if ( ! function_exists('service_tab_ver_1_li')) {
	function service_tab_ver_1_li ( $args, $content ) {
		$title = (!empty($args['title'])) ? $args['title'] : '';
		$image_link = (!empty($args['image_link'])) ? $args['image_link'] : '';
		$link = (!empty($args['link'])) ? $args['link'] : '';
		$desc = (!empty($args['desc'])) ? $args['desc'] : '';
		$price = (!empty($args['price'])) ? $args['price'] : '';
		$num_col = (!empty($args['num_col'])) ? $args['num_col'] : 1;
		$col = 12 / $num_col;
		$class_col = "";
		switch ($col) {
			case "3":
				$class_col = 'col-lg-3 col-md-4 col-sm-6';
				break;
			case "4":
				$class_col = 'col-lg-4 col-md-6';
				break;
			default: 
				$class_col = 'col-lg-'.$col;
		}

		$html = "<div class='".$class_col."'>
					<div class='item '>
						<div class='item-image'>
							<a href='".$link."'>
								<img src='".$image_link."' alt='".$title."'>
							</a>
						</div>
						<div class='content'>
							<div>
								<h3 class='title second_font'><a href='".$link."'>".$title."</a></h3>
								<span class='price'>".$price."</span>
							</div>
							<p>".$desc."</p>
						</div>
						</div>
					</div>";
		return $html;
	}
}
add_shortcode( 'service_tab_ver_1_li', 'service_tab_ver_1_li' );



//shortcode created service tab 2
if ( ! function_exists('service_tab_ul_ver_2')) {
	function service_tab_ul_ver_2 ( $args, $content ) {
		$html = "<div class='hoz-service-tab service_ver_2 list-item'>
					<div class='container'>
						<div class='row'>
							".do_shortcode($content)."
						</div>
					</div>
				</div>";
		return $html;
	}
}
add_shortcode( 'service_tab_ul_ver_2', 'service_tab_ul_ver_2' );


if ( ! function_exists('service_tab_ver_2_li')) {
	function service_tab_ver_2_li ( $args, $content ) {
		$title = (!empty($args['title'])) ? $args['title'] : '';
		$image_link = (!empty($args['image_link'])) ? $args['image_link'] : '';
		$link = (!empty($args['link'])) ? $args['link'] : '';
		$desc = (!empty($args['desc'])) ? $args['desc'] : '';
		$price = (!empty($args['price'])) ? $args['price'] : '';
		$num_col = (!empty($args['num_col'])) ? $args['num_col'] : 1;
		$col = 12 / $num_col;
		$class_col = "";
		switch ($col) {
			case "3":
				$class_col = 'col-lg-3 col-md-4 col-sm-6';
				break;
			case "4":
				$class_col = 'col-lg-4 col-md-6';
				break;
			default: 
				$class_col = 'col-lg-'.$col;
		}


		$html = "<div class='".$class_col."'>
					<div class='item '>
						<div class='item-image' style='background-image: url(".$image_link.")'>
							<a href='".$link."'>
							</a>
							<div class='price'>
								<span class='text-price'>".$price."</span>
							</div>
						</div>
						<div class='content'>
							<h3 class='title second_font'><a href='".$link."'>".$title."</a></h3>
						</div>
						</div>
					</div>";
		return $html;
	}
}
add_shortcode( 'service_tab_ver_2_li', 'service_tab_ver_2_li' );





?>